repo_create.sh is a shell of create the android branch
default.xml is the XML of repo
