it is a chart of use MediaPlayer to player a ts file ------------taoanran add


the code(java) is like that:

media = new MediaPlayer();
surfaceview=(SurfaceView) this.findViewById(R.id.surfaceView1);
surfaceHolder = surfaceview.getHolder();//��ҪΪ��͸Ϳ��
surfaceHolder.setFixedSize(1280,720);

media.setDataSource("/mnt/nand/video.mp4");
media.setDisplay(surfaceview.getHolder());
media.setAudioStreamType(AudioManager.STREAM_MUSIC);

media.prepare();
media.start();  

��Ҫ����:   
media = new MediaPlayer();
media.setDataSource("/mnt/nand/video.mp4");
media.prepare();
media.start();  