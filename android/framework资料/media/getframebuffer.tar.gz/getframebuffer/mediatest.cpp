#include <media/mediaplayer.h>
#include <media/AudioTrack.h>
#include <surfaceflinger/SurfaceComposerClient.h>
#include <surfaceflinger/ISurfaceComposer.h>
#include <ui/DisplayInfo.h>

#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h> 

#include <pthread.h>

using namespace android;

sp<SurfaceControl> sfcontrol = NULL;
sp<Surface> surface = NULL;
sp<Surface> m_surface = NULL;
sp<ISurface> isurface = NULL;
sp<SurfaceComposerClient> client = NULL;
sp<ISurfaceTexture> ist = NULL;
sp<ISurfaceTexture> texture = NULL;
DisplayInfo dinfo;
static uint8_t *m_graphicPtr = NULL;
//创建视频播放的surface
sp<ISurfaceTexture> create_window(int width, int height)
{
Surface::SurfaceInfo info;
	client = new SurfaceComposerClient();
	status_t status = client->getDisplayInfo(0, &dinfo);
	if(status != 0)
	{
		dinfo.w = 1280;
		dinfo.h = 720;
	}

	if(client != NULL)
	{
		status_t status = client->getDisplayInfo(0, &dinfo);
		if(status != 0)
		{
			dinfo.w = 1280;//PLANE_WIDTH;
			dinfo.h = 720; //PLANE_HEIGHT;
		}
	}
	if(surface == NULL)
	{
		sfcontrol = client->createSurface(0, dinfo.w, dinfo.h, PIXEL_FORMAT_RGBA_8888);
		surface = sfcontrol->getSurface();
		SurfaceComposerClient::openGlobalTransaction();
		sfcontrol->setSize(dinfo.w, dinfo.h);
		sfcontrol->setPosition(1, 1);
		sfcontrol->setLayer(0x10000);
		sfcontrol->show();
		SurfaceComposerClient::closeGlobalTransaction();

		ist = surface->getSurfaceTexture();
	
	}
//	return surface;
	return ist;
}

void destory_window()
{
	client = NULL;
	sfcontrol = NULL;
	surface = NULL;
}

pthread_t ntid;

void *thread_func(void *arg)
{
	sleep(10);
	
	IPCThreadState::self()->stopProcess();	
	printf("exit");
	return NULL;
}

int main()
{
	sp<ProcessState> proc(ProcessState::self());
	printf("init player\n");
	MediaPlayer *m_player = new MediaPlayer;
	ProcessState::self()->startThreadPool();
	printf("create a surfaceTexture\n");
//	texture = create_window(1280, 720);
//	printf("setVideoSurfaceTexture texture\n");
//	m_player->setVideoSurface(m_surface);
//	m_player->setVideoSurfaceTexture(texture);
	printf("setDataSource is file:///data/test.ts\n");
	m_player->setDataSource((char*)"file:///data/1.mp3", NULL);
	printf("prepare for playing\n");
	printf("prepare = %d\n", m_player->prepare());
	
	m_player->start();
	
	printf("start to play video\n");
	
	pthread_create(&ntid, NULL, thread_func, NULL);
	
	IPCThreadState::self()->joinThreadPool();
//	IPCThreadState::self()->stopProcess();	
//	sleep(10);
	printf("1111111111111111\n");
//	m_player->stop();

	
}
