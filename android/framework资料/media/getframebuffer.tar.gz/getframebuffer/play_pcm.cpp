#include <media/AudioTrack.h>
#include <utils/Log.h>
#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IMemory.h>
#include <binder/Binder.h>
#include <math.h>

using namespace android;
static void bufferCallBack(int event, void* user, void* info);

typedef struct pcm_info{
	char* pcmbuf;
	int pcmsize;
	int pcmoffset;
}pcminfo_t;

static pcminfo_t m_pcm;

static int make_pcm(int sample_rate,char *func_buffer, int buf_size, int len_byte,int channel_num, int frequence)
{ 
	int len = sample_rate/frequence;
	int loop, point;
	double angle=0.0;
	int val_left, val_right;
	double pi=3.1415926;
	int Peak=32767;

	if ( NULL==func_buffer )
		return 0;

	if ( channel_num*sample_rate*2>buf_size || channel_num<1 || channel_num>2 )
		return 0;

	for ( point=0; point<len; ++point )	{
		angle = 2.0 * pi * (double)point / len;

		val_left =  (int)(Peak * sin( angle ));
		val_right = (int)(Peak * sin( angle+pi ));

		if ( channel_num ==1 )	{
			*(short *)( func_buffer+point*2 ) = (short)val_left;
		}else	{
			//channel_num=2
			*(short *)( func_buffer+point*4 ) = (short)val_left;
			*(short *)( func_buffer+point*4+2 ) = (short)val_right;
		}
	}

	for ( loop=1; loop<frequence; ++loop )	
	{
		for ( point=0; point<len; ++point )	
		{
			if ( channel_num ==1 )	
			{
				*(short *)( func_buffer+len*2*loop+point*2 ) = 
					*(short *)( func_buffer+point*2 );
			}
			else	//channel_num=2
			{
				*(short *)( func_buffer+len*4*loop+point*4 ) = 
					*(short *)( func_buffer+point*4 );
				*(short *)( func_buffer+len*4*loop+point*4+2 ) = 
					*(short *)( func_buffer+point*4+2 );
			}
		}
	}
	return loop*channel_num*len;	
}



int audiotrack_play( )
{
	AudioTrack* atrack = NULL;
	memset(&m_pcm,0,sizeof(m_pcm));
	m_pcm.pcmbuf = (char*)malloc( 48000 * 16 * 2 /8 );
	if( m_pcm.pcmbuf  == NULL )
	{
		printf("malloc failed\n");
		return -1;
	}
	memset( m_pcm.pcmbuf,0,48000 * 16 * 2 /8 );
	m_pcm.pcmsize = make_pcm(48000 , m_pcm.pcmbuf, 48000 * 16 * 2 /8 , 16 , 2, 300);
	m_pcm.pcmoffset = 0;
	atrack = new AudioTrack;
	atrack->set(AUDIO_STREAM_MUSIC, 48000,AUDIO_FORMAT_PCM_16_BIT,AUDIO_CHANNEL_OUT_STEREO,0, 0,bufferCallBack,&m_pcm);
	atrack->start();
	while( getchar() != 'q' );
	atrack->stop();
	free( m_pcm.pcmbuf );
	memset(&m_pcm,0,sizeof(m_pcm));
	delete atrack;
	return 0;
}

static void bufferCallBack(int event, void* user, void* info)
{
	AudioTrack::Buffer *buffer = (AudioTrack::Buffer *)info;
	pcminfo_t* pcm = (pcminfo_t*)user;
	int size = 0 ;
	switch(event) {
		case AudioTrack::EVENT_MORE_DATA:
			size = pcm->pcmsize - pcm->pcmoffset;
			if( buffer->size < size )
				size = buffer->size;
			memcpy( buffer->raw,pcm->pcmbuf+pcm->pcmoffset,size );
			buffer->size = size;
			pcm->pcmoffset += size;
			if( pcm->pcmoffset >= pcm->pcmsize )
				pcm->pcmoffset = 0;
			break;
		case AudioTrack::EVENT_BUFFER_END:
			printf("event EVENT_BUFFER_END\n");
		break;
		default:
			break;
	}
}

int main( int argc, char** argv )
{
	audiotrack_play();
	return 0;
}
