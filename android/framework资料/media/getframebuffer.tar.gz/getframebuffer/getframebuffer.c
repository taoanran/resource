#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/mman.h>

int main()
{
	int fbfd = 0;
	struct fb_var_screeninfo vinfo;
	struct fb_fix_screeninfo finfo;
	long int screensize = 0;
	char *fbp = 0;
	int x = 0, y = 0, i;
	long int location = 0;

	fbfd = open("/dev/graphics/fb0", O_RDWR);
	if(fbfd < 0)
	{
		printf("Error: cannot open framebuffer device.\n");
		return -1;
	}
	printf("The framebuffer device was opened successfully\n");

	if(ioctl(fbfd, FBIOGET_FSCREENINFO, &finfo)) 
	{
		printf("Error reading fixed information.\n");
		return -1;
	}

	if(ioctl(fbfd, FBIOGET_VSCREENINFO, &vinfo))
	{
		printf("Error reading variable information\n");
		return -1;
	}

	printf("The mem is: %d\n", finfo.smem_len);
	printf("the line length is: %d\n", finfo.line_length);
	printf("the xres is: %d\n", vinfo.xres);
	printf("the yres is: %d\n", vinfo.yres);
	printf("bits_per_pixel is: %d\n", vinfo.bits_per_pixel);

	close(fbfd);
	return 0;
}
