#include <stdio.h>
#include <math.h>
#include <strings.h>
#include <malloc.h>

//RIFF HEADER
typedef struct RIFF_HEADER
{
	char szRiffID[4]; // 'R','I','F','F'
	unsigned int dwRiffSize;
	char szRiffFormat[4]; // 'W','A','V','E'
}RIFF_HEADER_T;


typedef  struct WAVE_FORMAT
{
	unsigned short wFormatTag;
	unsigned short wChannels;
	unsigned int dwSamplesPerSec;
	unsigned int dwAvgBytesPerSec;
	unsigned short wBlockAlign;
	unsigned short wBitsPerSample;
}WAVE_FORMAT_T;

typedef struct FMT_BLOCK
{
	char szFmtID[4]; // 'f','m','t',' '
	unsigned int dwFmtSize;
	WAVE_FORMAT_T wavformat;
}FMT_BLOCK_T;


typedef struct DATA_BLOCK
{
	char DataID[4]; // 'f','m','t',' '
	unsigned int dwSize;
}DATA_BLOCK_T;

#if 0
static int make_pcm(int sample_rate,char *func_buffer, int buf_size, int len_byte,int channel_num, int frequence)
{ 
	int len = sample_rate/frequence;
	int loop, point;
	double angle=0.0;
	int val_left, val_right;
	
	static double pi=3.1415926;
	static int Peak=32767;
	
	if ( NULL==func_buffer )
		return 0;

	if ( channel_num*sample_rate*2>buf_size || channel_num<1 || channel_num>2 )
		return 0;

	for ( point=0; point<len; ++point )	{
		angle = 2.0 * pi * (double)point / len;
			
		val_left =  (int)(Peak * sin( angle ));
		val_right = (int)(Peak * sin( angle+pi ));
			
		if ( channel_num ==1 )	{
			*(short *)( func_buffer+point*2 ) = (short)val_left;
		}else	{
			//channel_num=2
			*(short *)( func_buffer+point*4 ) = (short)val_left;
			*(short *)( func_buffer+point*4+2 ) = (short)val_right;
		}
	}
	
	for ( loop=1; loop<frequence; ++loop )	
	{
		for ( point=0; point<len; ++point )	
		{
			if ( channel_num ==1 )	
			{
				*(short *)( func_buffer+len*2*loop+point*2 ) = 
					*(short *)( func_buffer+point*2 );
			}
			else	//channel_num=2
			{
				*(short *)( func_buffer+len*4*loop+point*4 ) = 
					*(short *)( func_buffer+point*4 );
				*(short *)( func_buffer+len*4*loop+point*4+2 ) = 
					*(short *)( func_buffer+point*4+2 );
			}
		}
	}
	return loop*channel_num*len;	
}

#endif
void main()
{
	RIFF_HEADER_T header;
	FMT_BLOCK_T  fmtblock;
	DATA_BLOCK_T  datablock;
	char *szTempBuf = NULL;
	int len = 0,inlen = 0;
	int samplerate = 11025,channels = 1,bitspersample = 8;
	FILE *fp = NULL,*fpin = NULL;
	fp  = fopen("audio.wav","wb");
	if( fp == NULL)
	{
		printf("cannot create file \n");
		return ;
	}
	fpin  = fopen("sound","rb");
	if( fpin == NULL)
	{
		printf("cannot create file \n");
		return ;
	}
	fseek( fpin,0,SEEK_END );
	inlen = ftell(fpin);
	fseek( fpin,0,SEEK_SET );
	szTempBuf = (char*)malloc( samplerate*bitspersample*channels/8 );
	
	//RIFF
	header.szRiffID[0] = 'R';
	header.szRiffID[1] = 'I';
	header.szRiffID[2] = 'F';
	header.szRiffID[3] = 'F';
	header.szRiffFormat[0] = 'W';
	header.szRiffFormat[1] = 'A';
	header.szRiffFormat[2] = 'V';
	header.szRiffFormat[3] = 'E';

	//WAVE
	fmtblock.wavformat.wFormatTag = 0x0001;
	fmtblock.wavformat.wChannels = channels;
	fmtblock.wavformat.dwSamplesPerSec = samplerate;//48000;
	fmtblock.wavformat.dwAvgBytesPerSec = samplerate*bitspersample*channels/8;
	fmtblock.wavformat.wBlockAlign = 2;
	fmtblock.wavformat.wBitsPerSample = bitspersample;
	
	//FMT BLOCK
	fmtblock.szFmtID[0] = 'f';
	fmtblock.szFmtID[1] = 'm';
	fmtblock.szFmtID[2] = 't';
	fmtblock.szFmtID[3] = ' ';
	fmtblock.dwFmtSize = sizeof(WAVE_FORMAT_T);
	//data
	datablock.DataID[0] = 'd';
	datablock.DataID[1] = 'a';
	datablock.DataID[2] = 't';
	datablock.DataID[3] = 'a';
	datablock.dwSize = inlen;
	header.dwRiffSize = sizeof(header)+sizeof(fmtblock)+sizeof(datablock)+inlen-8;
	
	//write header
	fwrite( &header,1,sizeof(header),fp );
	fwrite( &fmtblock,1,sizeof(fmtblock),fp );
	fwrite( &datablock,1,sizeof(datablock),fp );
	while( !feof(fp) )
	{
		len = fread( szTempBuf,1,samplerate*bitspersample*channels/8,fpin );
		if( len<=0 )
			break;
		fwrite( szTempBuf,1,len,fp );
	}
	free( szTempBuf );
	fclose( fp );
	fclose( fpin );
}
