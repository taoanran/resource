#include <stdio.h>
#include <math.h>
#include <string.h>
#include <malloc.h>

typedef struct RIFF_HEADER
{
		char szRiffID[4]; // 'R','I','F','F'
		unsigned int dwRiffSize; //wav file's data size
		char szRiffFormat[4]; // 'W','A','V','E'
}RIFF_HEADER_T; 

typedef struct WAVE_FORMAT
{
		unsigned short wFormatTag;
		unsigned short wChannels;
		unsigned int dwSamplesPerSec;
		unsigned int dwAvgBytesPerSec;
		unsigned short wBlockAlign;
		unsigned short wBitsPerSample;
}WAVE_FORMAT_T; 

typedef struct FMT_BLOCK
{
		char szFmtID[4]; // 'f','m','t',' '
		unsigned int dwFmtSize;
		WAVE_FORMAT_T wavFormat; 
}FMT_BLOCK_T; 

typedef struct DATA_BLOCK
{
		char szDataID[4]; // 'd','a','t','a'
		unsigned int  dwDataSize;
}DATA_BLOCK_T;

void wav_to_pcm()
{
    	RIFF_HEADER_T header;
		FMT_BLOCK_T  fmtblock;
		DATA_BLOCK_T  datablock;
		int len_wav_head = 0; 
		char szTempBuf[1024] ;
		FILE *fp_wav = NULL,*fp_pcm = NULL;
		int len_pcm = 0;
		int len_wav = 0;
		
		memset(szTempBuf,0,1024);
		
		fp_wav = fopen("./audio.wav", "rb");
		if (NULL == fp_wav)
		{
				printf("can't open the file(audio.wav)----------------[%d]\n", __LINE__);
				return ;
		}
		
		fp_pcm = fopen("./in.pcm", "wb");
		if (NULL == fp_pcm)
		{
				printf("can't open the file(PCM)----------------[%d]\n", __LINE__);
				return ;
		}
		
		len_wav_head = sizeof(RIFF_HEADER_T) + sizeof(FMT_BLOCK_T) + sizeof(DATA_BLOCK_T);
		fseek(fp_pcm, len_wav_head,SEEK_END); 

        while(1)
		{
				len_pcm = fread(szTempBuf, 1, 1024, fp_wav);
				printf("len = %d\n", len_pcm);
				if (len_pcm <= 0)
					break;
				fwrite(szTempBuf, 1, len_pcm, fp_pcm);
		}
        

		fclose(fp_pcm);
		fclose(fp_wav);
		fp_pcm = NULL;
		fp_wav = NULL;
}

int pcm_to_wav()
{
		RIFF_HEADER_T header;
		FMT_BLOCK_T  fmtblock;
		DATA_BLOCK_T  datablock;
		int samplerate = 11025*4,channels = 2,bitspersample = 16;
		char *szTempBuf = NULL;
		FILE *fp_wav = NULL,*fp_pcm = NULL;
		int len_pcm = 0;
		int len_wav = 0;
		
		szTempBuf = (char*)malloc( samplerate*bitspersample*channels/8 );
		memset(szTempBuf, 0, samplerate*bitspersample*channels/8);
		
		fp_wav = fopen("./audio.wav", "wb");
		if (NULL == fp_wav)
		{
				printf("can't open the file(audio.wav)----------------[%d]\n", __LINE__);
				return -1;	
		}
		
		fp_pcm = fopen("./out.pcm", "rb");
		if (NULL == fp_pcm)
		{
				printf("can't open the file(PCM)----------------[%d]\n", __LINE__);
				return -1;	
		}
		
		fseek(fp_pcm, 0,SEEK_END); 
		len_pcm =ftell(fp_pcm);
		fseek( fp_pcm,0,SEEK_SET );
		
		///RIFF('R','I','F','F')++++++++++++++++++++++++++++++++++++++++
		header.szRiffID[0] = 'R';
		header.szRiffID[1] = 'I';
		header.szRiffID[2] = 'F';
		header.szRiffID[3] = 'F';
		//header+fmtBlock+dataBlock+data-8
		header.dwRiffSize = sizeof(RIFF_HEADER_T) + sizeof(FMT_BLOCK_T) + sizeof(DATA_BLOCK_T) + len_pcm - 8;
		header.szRiffFormat[0] = 'W';
		header.szRiffFormat[1] = 'A';
		header.szRiffFormat[2] = 'V';
		header.szRiffFormat[3] = 'E';
		
		////WAVE++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		fmtblock.szFmtID[0] = 'f';
		fmtblock.szFmtID[1] = 'm';
		fmtblock.szFmtID[2] = 't';
		fmtblock.szFmtID[3] = ' ';

		fmtblock.dwFmtSize = sizeof(WAVE_FORMAT_T);
		
		fmtblock.wavFormat.wFormatTag = 0x0001;
		fmtblock.wavFormat.wChannels = channels;
		fmtblock.wavFormat.dwSamplesPerSec = samplerate;//48000
		fmtblock.wavFormat.dwAvgBytesPerSec = samplerate*channels*bitspersample/8; //1byte = 8bits
		fmtblock.wavFormat.wBlockAlign = channels*bitspersample/8 ;//ÿ��������Ҫ���ֽ���
		fmtblock.wavFormat.wBitsPerSample = bitspersample;//ÿ��������Ҫ��bit��
		
		//data
		datablock.szDataID[0] = 'd';
		datablock.szDataID[1] = 'a';
		datablock.szDataID[2] = 't';
		datablock.szDataID[3] = 'a';
		datablock.dwDataSize = len_pcm;
		
		//write wav header
		fwrite( &header,1,sizeof(header),fp_wav);
		fwrite( &fmtblock,1,sizeof(fmtblock), fp_wav);
		fwrite( &datablock,1,sizeof(datablock), fp_wav);
		
		//write the pcm data
		while(1)
		{
				len_pcm = fread(szTempBuf, 1, samplerate*bitspersample*channels/8, fp_pcm);
				printf("len = %d\n", len_pcm);
				if (len_pcm <= 0)
					break;
				fwrite(szTempBuf, 1, len_pcm, fp_wav);
		}
		fclose(fp_pcm);
		fclose(fp_wav);
		fp_pcm = NULL;
		fp_wav = NULL;
		
		free(szTempBuf);
		szTempBuf = NULL;
}

int main()
{
        pcm_to_wav();
        //wav_to_pcm();

         return 0;
}
