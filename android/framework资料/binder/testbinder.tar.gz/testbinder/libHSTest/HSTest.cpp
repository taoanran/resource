#include <binder/IServiceManager.h>
#include <binder/IPCThreadState.h>
#include "IHSTestService.h"
#include "HSTest.h"

namespace android{

sp<IHSTestService> server;

HSTest::HSTest(){}
HSTest::~HSTest(){}

int HSTest::add(int n)
{
		sp<IHSTestService>& mHSTestService = getMyService();
		LOGE("BpMyService::create remote()->transact()\n");
		int num = mHSTestService->add(n);
		LOGE("HSTest::add's num = %d\n", num);

		return num;
}

sp<IHSTestService>& HSTest::getMyService()
{
		sp<IServiceManager> sm = defaultServiceManager();
		sp<IBinder> binder;

		binder = sm->getService(String16("android.HSTestService"));

		LOGE("getMyService %p/n",sm.get());

		while (binder == 0) {
				LOGW("IHSTestService not published, waiting...");
		}
		server = interface_cast<IHSTestService>(binder);
		return server;
}


}; //namespace
