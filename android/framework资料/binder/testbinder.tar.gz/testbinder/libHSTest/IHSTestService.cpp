#include <utils/threads.h>  
#include <utils/RefBase.h>  
#include <binder/IInterface.h>  
#include <binder/BpBinder.h>  
#include <binder/Parcel.h>  

#include <utils/Log.h>
#include "IHSTestService.h"

namespace android {

enum{
	DISCONNECT = IBinder::FIRST_CALL_TRANSACTION,
	ADD,
};

class BpHSTestService : public BpInterface<IHSTestService>
{
	public:
			BpHSTestService(const sp<IBinder>& impl)
					: BpInterface<IHSTestService>(impl)
				{}

			int add(int n)
			{
					Parcel data, reply;
					data.writeInt32(n);
					remote()->transact(ADD, data, &reply);
					
					return reply.readInt32();
			}
};

IMPLEMENT_META_INTERFACE(HSTestService, "android.IHSTestService");

//-----------------------------------------------------------
status_t BnHSTestService::onTransact(uint32_t code, const Parcel& data, Parcel* reply, uint32_t flags)
{
	switch(code)
	{
		case ADD: {
			LOGE("[%s]---------------------ADD [%d][%s]\n", __func__, __LINE__, __FILE__);
			int32_t num = data.readInt32();
			reply->writeInt32(add(num));
			
			return NO_ERROR;
			} break;
		default:
			LOGE("[%s]---------------------not this case !!!!!! [%d][%s]\n", __func__, __LINE__, __FILE__);
			return BBinder::onTransact(code, data, reply, flags);
	}
}
//--------------------------------------------------------------------------------------------------------------
};//namespace
