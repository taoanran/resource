#include <unistd.h>  
#include <binder/IPCThreadState.h>  
#include <binder/ProcessState.h>  
#include <binder/IServiceManager.h>  
#include <utils/Log.h>  
#include <private/android_filesystem_config.h>  
#include "HSTestService.h"  

using namespace android;  

int main()
{
    LOGE("myserver ------------------------------ IN [%d]\n", __LINE__);
    
    sp<ProcessState> proc(ProcessState::self()); 
	LOGE("----------------------------------\n");
    sp<IServiceManager> sm = defaultServiceManager();//���ServiceManager�ӿ�  
//    LOGE("ServiceManage:0x%x ------------------------ [%s][%d]\n", sm, __func__, __LINE__);
    HSTestService::instantiate();  
    
		LOGE("HSTestService: ----------------1111----------\n");
    //ִ��addService()������ע�����
    ProcessState::self()->startThreadPool();  
		LOGE("HSTestService: ----------------2222----------\n");

	while(1)
	{
		sleep(1);
		LOGE("HSTestService::num = %d\n", HSTestService::num);
	}
    IPCThreadState::self()->joinThreadPool();  
    //����ѭ�����ȴ��ͻ��˵�����


    
    LOGE("myserver ------------------------------ OUT [%d]\n", __LINE__);
    
    return 0;
}
