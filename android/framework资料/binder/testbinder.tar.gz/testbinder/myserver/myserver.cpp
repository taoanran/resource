#include <unistd.h>  
#include <binder/IPCThreadState.h>  
#include <binder/ProcessState.h>  
#include <binder/IServiceManager.h>  
#include <utils/Log.h>  
#include <private/android_filesystem_config.h>  
#include "../libmyservice/myservice.h"  

using namespace android;  

int main()
{
    LOGE("myserver ------------------------------ IN [%d]\n", __LINE__);
    
    sp<ProcessState> proc(ProcessState::self()); 
	LOGE("----------------------------------\n");
    sp<IServiceManager> sm = defaultServiceManager();//���ServiceManager�ӿ�  
//    LOGE("ServiceManage:0x%x ------------------------ [%s][%d]\n", sm, __func__, __LINE__);
    MyService::instantiate();  
    
    //ִ��addService()������ע�����
    ProcessState::self()->startThreadPool();  

    IPCThreadState::self()->joinThreadPool();  
    //����ѭ�����ȴ��ͻ��˵�����
    
    LOGE("myserver ------------------------------ OUT [%d]\n", __LINE__);
    
    return 0;
}
