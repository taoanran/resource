#ifndef ANDROID_IHSTESTSERVICE_H
#define ANDROID_IHSTESTSERVICE_H


#include <utils/threads.h>  
#include <utils/RefBase.h>  
#include <binder/IInterface.h>  
#include <binder/BpBinder.h>  
#include <binder/Parcel.h>  

#include <utils/Log.h>

namespace android {
class IHSTestService : public IInterface 
{
	public:
		DECLARE_META_INTERFACE(HSTestService);

	 virtual int add(int) = 0;
};
//-----------------------------------------------------------
class BnHSTestService : public BnInterface<IHSTestService>
{
	public:
		   virtual status_t onTransact(uint32_t code, const Parcel& data, Parcel* reply, uint32_t flags = 0); 
};

};//namespace

#endif
