#ifndef ANDROID_HSTEST_H
#define ANDROID_HSTEST_H

#include <binder/IMemory.h>
#include "IHSTestService.h"
#include <utils/KeyedVector.h>
#include <utils/String8.h>

#include "IHSTestService.h"

namespace android{

class HSTest : public BnHSTestService
{
public:
		HSTest();
		~HSTest();		
			int add(int n);
			sp<IHSTestService>& getMyService();
			//通过ServiceManager获取服务接口
};

};

#endif
