#ifndef ANDROID_TESTSERVER_H
#define ANDROID_TESTSERVER_H

#include <utils/threads.h>  
#include <utils/RefBase.h>  
#include <binder/IInterface.h>  
#include <binder/BpBinder.h>  
#include <binder/Parcel.h>  

#include "IHSTestService.h" 
#include <utils/Log.h>

namespace android {
class HSTestService : public BnHSTestService
{
		public:
			static int instantiate();
			virtual ~HSTestService();
			virtual int add(int);


			static int num;
		private:
			HSTestService();
};


};//namespace

#endif//ANDROID_TESTSERVER_H
