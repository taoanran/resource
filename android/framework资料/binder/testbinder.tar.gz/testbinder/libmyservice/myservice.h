#include <utils/threads.h>  
#include <utils/RefBase.h>  
#include <binder/IInterface.h>  
#include <binder/BpBinder.h>  
#include <binder/Parcel.h>  
#include "ISWMeidaCMD.h"

#include <utils/Log.h>

namespace android {
		class SWMediaCMD : public BnSWMediaCMD
		{
				int mNextConnId;
			public:
				   SWMediaCMD();
				   virtual ~SWMediaCMD();
				   virtual int onTransact(uint32_t, const Parcel&, Parcel*, uint32_t); 
		};
};//namespace



