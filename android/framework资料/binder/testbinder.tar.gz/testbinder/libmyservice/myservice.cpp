#include <fcntl.h>
#include <limits.h>
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <android/log.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <linux/videodev2.h>


#include <utils/Log.h>

#include <binder/IBinder.h>
#include <binder/IInterface.h>
#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IServiceManager.h>
#include <binder/Parcel.h>
#include "ISWMediaCMD.h"

#include <media/IMediaDeathNotifier.h>
#include "myservice.h"


namespace android{
	static struct sigaction oldact;
	static pthread_key_t sigbuskey;  
	int MyService::instantiate()
	{
		int ret;

		LOGE("[%s] --------------------------- IN [%d]\n", __func__, __LINE__);

	    ret = defaultServiceManager()->addService(String16("adnroid.MyService"), new MyService());
		LOGE("adnroid.MyService = %d --------------------------------[%s][%d]\n", ret, __func__, __LINE__);

		return ret; 
	}

	MyService::MyService()
	{
		LOGE("[%s] --------------------------- IN [%d]\n", __func__, __LINE__);
		mNextConnId = 1;  
		pthread_key_create(&sigbuskey, NULL);  
	}

	MyService::~MyService()  
	{
		pthread_key_delete(sigbuskey);  
		LOGE("[%s] --------------------------- IN [%d]\n", __func__, __LINE__);
	}
	
	int MyService::onTransact(uint32_t code, const Parcel& data, Parcel* reply, uint32_t flags)  
	{
		switch(code) {
				case 0:
				{
					int num;
					pid_t pid = data.readInt32();  
					num = data.readInt32();
					num += 100;		
					reply->writeInt32(num);

					break;
				}
				default:
					LOGE("default ----------------------------[%s][%d]\n", __func__, __LINE__);
		}

		return NO_ERROR;
	}
};
