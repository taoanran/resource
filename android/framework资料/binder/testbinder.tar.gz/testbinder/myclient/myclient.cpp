#include <binder/IServiceManager.h>
#include <binder/IPCThreadState.h>
#include "myclient.h"

using namespace android;

namespace android
{
		sp<IBinder> binder;
		void MyClient::add100(int n)
		{
				getMyService();
				Parcel data, reply;
				int answer;

				data.writeInt32(getpid());
				data.writeInt32(n);

				LOGE("BpMyService::create remote()->transact()\n");

				binder->transact(0, data, &reply);

				answer = reply.readInt32();

				LOGE("answner=%d\n", answer);    

				return;
		}

		const void MyClient::getMyService()
		{
				sp<IServiceManager> sm = defaultServiceManager();

				binder = sm->getService(String16("adnroid.MyService"));

				LOGE("MyClient::getMyService %p/n",sm.get());

				if (binder == 0) {
						LOGW("MyService not published, waiting...");
						return;
				}
		}
}; //namespace


int main()
{
		MyClient* p = new MyClient();

		p->add100(1);

		return 0;
}
