namespace android{
		class MyClient {
				public:
						void add100(int n);
				private:
						static const void getMyService();
						//通过ServiceManager获取服务接口
		};
}
