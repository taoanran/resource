#include <fcntl.h>
#include <limits.h>
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <android/log.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <linux/videodev2.h>


#include <utils/Log.h>

#include <binder/IBinder.h>
#include <binder/IInterface.h>
#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IServiceManager.h>
#include <binder/Parcel.h>

#include <media/IMediaDeathNotifier.h>
#include "IHSTestService.h"
#include "HSTestService.h"


namespace android{
	static struct sigaction oldact;
	static pthread_key_t sigbuskey;  
	int HSTestService::num = 0;
	int HSTestService::instantiate()
	{
		int ret;

		LOGE("[%s] --------------------------- IN [%d]\n", __func__, __LINE__);

	    ret = defaultServiceManager()->addService(String16("android.HSTestService"), new HSTestService());
		LOGE("adnroid.MyService = %d --------------------------------[%s][%d]\n", ret, __func__, __LINE__);

		return ret; 
	}

	HSTestService::HSTestService()
	{
		LOGE("[%s] --------------------------- IN [%d]\n", __func__, __LINE__);
	//	mNextConnId = 1;  
	//	pthread_key_create(&sigbuskey, NULL);  
	}

	HSTestService::~HSTestService()  
	{
	//	pthread_key_delete(sigbuskey);  
		LOGE("[%s] --------------------------- IN [%d]\n", __func__, __LINE__);
	}

	int HSTestService::add(int t)
	{
		num += t;
		LOGE("[%s] --------------------------- num = %d [%d]\n", __func__, num, __LINE__);
		return num ;
	}

};
