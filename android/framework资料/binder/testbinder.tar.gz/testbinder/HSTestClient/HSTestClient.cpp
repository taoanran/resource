#include <binder/IServiceManager.h>
#include <binder/IPCThreadState.h>
#include "HSTest.h"
#include "IHSTestService.h"

using namespace android;

int main()
{
		HSTest* p = new HSTest();

		p->add(1);

		return 0;
}
