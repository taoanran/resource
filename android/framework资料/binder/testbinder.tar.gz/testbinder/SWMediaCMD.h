//SWMediaCMD.h

#ifndef __SWMEDIACMD_H__
#define __SWMEDIACMD_H__


#include <ISWMediaCMD.h>
namespace android {

class SWMediaCMD {
	public:
		 					SWMediaCMD();
		 virtual ~SWMediaCMD();
		 void     disconnect();
		 int 			SendCmd(SWMEDIA_CMD_TYPE_E cmd, char* param);
	private:
		 sp<ISWMediaCMD>            mPlayerService;
};

}

#endif