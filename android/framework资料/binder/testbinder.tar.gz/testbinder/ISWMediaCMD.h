
 
// Ibinder for comunication between mediaplayerservice and swservice
 
#ifndef ANDROID_ISWMEDIAINTERFACE_H
#define ANDROID_ISWMEDIAINTERFACE_H
 
#include <binder/Binder.h>
#include <utils/RefBase.h>
#include <binder/IInterface.h>
#include <binder/Parcel.h>
 
namespace android {
 	
	typedef enum {
 		SWMEDIA_CMD_TYPE_PPPOE,
 		SWMEDIA_CMD_TYPE_DISPLAY_FORMAT,
 		SWMEDIA_CMD_TYPE_VIDEOPHONE,
 		SWMEDIA_CMD_TYPE_NULL
 	}SWMEDIA_CMD_TYPE_E;
 	
 	class ISWMediaCMD: public IInterface{
 		
 		DECLARE_META_INTERFACE(SWMediaCMD);
    virtual void            disconnect() = 0;

 		virtual  int SendCmd(SWMEDIA_CMD_TYPE_E cmd, char* param) = 0;	
 	};
 	
 	class BnSWMediaCMD: public BnInterface<ISWMediaCMD>
{
public:
    virtual int    onTransact( uint32_t code,
                                    const Parcel& data,
                                    Parcel* reply,
                                    uint32_t flags = 0);
};
 	
};
#endif