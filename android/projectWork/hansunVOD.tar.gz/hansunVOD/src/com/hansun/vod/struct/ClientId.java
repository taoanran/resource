package com.hansun.vod.struct;
/*
 * name:        ClientId
 * function:    remember client(STB)'s ID, 
 * 				
 * description: this struct is a number of SSPClientSessionSetUpRequest message,
 * 				it is used to differentatiate STB and must be globally unique 
 * author:      taoanran
 * time:        2012.11.30
 * */
public class ClientId {
	public byte afi ;
	public byte []idi;
	public int dsp;
	public byte []mac;
	public byte sel ;
	
	public ClientId()
	{
		afi = 0;
		idi = new byte[8];
		for (int i=0; i<8; i++)
		{
			idi[i] = 0;
		}
		dsp = 0;
		mac = new byte[6];
		for (int i=0; i<6; i++)
		{
			mac[i] = 0;
		}
		sel = 0;
	}
}