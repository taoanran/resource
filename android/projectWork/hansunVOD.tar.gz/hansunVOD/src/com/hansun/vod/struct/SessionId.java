package com.hansun.vod.struct;
/*
 * name:        SessionId
 * function:    the SSP session ID
 * description: this is a data struct class
 * author:      taoanran
 * time:        2012.11.30
 * */
public class SessionId {
	////////deviceId, MAC Address, IP Address and system time
	public int   sysTime ;  	    ///system time 
	public byte mac[] ;			///mac address	
	
	public SessionId()
	{
		sysTime = 0;
		mac = new byte[6];
	}
}
