package com.hansun.vod.struct;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

import android.util.Log;
/*
 * className:   ClientSessionInProgressData 
 * function:    it is the heartBeat's(ssp connect) data
 * description: it is a struct class
 * author:      taoanran
 * createTime:  2012-12-25
 * */
public class NetFormatTransform {
	private final static String TAG = "NetFormatTransform";
	 /**
	  * 将一个Int 数据，转换为byte数组.
	  * @param intValue Int 数据
	  * @return byte数组.
	  */
	 public static byte[] integer2Bytes(int intValue) {
	  byte [] result = new byte[4];
	  result[0] = (byte) ((intValue & 0xFF000000) >> 24);
	  result[1] = (byte) ((intValue & 0x00FF0000) >> 16);
	  result[2] = (byte) ((intValue & 0x0000FF00) >> 8);
	  result[3] = (byte) ((intValue & 0x000000FF) );
	  return result;
	 } 
	 public static String int2IpString(int intValue) {
		 byte[] bs = integer2Bytes(intValue);
		 StringBuffer sb = new StringBuffer();	
		for(byte b : bs) {
			try {
				sb.append(unsignedByte2Int(b));
			} catch (IOException e) {
				sb.append('0');
			} 
			sb.append('.');
		}
		sb.delete(sb.length() - 1, sb.length());
		return sb.toString();
	 }
	 public static int unsignedByte2Int(byte b) throws IOException {
		 byte[] bs = new byte[2];
		 bs[0] = 0;
		 bs[1] = b;
		 return new DataInputStream(new ByteArrayInputStream(bs)).readShort();
	 }
	 /**
      * 将byte数组的数据，转换成Int值.
      * @param byteVal byte数组
      * @return Int值.
      */
     public static int bytes2Integer(byte[] byteVal) {
      int result = 0;
      Log.v(TAG, "byteVal.length = " + byteVal.length);
      for(int i = 0; i < byteVal.length; i ++) {
       int tmpVal = (byteVal[i] << (8 * (3-i)));
       switch (i) {
        case 0:
         tmpVal = tmpVal & 0xFF000000;
         break;
        case 1:
         tmpVal = tmpVal & 0x00FF0000;
         break;
        case 2:
         tmpVal = tmpVal & 0x0000FF00;
         break;
        case 3:
         tmpVal = tmpVal & 0x000000FF;
         break;
       }
       result = result | tmpVal;
      }
      return result;
     }
     /**
	  * 将一个Short 数据，转换为byte数组.
	  * @param intValue Short 数据
	  * @return byte数组.
	  */
	 public static byte[] short2Bytes(short shortValue) {
	  byte [] result = new byte[2];
	  result[0] = (byte) ((shortValue & 0xFF00) >> 8);
	  result[1] = (byte) ((shortValue & 0x00FF) );
	  return result;
	 } 
	 
	 /**
      * 将byte数组的数据，转换成Short值.
      * @param byteVal byte数组
      * @return Short值.
      */
     public static short bytes2Short(byte[] byteVal) {
		 short result = 0;
		 short tmpVal;
		 Log.v(TAG, "byteVal.length = " + byteVal.length);
		 for(short i = 0; i < byteVal.length; i ++) {
		  {
			  tmpVal = (short) (byteVal[i] << (8 * (1-i)));
			  //Log.v(TAG, "tmpVal = " + tmpVal);
		  }
       switch (i) {
        case 0:
         tmpVal = (short) (tmpVal & (short)0xFF00);
         break;
        case 1:
         tmpVal = (short) (tmpVal & (short)0x00FF);
         break;
       }
       result = (short) (result | tmpVal);
      }
      return result;
     }
     
     public static String getLocalIP() {
       		String IPString = new String();

            try {
                Enumeration<?> e1 = (Enumeration<?>) NetworkInterface.getNetworkInterfaces();
                while (e1.hasMoreElements()) {
                    NetworkInterface ni = (NetworkInterface) e1.nextElement();
                    //beacause the cable module is using eth1
                    if (!ni.getName().equals("eth1")) {
                        continue;
                    } else {
                        Enumeration<?> e2 = ni.getInetAddresses();
                        while (e2.hasMoreElements()) {
                            InetAddress ia = (InetAddress) e2.nextElement();
                            if (ia instanceof Inet6Address)
                                continue;
                            IPString = ia.getHostAddress();
                        }
                        break;
                    }
                }
            } catch (SocketException e) {
                e.printStackTrace();
                System.exit(-1);
            }
            Log.v(TAG, "IPString = " + IPString);
            return IPString;
        }
}
