package com.hansun.vod.struct;

import java.util.ArrayList;

import java.util.List;


/*
 * name:        ClientSessionSetupRequestBody
 * function:    ClientSessionSetupRequest's body, behind the ClientSessionSetupRequest's head, 
 * 				
 * description: this struct is the body of SSPClientSessionSetUpRequest message,
 *				
 * author:      taoanran
 * time:        2012.12.06
 * */
public class ClientSessionSetupRequestBody {
	public short m_uuDataLength ;
	public short m_privateDataLength ; //private data length is 0x56 bytes
	public byte  m_protocolID;
	public byte  m_version;
	public byte m_descriptorCount;
	//public byte []m_assetID = new byte[8];
	public AssetID m_assetID = null;
	public NodeGroupId m_nodeGroupID = null;
	public ApplicationRequestData m_applicationRequestData = null;
	
	public class AssetID
	{
		public byte tag ;  
		public byte  datelength ; 
		public String data = null;   
		
		public AssetID()
		{
			tag = 0;
			datelength = 0;
			data = new String();
		}
	}
	public class NodeGroupId
	{
		public byte tag ;  /// 0x02
		public byte  datelength ;    /// 0x06
		public byte []data ;   ///   00 00 00 00 03 e9 [0x03e9]
		
		public NodeGroupId()
		{
			tag = 0;
			datelength = 0;
			data = new byte[6];
			for (int i=0; i<6; i++)
			{
				data[i]= 0;
			}
		}
	}
	public class ApplicationRequestData
	{
		public byte descriptorTag  ; //0x05
		public byte descriptorLength  ; //the next data length
		public byte protocol  ; //0x01
		public byte version  ; //0x01
		public byte count  ; //0x
		//public List<AppDescInfo> m_appDescInfo = new ArrayList<AppDescInfo>();//AppDescInfo, has 8 member
		public AppDescInfo[] m_appDescInfo = null;
		public class AppDescInfo
		{
			public byte appDescTag ;  /// 0x02
			public byte appDescLength ;    /// 0x06
			public int appDescdata ;   ///   00 00 00 00 03 e9 [0x03e9]s
			
			public AppDescInfo()
			{
				appDescTag = 0;
				appDescLength = 0;
				appDescdata = 0;
			}
		}
		
		public ApplicationRequestData()
		{
			descriptorTag = 0;
			descriptorLength = 0;
			protocol = 0;
			version = 0 ;
			count = 0;
			m_appDescInfo = new AppDescInfo[8];
			for (int i = 0; i < 8; i++)
			{
				m_appDescInfo[i] = new AppDescInfo();
			}
		}
	}
	
	
	public ClientSessionSetupRequestBody()
	{
		m_uuDataLength = 0;
		m_privateDataLength = 0; //private data length is 0x56 bytes
		m_protocolID = 0;
		m_version = 0;
		m_descriptorCount = 0;
		m_assetID = new AssetID();
		m_nodeGroupID = new NodeGroupId();
		m_applicationRequestData = new ApplicationRequestData();
	}
}
