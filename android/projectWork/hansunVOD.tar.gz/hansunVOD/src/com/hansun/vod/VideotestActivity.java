package com.hansun.vod;


import java.io.IOException;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
public class VideotestActivity extends Activity implements OnBufferingUpdateListener, 
        OnCompletionListener, MediaPlayer.OnPreparedListener, 
        SurfaceHolder.Callback { 
	private static final String TAG = "HeartBeat";
    private MediaPlayer mediaPlayer; 
    private SurfaceView surfaceView; 
    private SurfaceHolder surfaceHolder; 
    private int videoWidth; 
    private int videoHeight;
    @Override 
    public void onCreate(Bundle savedInstanceState) { 
        super.onCreate(savedInstanceState); 
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
   //     getWindow().getDecorView().setSystemUiVisibility(4);
        setContentView(R.layout.main); 
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
         
        mediaPlayer = new MediaPlayer(); 
        this.surfaceView = (SurfaceView) this.findViewById(R.id.surface); 
        this.surfaceHolder = this.surfaceView.getHolder(); 
        this.surfaceHolder.addCallback(this); 
        this.surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        Log.v("cat", ">>>create ok."); 
    }
    private void playVideo() throws IllegalArgumentException, 
            IllegalStateException, IOException { 
    	 this.mediaPlayer = new MediaPlayer(); 
       // this.mediaPlayer 
         //       .setDataSource("dvb://SymbolRate=6900/Freq=355/QamType=64/videoPid=1112/audioPid=1113/videoType=2/audioType=3/pcrPid=1112 \n"); 
    	 
       
    	 
    	 this.mediaPlayer.setDisplay(this.surfaceHolder); 
        this.mediaPlayer.prepare();
        this.mediaPlayer.prepareAsync();
        this.mediaPlayer.setOnBufferingUpdateListener(this); 
      //  this.mediaPlayer.setOnErrorListener(this);
        this.mediaPlayer.setOnPreparedListener(this); 
        
      
   //     this.mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC); 
       
        Log.i("mplayer", ">>>play video"); 
    }
  
    @Override 
    public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) { 
        Log.i("cat", ">>>surface changed");
    }
    @Override 
    public void surfaceCreated(SurfaceHolder holder) { 
        try { 
            this.playVideo(); 
        } catch (Exception e) { 
            Log.i("cat", ">>>error", e); 
        } 
        Log.i("cat", ">>>surface created");
    }
    @Override 
    public void surfaceDestroyed(SurfaceHolder holder) { 
        Log.v("mplayer", ">>>surface destroyed");
    }
    @Override 
    public void onCompletion(MediaPlayer arg0) { 
        // TODO Auto-generated method stub
    }
    @Override 
    public void onBufferingUpdate(MediaPlayer mp, int percent) { 
        // TODO Auto-generated method stub
    }
    @Override 
    public void onPrepared(MediaPlayer arg0) { 
        this.videoWidth = this.mediaPlayer.getVideoWidth(); 
        this.videoHeight = this.mediaPlayer.getVideoHeight();
        if (this.videoHeight != 0 && this.videoWidth != 0) { 
            this.surfaceHolder.setFixedSize(videoWidth, videoHeight); 
           
            
            Log.v("sk", "sk start \n");
            
        }
      
    } 
    @Override 
    protected void onDestroy() { 
        super.onDestroy(); 
        if (this.mediaPlayer != null) { 
            this.mediaPlayer.release(); 
            this.mediaPlayer = null; 
        } 
    } 
    	public boolean onKeyDown(int keyCode, KeyEvent event)
        {
        	Log.v(TAG, "keyCode = " + keyCode);
        	
        	if(keyCode==KeyEvent.KEYCODE_BACK)
        	{
        		Log.v(TAG, "KeyEvent.KEYCODE_BACK --------");

    			//send the message of stop Player 
    			VodControl.getInstance().setCableMPEGClose();
        		//return true;
        	}
        	
        	return super.onKeyDown(keyCode, event);
        }
    
}