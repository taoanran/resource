package com.hansun.vod;

import android.util.Log;

public class EnReach {
	private final static String TAG = "EnReach";
	
	public EnReach()
	{
		Log.v(TAG, "in the EnReach");
	}
	
	public void ExitBrowser()
	{
		Log.v(TAG, "in the ExitBrowser");
	}
	public void setHighlight(int hightLight)
	{
		Log.v(TAG, "in the setHighlight = " + hightLight);
	}
	public void setHighlightNodeColor(String color)
	{
		Log.v(TAG, "in the setHighlightNodeColor = " + color);
	}
}
