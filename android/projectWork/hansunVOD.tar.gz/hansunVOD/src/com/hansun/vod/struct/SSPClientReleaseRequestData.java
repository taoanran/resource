package com.hansun.vod.struct;

/*
 * name:        SSPClientReleaseRequestData
 * function:    the data of STB client tearDown the SSP connect
 * description: this is a data struct class
 * author:      taoanran
 * time:        2012.11.30
 * */
public class SSPClientReleaseRequestData {
	public DsmccMessageHeader   m_dsmHeader ; 
	public SessionId m_sessionId ; ///set by the Client to the sessionId of the session that the Client is requesting to be torn-down
	public short m_reason ;	   ///set by the Client to indicate the reason that the session is being requested to be torn-down
	//userData
	public UserData m_userData ;
	
	public SSPClientReleaseRequestData()
	{
		m_dsmHeader = new DsmccMessageHeader();
		m_sessionId =  new SessionId();
		m_reason = 0;
		m_userData = new UserData();
	}
}
