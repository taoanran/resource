package com.hansun.vod.struct;

/*
 * name:        DsmccMessageHeader
 * function:    the data of DMSCC message header
 * description: this is a data struct class
 * author:      taoanran
 * time:        2012.11.30
 * */
public class DsmccMessageHeader {
	public byte m_protocolDiscriminator ;
	public byte m_dsmccType ;
	public short m_messageId ;
	public int m_transactionId ;  ///unit32 
	public byte m_reserved ;
	public byte m_adaptationLength ;  ///   DSMCCADAPTIONHEADER
	public short m_messageLength ; 
	public DsmccAdaptationHeader m_DsmccAdaptationHeader ; /// if m_adaptationLength > 0 
	///for ClientSessionSetUpRequest   --- 1
	public class DsmccAdaptationHeader
	{
		byte adaptationType ;//// adaptationDataByte[m_adaptationLength-1]  if  adaptationLength >0
		
		public DsmccAdaptationHeader()
		{
			adaptationType = 0;
		}
	}
	
	public DsmccMessageHeader()
	{
		m_protocolDiscriminator = 0;
		m_dsmccType = 0;
		m_messageId = 0;
		m_transactionId = 0;
		m_reserved = 0 ;
		m_adaptationLength = 0;
		m_adaptationLength = 0;
		m_messageLength = 0;
		m_DsmccAdaptationHeader = new DsmccAdaptationHeader();
	}
}
