package com.hansun.vod.struct;
/*
 * className:   ClientSessionInProgressData 
 * function:    it is the heartBeat's(ssp connect) data
 * description: it is a struct class
 * author:      taoanran
 * createTime:  2012-12-25
 * */
public class ClientSessionInProgressData {
	public DsmccMessageHeader   m_dsmHeader ; 
	public short m_sessionCount ;	
	public SessionId m_sessionId ;	 /// deviceId MAC IP systemTime if m_reserved > 0   
	
	public ClientSessionInProgressData()
	{
		m_dsmHeader = new DsmccMessageHeader();
		m_sessionCount = 0;
		m_sessionId = new SessionId();
	}
}
