package com.hansun.vod;

import java.io.ByteArrayInputStream;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import com.hansun.vod.struct.ClientSessionInProgressData;
import com.hansun.vod.struct.ClientSessionSetupRequestBody;
import com.hansun.vod.struct.DsmccMessageHeader;
import com.hansun.vod.struct.NetFormatTransform;
import com.hansun.vod.struct.SSPClientReleaseRequestData;
import com.hansun.vod.struct.SSPClientSessionSetUpRequest;
import com.hansun.vod.struct.SessionId;
import com.hansun.vod.struct.SetupConfirm;
import com.hansun.vod.struct.SetupConfirm.Ats_info;
import com.hansun.vod.struct.SetupConfirm.Comm_info;
import com.hansun.vod.struct.SetupConfirm.Head_end_info;
import com.hansun.vod.struct.SetupConfirm.Lsc_data;
import com.hansun.vod.struct.SetupConfirm.Lsc_data_des_count;
import com.hansun.vod.struct.SetupConfirm.Mpeg_info;
import com.hansun.vod.struct.SetupConfirm.Ts_info;
import com.hansun.vod.struct.UserData;
import com.hansun.vod.struct.ClientSessionSetupRequestBody.ApplicationRequestData;
import com.hansun.vod.struct.ClientSessionSetupRequestBody.AssetID;
import com.hansun.vod.struct.ClientSessionSetupRequestBody.NodeGroupId;
import com.hansun.vod.struct.ClientSessionSetupRequestBody.ApplicationRequestData.AppDescInfo;
import com.hansun.vod.struct.DsmccMessageHeader.DsmccAdaptationHeader;

import android.util.Log;

/*
 * className:   SSpSocket 
 * function:    ssp connect socket, we use the UDP SOCKET now
 * discription: there is only one activity ssp(udp) socket, so we Definite SSpSocket
 * 				as the singleton class
 * author:      taoanran
 * createTime:  2012-12-11
 * */
public class SSPSocket {
	private static final String TAG = "SSPSocket";

	public interface ssp_msg_type{
		byte	SSP_ClientReleaseRequestData = 0x01,
				SSP_ClientSessionSetUpRequest = 0x02,
				SSP_ClientSessionInProgressData = 0x03;
	};
	private static SSPSocket instance = null;
	public DatagramSocket mSocket = null;
	public SSPClientReleaseRequestData ssp_releaseData_hdr = null;
	
	public static SSPSocket getInstance() {
		if (instance == null)
		{
			instance = new SSPSocket();
		}
		return instance;
	}
	
	private SSPSocket()
	{
		try {
			mSocket = new DatagramSocket();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * communication with server use this
	 * @param cmd
	 * @param ns
	 * @return
	 */
	private synchronized boolean sendMessage(
			byte msg_type, Object message,
			String m_SRMIP, short m_SRMPort)
	{
		Log.v(TAG, "sendMessage ----- IN");
		if (null == message)
		{
			Log.e(TAG, "sendMessage's param == null !!!!!!!!");
			return false;
		}
		
		switch(msg_type)
		{
		case ssp_msg_type.SSP_ClientReleaseRequestData:
			SSPClientReleaseRequestData_hdr sspClientReleaseRequestData_hdr = new SSPClientReleaseRequestData_hdr((SSPClientReleaseRequestData)message);
			if (mSocket != null)
			{
				byte []buf ;
				Log.v(TAG, "sendMessage ----111111- ");
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				try {
					Log.v(TAG, "sendMessage ---22222222-- ");
					sspClientReleaseRequestData_hdr.writeItems(bos);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				buf = bos.toByteArray();
				return DatagramPacket_Send(buf, buf.length, m_SRMIP, m_SRMPort);
			}
			else{
				Log.e(TAG, "sendMessage's mSocket == null");
				return false;
			}			
		case ssp_msg_type.SSP_ClientSessionSetUpRequest:
			SSPClientSessionSetUpRequest_hdr sspClientSessionSetUpRequest_hdr = new SSPClientSessionSetUpRequest_hdr((SSPClientSessionSetUpRequest)message);
			if (mSocket != null)
			{
				byte []buf ;
				Log.v(TAG, "sendMessage ----SSP_ClientSessionSetUpRequest 111111- ");
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				try {
					Log.v(TAG, "sendMessage --SSP_ClientSessionSetUpRequest---22222222-- ");
					sspClientSessionSetUpRequest_hdr.writeItems(bos);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				buf = bos.toByteArray();
				return DatagramPacket_Send(buf, buf.length, m_SRMIP, m_SRMPort);
			}
			else{
				Log.e(TAG, "sendMessage's mSocket == null");
				return false;
			}
		case ssp_msg_type.SSP_ClientSessionInProgressData:
			SSPClientSessionInProgress_hdr sspClientSessionInProgress_hdr = new SSPClientSessionInProgress_hdr((ClientSessionInProgressData)message);
			if (mSocket != null)
			{
				byte []buf ;
				Log.v(TAG, "sendMessage ----SSP_ClientSessionSetUpRequest 111111- ");
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				try {
					Log.v(TAG, "sendMessage --SSP_ClientSessionSetUpRequest---22222222-- ");
					sspClientSessionInProgress_hdr.writeItems(bos);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				buf = bos.toByteArray();
				return DatagramPacket_Send(buf, buf.length, m_SRMIP, m_SRMPort);
			}
			else{
				Log.e(TAG, "sendMessage's mSocket == null");
				return false;
			}
		default:
			return false;
		}
	}
	/**
	 * @function send the ssp Client Release Request to the srm server
	 * @param   SSPClientSessionSetUpRequest // tmp
	 * @param   m_SRMIP //IP
	 * @param   m_SRMIP //port
	 * @return  
	 * 			true  :Send ok
	 * 			false :Send false 
	 * @throws IOException 
	 */
	public boolean ssp_send_sspClientReleaseRequestData(SSPClientReleaseRequestData tmp, String m_SRMIP, short m_SRMPort){
		// TODO Auto-generated method stub
		Log.v(TAG, "ssp_send_sspClientReleaseRequestData ----- IN");
		return sendMessage(ssp_msg_type.SSP_ClientReleaseRequestData, tmp,  m_SRMIP, m_SRMPort);
	}	
	/**
	 * @function send the ssp Client Release Response to the srm server
	 * @description  the formats of ClientReleaseResponseData is equal to the ClientReleaseRequestData 
	 * @param   SSPClientReleaseRequestData // tmp
	 * @param   m_SRMIP //IP
	 * @param   m_SRMPort //port
	 * @return  
	 * 			true  :Send ok
	 * 			false :Send false 
	 * @throws IOException 
	 */
	public boolean ssp_send_sspClientReleaseResponseData(
			SSPClientReleaseRequestData tmp,
			String m_SRMIP, short m_SRMPort) {
		// TODO Auto-generated method stub
		//the formats of ClientReleaseResponseData is equal to the ClientReleaseRequestData 
		return sendMessage(ssp_msg_type.SSP_ClientReleaseRequestData, tmp,  m_SRMIP, m_SRMPort);
	};
	
	/**
	 * @function send the ssp connect Request to the srm server
	 * @param   tmp // SSP Client Session SetUp Request
	 * @param   m_SRMIP //IP
	 * @param   m_SRMIP //port
	 * @return  
	 * 			true  :Send ok
	 * 			false :Send false 
	 * @throws IOException 
	 */
	public boolean ssp_send_ClientSessionSetUpRequestData(SSPClientSessionSetUpRequest tmp, String m_SRMIP, short m_SRMPort){
		// TODO Auto-generated method stub
		Log.v(TAG, "ssp_send_ClientSessionSetUpRequestData ----- IN");
		return sendMessage(ssp_msg_type.SSP_ClientSessionSetUpRequest, tmp,  m_SRMIP, m_SRMPort);
	}
	/**
	 * @function send the ClientSessionInProgress(heartBeat) to the srm server
	 * @param   tmp // tmpClientSessionInProgressData
	 * @param   m_SRMIP //IP
	 * @param   m_SRMIP //port
	 * @return  
	 * 			true  :Send ok
	 * 			false :Send false 
	 * @throws IOException 
	 */
	public boolean ssp_send_ClientSessionInProgress(
			ClientSessionInProgressData tmpClientSessionInProgressData,
			String m_SRMIpAddress, short m_SRMPort) {

		// TODO Auto-generated method stub
		Log.v(TAG, "ssp_send_ClientSessionInProgress ----- IN");
		return sendMessage(ssp_msg_type.SSP_ClientSessionInProgressData, tmpClientSessionInProgressData,  m_SRMIpAddress, m_SRMPort);
	}
	/**
	 * 
	 * @param   buf[] //send buf 
	 * @param   m_SRMIP //IP
	 * @param   m_SRMIP //port
	 * @return  
	 * 			true  :Send ok
	 * 			false :Send false 
	 * @throws IOException 
	 */
	private boolean DatagramPacket_Send(byte []buf, int lenth, String m_SRMIP, short m_SRMPort){
		// TODO Auto-generated method stub
		Log.v(TAG, "DatagramPacket_Send ---1111111-- ");
		if (buf == null || m_SRMIP == null || m_SRMPort < 0 )
		{
			Log.e(TAG, "DatagramPacket_Send's packege or mSocket is null, or port < 0");
			return false;
		}
		DatagramPacket sendPacket = null;
		InetAddress addr = null;
		try {
			Log.v(TAG, "DatagramPacket_Send ---2222222-- ");
			addr = InetAddress.getByName(m_SRMIP);
		} catch (UnknownHostException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		Log.v(TAG, "DatagramPacket_Send m_SRMIP =  " + m_SRMIP );
		Log.v(TAG, "DatagramPacket_Send port =  " + m_SRMPort );
		if (addr == null)
		{
			Log.e(TAG, "addr == NULL");
			return false;
		}
		sendPacket = new DatagramPacket(buf, lenth, addr, m_SRMPort);
		Log.v(TAG, "DatagramPacket_Send ---333333333-- ");
		try {
			mSocket.send(sendPacket);
			
			Log.v(TAG, "we send to the server----------taoanran add");
			for (int i=0; i<lenth; i++)
			{
				Log.v(TAG, "send: " + buf[i]);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		Log.v(TAG, "send END =-----------------------lenth = " + lenth);
		return true;
	}
	/**
	 * 
	 * @param   packege // DatagramPacket
	 * @return  
	 * 			true  :Recieve ok
	 * 			false :Recieve false 
	 * @throws IOException 
	 */
	public boolean DatagramPacket_Recieve(DatagramPacket packege){
		// TODO Auto-generated method stub
		
		if (packege == null || mSocket == null)
		{
			Log.e(TAG, "DatagramPacket_Send's packege or mSocket is null");
			return false;
		}
		
		try {
			mSocket.receive(packege); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		return true;
	}
	
	public class SSPClientReleaseRequestData_hdr implements NetWorkStruct{
		SSPClientReleaseRequestData m_data = null;
		public SSPClientReleaseRequestData_hdr() {
			this.m_data = new SSPClientReleaseRequestData();
		}
		public SSPClientReleaseRequestData_hdr(SSPClientReleaseRequestData data) {
			this.m_data = data;
		}
		/**
		 * write data to network
		 * @param bos
		 * @throws IOException
		 */
		public void writeItems(OutputStream bos) throws IOException {
	        DataOutputStream dps = new DataOutputStream(bos);
	        Log.v(TAG, "writeItems ---11111111-- ");
	        // dsmHeader -------------------------------------------------------
	    	dps.writeByte(this.m_data.m_dsmHeader.m_protocolDiscriminator);
	    	dps.writeByte(this.m_data.m_dsmHeader.m_dsmccType);
	    	dps.writeShort(this.m_data.m_dsmHeader.m_messageId);
	    	dps.writeInt(this.m_data.m_dsmHeader.m_transactionId);
	    	dps.writeByte(this.m_data.m_dsmHeader.m_reserved);
	    	dps.writeByte(this.m_data.m_dsmHeader.m_adaptationLength);
	    	dps.writeShort(this.m_data.m_dsmHeader.m_messageLength);
	    	/*
	    	 * DsmccAdaptationHeader not fill into the header, beacause
	    	 * the DsmccAdaptationHeader always empty 
	    	 * */
	    	
	    	// SessionId -------------------------------------------------------
	    	dps.writeInt(this.m_data.m_sessionId.sysTime);
	    	Log.v(TAG, "m_data.m_sessionId.mac.lenth = " + m_data.m_sessionId.mac.length);
	    	dps.write(this.m_data.m_sessionId.mac);
	    	// m_reason -------------------------------------------------------
	    	dps.writeShort(this.m_data.m_reason);
	    	// UserData ----------------------------------------------
	    	dps.writeShort(this.m_data.m_userData.m_uuDataLength);
	    	dps.write(this.m_data.m_userData.m_uuDataByte);
	    	dps.writeShort(this.m_data.m_userData.m_privateDataLength);
	    	dps.write(this.m_data.m_userData.m_privateDataByte);
	 /*   	
	    	Log.v(TAG, "writeItems m_protocolDiscriminator = " + m_data.m_dsmHeader.m_protocolDiscriminator);
	    	Log.v(TAG, "writeItems m_dsmccType = " + m_data.m_dsmHeader.m_dsmccType);
	    	Log.v(TAG, "writeItems m_messageId = " + m_data.m_dsmHeader.m_messageId);
	    	Log.v(TAG, "writeItems m_transactionId = " + m_data.m_dsmHeader.m_transactionId);
	    	Log.v(TAG, "writeItems m_reserved = " + m_data.m_dsmHeader.m_reserved);
	    	Log.v(TAG, "writeItems m_adaptationLength = " + m_data.m_dsmHeader.m_adaptationLength);
	    	Log.v(TAG, "writeItems m_messageLength = " + m_data.m_dsmHeader.m_messageLength);
	    	
	    	Log.v(TAG, "writeItems m_data.m_sessionId.sysTime = " + m_data.m_sessionId.sysTime);
	    	for (int i=0; i<6; i++)
    		{
	    		Log.v(TAG, "writeItems m_data.m_sessionId.mac = " + m_data.m_sessionId.mac[i]);
    		}
	    	Log.v(TAG, "writeItems m_data.m_reason = " + m_data.m_reason);
	    	Log.v(TAG, "writeItems m_data.m_userData.m_uuDataLength = " + m_data.m_userData.m_uuDataLength);
	    	Log.v(TAG, "writeItems m_data.m_userData.m_privateDataLength = " + m_data.m_userData.m_privateDataLength);
	   */
	        dps.close();
		}
		@Override
		public void readItems(InputStream is, int offset) throws IOException {
			// TODO Auto-generated method stub
			// dsmHeader -------------------------------------------------------
			Log.v(TAG, "readItems ----------------------- ");
			if (m_data == null)
			{
				Log.v(TAG, "m_data is null");
				return;
			}
			is.skip(offset);
			if (m_data.m_dsmHeader == null)
			{
				m_data.m_dsmHeader = new DsmccMessageHeader();
			}
			m_data.m_dsmHeader.m_protocolDiscriminator = (byte) is.read();
			m_data.m_dsmHeader.m_dsmccType = (byte) is.read();
			
			byte []buf = new byte[4];
			is.read(buf, 0, 4);		
			m_data.m_dsmHeader.m_messageId = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
			//m_data.m_dsmHeader.m_messageId = (short) is.read();
			m_data.m_dsmHeader.m_transactionId = is.read();
			m_data.m_dsmHeader.m_reserved = (byte) is.read();
			m_data.m_dsmHeader.m_adaptationLength = (byte) is.read();
			
			buf = new byte[2];
			is.read(buf, 0, 2);		
			m_data.m_dsmHeader.m_messageLength = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
			//m_data.m_dsmHeader.m_messageLength = (short) is.read();
/*			
			Log.v(TAG, "readItems m_protocolDiscriminator = "
				+m_data.m_dsmHeader.m_protocolDiscriminator);
			Log.v(TAG, "readItems m_dsmccType = "
				+m_data.m_dsmHeader.m_dsmccType);	
			Log.v(TAG, "readItems m_messageId = "
				+m_data.m_dsmHeader.m_messageId);	
			Log.v(TAG, "readItems m_transactionId = "
				+m_data.m_dsmHeader.m_transactionId);
			Log.v(TAG, "readItems m_reserved = "
				+m_data.m_dsmHeader.m_reserved);	
			Log.v(TAG, "readItems m_adaptationLength = "
				+m_data.m_dsmHeader.m_adaptationLength);	
	*/
	}
	};
	
	public class SSPClientSessionSetUpRequest_hdr implements NetWorkStruct{
		SSPClientSessionSetUpRequest m_data = null;
		public SSPClientSessionSetUpRequest_hdr() {
			this.m_data = new SSPClientSessionSetUpRequest();
		}
		public SSPClientSessionSetUpRequest_hdr(SSPClientSessionSetUpRequest data) {
			this.m_data = data;
		}
		/**
		 * write data to network
		 * @param bos
		 * @throws IOException
		 */
		public void writeItems(OutputStream bos) throws IOException {
	        DataOutputStream dps = new DataOutputStream(bos);
	        Log.v(TAG, "writeItems ---11111111-- ");
	        // dsmHeader -------------------------------------------------------
	    	dps.writeByte(this.m_data.m_dsmHeader.m_protocolDiscriminator);
	    	dps.writeByte(this.m_data.m_dsmHeader.m_dsmccType);
	    	dps.writeShort(this.m_data.m_dsmHeader.m_messageId);
	    	dps.writeInt(this.m_data.m_dsmHeader.m_transactionId);
	    	dps.writeByte(this.m_data.m_dsmHeader.m_reserved);
	    	dps.writeByte(this.m_data.m_dsmHeader.m_adaptationLength);
	    	dps.writeShort(this.m_data.m_dsmHeader.m_messageLength);
	    	/*
	    	 * DsmccAdaptationHeader not fill into the header, beacause
	    	 * the DsmccAdaptationHeader always empty 
	    	 * */
	    	
	    	// SessionId -------------------------------------------------------
	    	dps.writeInt(this.m_data.m_sessionId.sysTime);
	    	dps.write(this.m_data.m_sessionId.mac);
	    	// m_reserved -------------------------------------------------------
	    	dps.writeShort(this.m_data.m_reserved);
	    	// m_clientId ----------------------------------------------
	    	dps.writeByte(m_data.m_clientId.afi);
	    	dps.write(m_data.m_clientId.idi);
	    	dps.writeInt(m_data.m_clientId.dsp);
	    	dps.write(m_data.m_clientId.mac);
	    	dps.writeByte(m_data.m_clientId.sel);
	    	// m_serverId ----------------------------------------------
	    	dps.writeByte(m_data.m_serverId.afi);
	    	dps.write(m_data.m_serverId.idi);
	    	dps.writeInt(m_data.m_serverId.dsp);
	    	dps.write(m_data.m_serverId.mac);
	    	dps.writeByte(m_data.m_serverId.sel);
	    	// UserData 1.----------------------------------------------
	    	dps.writeShort(this.m_data.m_userData.m_uuDataLength);
	    	dps.writeShort(this.m_data.m_userData.m_privateDataLength);
	    	dps.writeByte(this.m_data.m_userData.m_protocolID);
	    	dps.writeByte(this.m_data.m_userData.m_version);
	    	dps.writeByte(this.m_data.m_userData.m_descriptorCount);

	        //userData 2.assetID --------------------
	    	dps.writeByte(this.m_data.m_userData.m_assetID.tag);
	    	dps.writeByte(this.m_data.m_userData.m_assetID.datelength);
	    /*	
	    	byte []assetId_data = new byte[1024];
			byte tmpbyte1 = 0;
			byte tmpbyte2 = 0;
			Log.v(TAG, "m_data.m_userData.m_assetID.data.length() 111= " + m_data.m_userData.m_assetID.data.length());
			if (m_data.m_userData.m_assetID.data.length()%2 == 1)
			{
				String tmpString = "0"+ m_data.m_userData.m_assetID.data;
				m_data.m_userData.m_assetID.data = tmpString;
			}
			
			Log.v(TAG, "m_data.m_userData.m_assetID.data.length() 222= " + m_data.m_userData.m_assetID.data.length());
		*/
			
			byte tmpbyte1 ;
			byte tmpbyte2 ;
			byte []assetId_data = new byte[1024];
			
			for (int i=0, j=0; i<m_data.m_userData.m_assetID.data.length(); i += 2, j++)
			{	
				tmpbyte1 = (byte) m_data.m_userData.m_assetID.data.charAt(i);
				tmpbyte2 = (byte) m_data.m_userData.m_assetID.data.charAt(i+1);
				if (tmpbyte1 >= '0' && tmpbyte1 <= '9')
				{
					//System.out.print((byte)(tmpbyte1 - '0') + "\n");
					tmpbyte1 = (byte) (tmpbyte1 - '0');
				}
				else
				{
					//System.out.print((byte)(tmpbyte1 - 'a' + 10)+ "\n");
					tmpbyte1 = (byte)(tmpbyte1 - 'a' + 10);
				}
				
				if (tmpbyte2 >= '0' && tmpbyte2 <= '9')
				{
					tmpbyte2 = (byte) (tmpbyte2 - '0');
					//System.out.print((byte)(tmpbyte2 - '0') + "\n");
				}
				else
				{
					tmpbyte2 = (byte)(tmpbyte2 - 'a' + 10);
					//System.out.print((byte)(tmpbyte2 - 'a' + 10)+ "\n");
				}
				
				assetId_data[j] = (byte) ((tmpbyte1 *16) + tmpbyte2);
				Log.v(TAG, "assetId_data[j] = " + assetId_data[j]);
				//System.out.print("tmpByte = "+ tmpByte + "\n");
			}
			Log.v(TAG, "@@@@@@@@@@@@@@@@@");
			Log.v(TAG, "m_data.m_userData.m_assetID.data.length() = " + m_data.m_userData.m_assetID.data.length());
			Log.v(TAG, "m_data.m_userData.m_assetID.datelength = " + m_data.m_userData.m_assetID.datelength);
	    	dps.write(assetId_data, 0, m_data.m_userData.m_assetID.data.length()/2);
	        //userData 3.groupID -------------------------
	    	dps.writeByte(this.m_data.m_userData.m_nodeGroupID.tag);
	    	dps.writeByte(this.m_data.m_userData.m_nodeGroupID.datelength);
	    	dps.write(this.m_data.m_userData.m_nodeGroupID.data);
	    	//AppRequestData
	    	dps.writeByte(this.m_data.m_userData.m_applicationRequestData.descriptorTag);
	    	dps.writeByte(this.m_data.m_userData.m_applicationRequestData.descriptorLength);
	    	dps.writeByte(this.m_data.m_userData.m_applicationRequestData.protocol);
	    	dps.writeByte(this.m_data.m_userData.m_applicationRequestData.version);
	    	dps.writeByte(this.m_data.m_userData.m_applicationRequestData.count);
	    	for (int i=0; i<8; i++)
	    	{
	    		dps.writeByte(this.m_data.m_userData.m_applicationRequestData.m_appDescInfo[i].appDescTag);
	    		dps.writeByte(this.m_data.m_userData.m_applicationRequestData.m_appDescInfo[i].appDescLength);
	    		dps.writeInt(this.m_data.m_userData.m_applicationRequestData.m_appDescInfo[i].appDescdata);
	    	}
	    	
	    /*	
	    	Log.v(TAG, "writeItems m_protocolDiscriminator = " + m_data.m_dsmHeader.m_protocolDiscriminator);
	    	Log.v(TAG, "writeItems m_dsmccType = " + m_data.m_dsmHeader.m_dsmccType);
	    	Log.v(TAG, "writeItems m_messageId = " + m_data.m_dsmHeader.m_messageId);
	    	Log.v(TAG, "writeItems m_transactionId = " + m_data.m_dsmHeader.m_transactionId);
	    	Log.v(TAG, "writeItems m_reserved = " + m_data.m_dsmHeader.m_reserved);
	    	Log.v(TAG, "writeItems m_adaptationLength = " + m_data.m_dsmHeader.m_adaptationLength);
	    	Log.v(TAG, "writeItems m_messageLength = " + m_data.m_dsmHeader.m_messageLength);
	    	
	    	Log.v(TAG, "writeItems m_data.m_sessionId.sysTime = " + m_data.m_sessionId.sysTime);
	    	for (int i=0; i<6; i++)
    		{
	    		Log.v(TAG, "writeItems m_data.m_sessionId.mac = " + m_data.m_sessionId.mac[i]);
    		}
	    	Log.v(TAG, "writeItems m_data.m_reason = " + m_data.m_reserved);
	    	Log.v(TAG, "writeItems m_data.m_userData.m_uuDataLength = " + m_data.m_userData.m_uuDataLength);
	    	Log.v(TAG, "writeItems m_data.m_userData.m_privateDataLength = " + m_data.m_userData.m_privateDataLength);
	   
	    	Log.v(TAG, "writeItems m_data.m_clientId.afi = " + m_data.m_clientId.afi);
	    	Log.v(TAG, "writeItems m_data.m_clientId.dsp = " + m_data.m_clientId.dsp);
	    	Log.v(TAG, "writeItems m_data.m_clientId.sel = " + m_data.m_clientId.sel);
	    	for (int i=0; i<8; i++)
	    	{
	    		Log.v(TAG, "writeItems m_data.m_clientId.idi = " + m_data.m_clientId.idi[i]);
	    	}
	    	for (int i=0; i<6; i++)
	    	{
	    		Log.v(TAG, "writeItems m_data.m_clientId.mac = " + m_data.m_clientId.mac[i]);	    	
	    	}
	    */
	    	Log.v(TAG, "writeItems m_data.m_serverId.dsp(gateway) = " + m_data.m_serverId.dsp);
	    	
	        dps.close();
		}
		@Override
		public void readItems(InputStream is, int offset) throws IOException {
			// TODO Auto-generated method stub
			// dsmHeader -------------------------------------------------------
			Log.v(TAG, "readItems ----------------------- ");
			if (m_data == null)
			{
				Log.v(TAG, "m_data is null");
				return;
			}
			is.skip(offset);
			if (m_data.m_dsmHeader == null)
			{
				m_data.m_dsmHeader = new DsmccMessageHeader();
			}
			m_data.m_dsmHeader.m_protocolDiscriminator = (byte) is.read();
			m_data.m_dsmHeader.m_dsmccType = (byte) is.read();
			
			byte []buf = new byte[4];
			is.read(buf, 0, 4);
			m_data.m_dsmHeader.m_messageId = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
			//m_data.m_dsmHeader.m_messageId = (short) is.read();
			m_data.m_dsmHeader.m_transactionId = is.read();
			m_data.m_dsmHeader.m_reserved = (byte) is.read();
			m_data.m_dsmHeader.m_adaptationLength = (byte) is.read();
			
			buf = new byte[2];
			is.read(buf, 0, 2);		
			m_data.m_dsmHeader.m_messageLength = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
			//m_data.m_dsmHeader.m_messageLength = (short) is.read();
/*			
			Log.v(TAG, "readItems m_protocolDiscriminator = "
				+m_data.m_dsmHeader.m_protocolDiscriminator);
			Log.v(TAG, "readItems m_dsmccType = "
				+m_data.m_dsmHeader.m_dsmccType);	
			Log.v(TAG, "readItems m_messageId = "
				+m_data.m_dsmHeader.m_messageId);	
			Log.v(TAG, "readItems m_transactionId = "
				+m_data.m_dsmHeader.m_transactionId);
			Log.v(TAG, "readItems m_reserved = "
				+m_data.m_dsmHeader.m_reserved);	
			Log.v(TAG, "readItems m_adaptationLength = "
				+m_data.m_dsmHeader.m_adaptationLength);	
	*/
	}
	}
	
	/*
	 * read the DsmccMessageHeader's data
	 * */
	public class DsmccMessageHeader_hdr implements NetWorkStruct{
		public DsmccMessageHeader m_dsmccMessageHeader = null;
		public DsmccMessageHeader_hdr() {
			this.m_dsmccMessageHeader = new DsmccMessageHeader();
		}
		public DsmccMessageHeader_hdr(DsmccMessageHeader data) {
			this.m_dsmccMessageHeader = data;
		}
		
		public void readItems(InputStream is, int offset) throws IOException {
			// TODO Auto-generated method stub
			// dsmHeader -------------------------------------------------------
			Log.v(TAG, "readItems ----------------------- ");
			if (m_dsmccMessageHeader == null)
			{
				Log.v(TAG, "m_data is null");
				return;
			}
			
			is.skip(offset);
			m_dsmccMessageHeader.m_protocolDiscriminator = (byte) is.read();
			m_dsmccMessageHeader.m_dsmccType = (byte) is.read();
			
			byte []buf = new byte[4];
			is.read(buf, 0, 2);
			m_dsmccMessageHeader.m_messageId = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
			is.read(buf, 0, 4);
			m_dsmccMessageHeader.m_transactionId = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
			m_dsmccMessageHeader.m_reserved = (byte) is.read();
			m_dsmccMessageHeader.m_adaptationLength = (byte) is.read();
			
			
			Log.v(TAG, "readItems m_protocolDiscriminator = " 
					+ m_dsmccMessageHeader.m_protocolDiscriminator);
			Log.v(TAG, "readItems m_dsmccType = " 
					+ m_dsmccMessageHeader.m_dsmccType);	
			Log.v(TAG, "readItems m_messageId = " 
					+ m_dsmccMessageHeader.m_messageId);	
			Log.v(TAG, "readItems m_transactionId = " 
					+ m_dsmccMessageHeader.m_transactionId);
			Log.v(TAG, "readItems m_reserved = " 
					+ m_dsmccMessageHeader.m_reserved);	
			Log.v(TAG, "readItems m_adaptationLength = " 
					+ m_dsmccMessageHeader.m_adaptationLength);	
	
	}
		@Override
		public void writeItems(OutputStream bos) throws IOException {
			// TODO Auto-generated method stub
			
		}
	}
		
		/*
		 * read the Ether_info data(in the parse_sc)
		 * */
		public class EtherInfo_hdr implements NetWorkStruct{
			public SetupConfirm.Eri_info m_eri_info = null;
			public EtherInfo_hdr() {
				SetupConfirm m_setupConfirm = new SetupConfirm();
				m_eri_info = m_setupConfirm.E_info;
			}
			public EtherInfo_hdr(SetupConfirm.Eri_info data) {
				m_eri_info = data;
			}
			
			public void readItems(InputStream is, int offset) throws IOException {
				// TODO Auto-generated method stub
				// dsmHeader -------------------------------------------------------
				Log.v(TAG, "readItems ----------------------- ");
				if (m_eri_info == null)
				{
					Log.v(TAG, "m_eri_info is null");
					return;
				}
				
				is.skip(offset);
				byte []buf = new byte[4];
				is.read(buf, 0, 2);
				m_eri_info.resource_request_id = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_eri_info.resource_des_type = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_eri_info.resource_num = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_eri_info.assi_tag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_eri_info.resource_flag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_eri_info.resource_status = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_eri_info.resource_field_len = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_eri_info.resource_count = new DataInputStream(new ByteArrayInputStream(buf)).readShort();		
				
				
				buf = new byte[4];
				//there is '00 02 00 01' behind the sourcePort, will be jump !!!!!
				is.read(buf, 0, 4);
				//this is the true source_port!!
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_eri_info.source_port = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				
				//there is '00 02 00 01' behind the source_ip, will be jump !!!!!
				buf = new byte[4];
				is.read(buf, 0, 4);
				//this is the true source_ip!!
				buf = new byte[4];
				is.read(buf, 0, 4);
				m_eri_info.source_ip = new DataInputStream(new ByteArrayInputStream(buf)).readInt();	
				
				//there is '00 02 00 01' and sourceMacAddr(6byte),we don't use it , so we jumped !!!!!
				buf = new byte[10];
				is.read(buf, 0, 10);
				
				//there is '00 02 00 01' behind the dst_port, will be jump !!!!!
				buf = new byte[4];
				is.read(buf, 0, 4);
				////this is the true dst_port!!
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_eri_info.dst_port = new DataInputStream(new ByteArrayInputStream(buf)).readShort();	
				
				//there is '00 02 00 01' behind the dst_ip, will be jump !!!!!
				buf = new byte[4];
				is.read(buf, 0, 4);
				////this is the true dst_ip!!
				buf = new byte[4];
				is.read(buf, 0, 4);
				m_eri_info.dst_ip = new DataInputStream(new ByteArrayInputStream(buf)).readInt();	
				
				Log.v(TAG, "readItems m_eri_info.resource_request_id = " 
						+ m_eri_info.resource_request_id);
				Log.v(TAG, "readItems m_eri_info.resource_des_type = " 
						+ m_eri_info.resource_des_type);	
				Log.v(TAG, "readItems m_eri_info.resource_num = " 
						+ m_eri_info.resource_num);	
				Log.v(TAG, "readItems m_eri_info.assi_tag = " 
						+ m_eri_info.assi_tag);
				Log.v(TAG, "readItems m_eri_info.resource_flag = " 
						+ m_eri_info.resource_flag);	
				Log.v(TAG, "readItems m_eri_info.resource_status = " 
						+ m_eri_info.resource_status);	
				Log.v(TAG, "readItems m_eri_info.resource_field_len = " 
						+ m_eri_info.resource_field_len);	
				
				Log.v(TAG, "readItems m_eri_info.resource_count = " 
						+ m_eri_info.resource_count);
				Log.v(TAG, "readItems m_eri_info.source_port = " 
						+ m_eri_info.source_port);	
				Log.v(TAG, "readItems m_eri_info.source_ip = " 
						+ m_eri_info.source_ip);	
				Log.v(TAG, "readItems m_eri_info.dst_port = " 
						+ m_eri_info.dst_port);
				Log.v(TAG, "readItems m_eri_info.dst_ip = " 
						+ m_eri_info.dst_ip);
		}
			@Override
			public void writeItems(OutputStream bos) throws IOException {
				// TODO Auto-generated method stub
				
			}
	}
		
		/*
		 * read the MpegInfo_hdr data(in the parse_sc)
		 * */
		public class MpegInfo_hdr implements NetWorkStruct{
			public Mpeg_info m_mpeg_info = null;
			public MpegInfo_hdr() {
				SetupConfirm m_setupConfirm = new SetupConfirm();
				m_mpeg_info = m_setupConfirm.M_info;
			}
			public MpegInfo_hdr(SetupConfirm.Mpeg_info data) {
				m_mpeg_info = data;
			}
			
			public void readItems(InputStream is, int offset) throws IOException {
				// TODO Auto-generated method stub
				// dsmHeader -------------------------------------------------------
				Log.v(TAG, "readItems ----------------------- ");
				if (m_mpeg_info == null)
				{
					Log.v(TAG, "m_mpeg_info is null");
					return;
				}
				
				is.skip(offset);
				byte []buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.resource_request_id = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.resource_des_type = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.resource_num = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.assi_tag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.resource_flag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_mpeg_info.resource_status = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_mpeg_info.resource_field_len = new DataInputStream(new ByteArrayInputStream(buf)).readByte();	
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.resource_count = new DataInputStream(new ByteArrayInputStream(buf)).readShort();		
				
				//there is '00 01' before the mpegProgramNum, so we will jump it !!!!
				buf = new byte[4];
				is.read(buf, 0, 2);
				//this is the true mpegProgramNum
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.mpeg_num = new DataInputStream(new ByteArrayInputStream(buf)).readShort();	
				
				//there is '00 01' before the mpeg_pmt_pid, so we will jump it !!!!
				buf = new byte[4];
				is.read(buf, 0, 2);
				//this is the true mpeg_pmt_pid
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.mpeg_pmt_pid = new DataInputStream(new ByteArrayInputStream(buf)).readShort();	
				
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.mpeg_ca_pid = new DataInputStream(new ByteArrayInputStream(buf)).readShort();	
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.stream_count = new DataInputStream(new ByteArrayInputStream(buf)).readShort();	
				
				//there is '00 01' before the mpeg_pcr, so we will jump it !!!!
				buf = new byte[4];
				is.read(buf, 0, 2);
				//this is the true mpeg_pmt_pid
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_mpeg_info.mpeg_pcr = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				
				Log.v(TAG, "readItems m_mpeg_info.resource_request_id = " 
						+ Integer.toHexString(m_mpeg_info.resource_request_id));
				Log.v(TAG, "readItems m_mpeg_info.resource_des_type = " 
						+ Integer.toHexString(m_mpeg_info.resource_des_type));	
				Log.v(TAG, "readItems m_mpeg_info.resource_num = " 
						+ Integer.toHexString(m_mpeg_info.resource_num));	
				Log.v(TAG, "readItems m_mpeg_info.assi_tag = " 
						+ Integer.toHexString(m_mpeg_info.assi_tag));
				Log.v(TAG, "readItems m_mpeg_info.resource_flag = " 
						+ Integer.toHexString(m_mpeg_info.resource_flag));	
				Log.v(TAG, "readItems m_mpeg_info.resource_status = " 
						+ Integer.toHexString(m_mpeg_info.resource_status));	
				Log.v(TAG, "readItems m_mpeg_info.resource_field_len = " 
						+ Integer.toHexString(m_mpeg_info.resource_field_len));	
				
				Log.v(TAG, "readItems m_mpeg_info.resource_request_id = " 
						+ Integer.toHexString(m_mpeg_info.resource_request_id));
				Log.v(TAG, "readItems m_mpeg_info.resource_des_type = " 
						+ Integer.toHexString(m_mpeg_info.resource_des_type));	
				Log.v(TAG, "readItems m_mpeg_info.resource_num = " 
						+ Integer.toHexString(m_mpeg_info.resource_num));	
				Log.v(TAG, "readItems m_mpeg_info.assi_tag = " 
						+ Integer.toHexString(m_mpeg_info.assi_tag));
				Log.v(TAG, "readItems m_mpeg_info.resource_flag = " 
						+ Integer.toHexString(m_mpeg_info.resource_flag));	
				Log.v(TAG, "readItems m_mpeg_info.resource_status = " 
						+ Integer.toHexString(m_mpeg_info.resource_status));	
				Log.v(TAG, "readItems m_mpeg_info.resource_field_len = " 
						+ Integer.toHexString(m_mpeg_info.resource_field_len));	
				Log.v(TAG, "readItems m_mpeg_info.mpeg_num = " 
						+ Integer.toHexString(m_mpeg_info.mpeg_num));	
		}
			@Override
			public void writeItems(OutputStream bos) throws IOException {
				// TODO Auto-generated method stub
				
			}
	}
		
		/*
		 * read the Head_hdr data(in the parse_sc)
		 * */
		public class Head_hdr implements NetWorkStruct{
			public Head_end_info m_head_end_info = null;
			public Head_hdr() {
				SetupConfirm m_setupConfirm = new SetupConfirm();
				m_head_end_info = m_setupConfirm.H_info;
			}
			public Head_hdr(SetupConfirm.Head_end_info data) {
				m_head_end_info = data;
			}
			
			public void readItems(InputStream is, int offset) throws IOException {
				// TODO Auto-generated method stub
				// dsmHeader -------------------------------------------------------
				Log.v(TAG, "readItems ----------------------- ");
				if (m_head_end_info == null)
				{
					Log.v(TAG, "m_head_end_info is null");
					return;
				}
				
				is.skip(offset);
				byte []buf = new byte[4];
				is.read(buf, 0, 2);
				m_head_end_info.resource_request_id = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_head_end_info.resource_des_type = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_head_end_info.resource_num = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_head_end_info.assi_tag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_head_end_info.resource_flag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_head_end_info.resource_status = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_head_end_info.resource_field_len = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_head_end_info.resource_count = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_head_end_info.head_end_flag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_head_end_info.hei.afi = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				
				is.read(m_head_end_info.hei.idi, 0, 8);
				buf = new byte[4];
				is.read(buf, 0, 4);
				m_head_end_info.hei.dsp = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
				is.read(m_head_end_info.hei.esi, 0, 6);
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_head_end_info.hei.sel = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				
				//there is '00 00' before the transport_stream_id, so we will jump it !!!
				buf = new byte[4];
				is.read(buf, 0, 2);
				//this is the true transport_stream_id
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_head_end_info.transport_stream_id = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				
				Log.v(TAG, "readItems m_head_end_info.resource_request_id = " 
						+ Integer.toHexString(m_head_end_info.resource_request_id));
				Log.v(TAG, "readItems m_head_end_info.resource_des_type = " 
						+ Integer.toHexString(m_head_end_info.resource_des_type));	
				Log.v(TAG, "readItems m_head_end_info.resource_num = " 
						+ Integer.toHexString(m_head_end_info.resource_num));	
				Log.v(TAG, "readItems m_head_end_info.assi_tag = " 
						+ Integer.toHexString(m_head_end_info.assi_tag));
				Log.v(TAG, "readItems m_head_end_info.resource_flag = " 
						+ Integer.toHexString(m_head_end_info.resource_flag));	
				Log.v(TAG, "readItems m_head_end_info.resource_status = " 
						+ Integer.toHexString(m_head_end_info.resource_status));
				Log.v(TAG, "readItems m_head_end_info.resource_field_len = " 
						+ Integer.toHexString(m_head_end_info.resource_field_len));
				Log.v(TAG, "readItems m_head_end_info.resource_count = " 
						+ Integer.toHexString(m_head_end_info.resource_count));
				Log.v(TAG, "readItems m_head_end_info.head_end_flag = " 
						+ Integer.toHexString(m_head_end_info.head_end_flag));
				
				Log.v(TAG, "readItems m_head_end_info.hei.afi = " 
						+ Integer.toHexString(m_head_end_info.hei.afi));
				for (int i=0; i<8; i++)
				{
					Log.v(TAG, "readItems m_head_end_info.hei.idi = " 
						+ m_head_end_info.hei.idi[i]);
				}
				Log.v(TAG, "readItems m_head_end_info.hei.dsp = " 
						+ Integer.toHexString(m_head_end_info.hei.dsp));
				for (int i=0; i<6; i++)
				{
					Log.v(TAG, "readItems m_head_end_info.hei.esi = " 
						+ m_head_end_info.hei.esi[i]);
				}
				Log.v(TAG, "readItems m_head_end_info.hei.sel = " 
						+ Integer.toHexString(m_head_end_info.hei.sel));
				
				Log.v(TAG, "readItems m_head_end_info.transport_stream_id = " 
						+ Integer.toHexString(m_head_end_info.transport_stream_id));
		}
			@Override
			public void writeItems(OutputStream bos) throws IOException {
				// TODO Auto-generated method stub
				
			}
	}
		
		/*
		 * read the Ts_hdr data(in the parse_sc)
		 * */
		public class Ts_hdr implements NetWorkStruct{
			public Ts_info m_ts_info = null;
			public Ts_hdr() {
				SetupConfirm m_setupConfirm = new SetupConfirm();
				m_ts_info = m_setupConfirm.T_info;
			}
			public Ts_hdr(SetupConfirm.Ts_info data) {
				m_ts_info = data;
			}
			
			public void readItems(InputStream is, int offset) throws IOException {
				// TODO Auto-generated method stub
				// dsmHeader -------------------------------------------------------
				Log.v(TAG, "readItems ----------------------- ");
				if (m_ts_info == null)
				{
					Log.v(TAG, "m_ts_info is null");
					return;
				}
				
				is.skip(offset);
				byte []buf = new byte[4];
				is.read(buf, 0, 2);
				m_ts_info.resource_request_id = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_ts_info.resource_des_type = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_ts_info.resource_num = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_ts_info.assi_tag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_ts_info.resource_flag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ts_info.resource_status = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ts_info.resource_field_len = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
			
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_ts_info.resource_count = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				
				//there is '00 01' before the downstreamBandwith, so we will jump it !!
				buf = new byte[4];
				is.read(buf, 0, 2);
				//this is the true downstreamBandwith
				buf = new byte[4];
				is.read(buf, 0, 4);
				m_ts_info.bandwidth = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
				 
				//there is '00 01' before the transport_id, so we will jump it !!
				buf = new byte[4];
				is.read(buf, 0, 2);
				//this is the true transport_id
				buf = new byte[4];
				is.read(buf, 0, 4);
				m_ts_info.transport_id = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
				
				Log.v(TAG, "readItems m_ts_info.resource_request_id = " 
						+ Integer.toHexString(m_ts_info.resource_request_id));
				Log.v(TAG, "readItems m_ts_info.resource_des_type = " 
						+ Integer.toHexString(m_ts_info.resource_des_type));	
				Log.v(TAG, "readItems m_ts_info.resource_num = " 
						+ Integer.toHexString(m_ts_info.resource_num));	
				Log.v(TAG, "readItems m_ts_info.assi_tag = " 
						+ Integer.toHexString(m_ts_info.assi_tag));
				Log.v(TAG, "readItems m_ts_info.resource_flag = " 
						+ Integer.toHexString(m_ts_info.resource_flag));	
				Log.v(TAG, "readItems m_ts_info.resource_status = " 
						+ Integer.toHexString(m_ts_info.resource_status));
				Log.v(TAG, "readItems m_ts_info.resource_field_len = " 
						+ Integer.toHexString(m_ts_info.resource_field_len));
				Log.v(TAG, "readItems m_ts_info.resource_count = " 
						+ Integer.toHexString(m_ts_info.resource_count));
				Log.v(TAG, "readItems m_ts_info.bandwidth = " 
						+ Integer.toHexString(m_ts_info.bandwidth));
				Log.v(TAG, "readItems m_ts_info.transport_id = " 
						+ Integer.toHexString(m_ts_info.transport_id));
		}
			@Override
			public void writeItems(OutputStream bos) throws IOException {
				// TODO Auto-generated method stub
				
			}
	}
		
		/*
		 * read the Comm_info_hdr data(in the parse_sc)
		 * */
		public class Comm_info_hdr implements NetWorkStruct{
			public Comm_info m_comm__info = null;
			public Comm_info_hdr() {
				SetupConfirm m_setupConfirm = new SetupConfirm();
				m_comm__info = m_setupConfirm.C_info;
			}
			public Comm_info_hdr(SetupConfirm.Comm_info data) {
				m_comm__info = data;
			}
			
			public void readItems(InputStream is, int offset) throws IOException {
				// TODO Auto-generated method stub
				// dsmHeader -------------------------------------------------------
				Log.v(TAG, "readItems ----------------------- ");
				if (m_comm__info == null)
				{
					Log.v(TAG, "m_comm__info is null");
					return;
				}
				
				is.skip(offset);
				byte []buf = new byte[4];
				is.read(buf, 0, 2);
				m_comm__info.resource_request_id = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_comm__info.resource_des_type = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_comm__info.resource_num = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_comm__info.assi_tag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_comm__info.resource_flag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_comm__info.resource_status = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_comm__info.resource_field_len = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_comm__info.resource_count = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				
				
				//there is PhysicalChannel resource info(00 01), we don't use it, so we will jump it!!!
				buf = new byte[4];
				is.read(buf, 0, 2);
				//this is the true channelID
				buf = new byte[4];
				is.read(buf, 0, 4);
				m_comm__info.channel_id = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
				for (int i=0; i<4; i++)
				{
					Log.v(TAG, "readItems m_comm__info.channel_id = " 
							+ Integer.toHexString(buf[i]));
				}
				
				
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_comm__info.direction = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				
				Log.v(TAG, "readItems m_comm__info.resource_request_id = " 
						+ Integer.toHexString(m_comm__info.resource_request_id));
				Log.v(TAG, "readItems m_comm__info.resource_des_type = " 
						+ Integer.toHexString(m_comm__info.resource_des_type));	
				Log.v(TAG, "readItems m_comm__info.resource_num = " 
						+ Integer.toHexString(m_comm__info.resource_num));	
				Log.v(TAG, "readItems m_comm__info.assi_tag = " 
						+ Integer.toHexString(m_comm__info.assi_tag));
				Log.v(TAG, "readItems m_comm__info.resource_flag = " 
						+ Integer.toHexString(m_comm__info.resource_flag));	
				Log.v(TAG, "readItems m_comm__info.resource_status = " 
						+ Integer.toHexString(m_comm__info.resource_status));
				Log.v(TAG, "readItems m_comm__info.resource_field_len = " 
						+ Integer.toHexString(m_comm__info.resource_field_len));
				Log.v(TAG, "readItems m_comm__info.resource_count = " 
						+ Integer.toHexString(m_comm__info.resource_count));
//				Log.v(TAG, "readItems m_comm__info.channel_id = " 
//						+ Long.toHexString(m_comm__info.channel_id));

				
				Log.v(TAG, "readItems m_comm__info.direction = " 
						+ Integer.toHexString(m_comm__info.direction));
		}
			@Override
			public void writeItems(OutputStream bos) throws IOException {
				// TODO Auto-generated method stub
				
			}
	}
		
		/*
		 * read the Ats_info_hdr data(in the parse_sc)
		 * */
		public class Ats_info_hdr implements NetWorkStruct{
			public Ats_info m_ats__info = null;
			public Ats_info_hdr() {
				SetupConfirm m_setupConfirm = new SetupConfirm();
				m_ats__info = m_setupConfirm.A_info;
			}
			public Ats_info_hdr(SetupConfirm.Ats_info data) {
				m_ats__info = data;
			}
			
			public void readItems(InputStream is, int offset) throws IOException {
				// TODO Auto-generated method stub
				// dsmHeader -------------------------------------------------------
				Log.v(TAG, "readItems ----------------------- ");
				if (m_ats__info == null)
				{
					Log.v(TAG, "m_sts__info is null");
					return;
				}
				
				is.skip(offset);
				byte []buf = new byte[4];
				is.read(buf, 0, 2);
				m_ats__info.resource_request_id = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_ats__info.resource_des_type = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_ats__info.resource_num = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_ats__info.assi_tag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_ats__info.resource_flag = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ats__info.resource_status = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ats__info.resource_field_len = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
			
				buf = new byte[4];
				is.read(buf, 0, 2);
				m_ats__info.resource_count = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
				/////////////////////////////////
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ats__info.transmission_system = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ats__info.coding_mode = new DataInputStream(new ByteArrayInputStream(buf)).readByte();

				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ats__info.split_bitmode = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ats__info.mod_format = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
			
				/////////////////////////////
				
				buf = new byte[4];
				is.read(buf, 0, 4);
				m_ats__info.sym_rate = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
				
				/////////////////////////////////
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ats__info.resert = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ats__info.depth = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ats__info.modu_mode = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				
				buf = new byte[4];
				is.read(buf, 0, 1);
				m_ats__info.forwrd = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				
				/////////////////////////////
				
				Log.v(TAG, "readItems m_ats__info.resource_request_id = " 
						+ Integer.toHexString(m_ats__info.resource_request_id));
				Log.v(TAG, "readItems m_ats__info.resource_des_type = " 
						+ Integer.toHexString(m_ats__info.resource_des_type));	
				Log.v(TAG, "readItems m_ats__info.resource_num = " 
						+ Integer.toHexString(m_ats__info.resource_num));	
				Log.v(TAG, "readItems m_ats__info.assi_tag = " 
						+ Integer.toHexString(m_ats__info.assi_tag));
				Log.v(TAG, "readItems m_ats__info.resource_flag = " 
						+ Integer.toHexString(m_ats__info.resource_flag));	
				Log.v(TAG, "readItems m_ats__info.resource_status = " 
						+ Integer.toHexString(m_ats__info.resource_status));
				Log.v(TAG, "readItems m_ats__info.resource_field_len = " 
						+ Integer.toHexString(m_ats__info.resource_field_len));
				Log.v(TAG, "readItems m_ats__info.resource_count = " 
						+ Integer.toHexString(m_ats__info.resource_count));
				Log.v(TAG, "readItems m_ats__info.transmission_system = " 
						+ Integer.toHexString(m_ats__info.transmission_system));
				Log.v(TAG, "readItems m_ats__info.coding_mode = " 
						+ Integer.toHexString(m_ats__info.coding_mode));
				Log.v(TAG, "readItems m_ats__info.split_bitmode = " 
						+ Integer.toHexString(m_ats__info.split_bitmode));
				Log.v(TAG, "readItems m_ats__info.mod_format = " 
						+ Integer.toHexString(m_ats__info.mod_format));
				Log.v(TAG, "readItems m_ats__info.sym_rate = " 
						+ Integer.toHexString(m_ats__info.sym_rate));
				
				Log.v(TAG, "readItems m_ats__info.resert = " 
						+ Integer.toHexString(m_ats__info.resert));
				Log.v(TAG, "readItems m_ats__info.depth = " 
						+ Integer.toHexString(m_ats__info.depth));
				Log.v(TAG, "readItems m_ats__info.modu_mode  = " 
						+ (m_ats__info.modu_mode));
				Log.v(TAG, "readItems m_ats__info.forwrd = " 
						+ (m_ats__info.forwrd));
				
		}
			@Override
			public void writeItems(OutputStream bos) throws IOException {
				// TODO Auto-generated method stub
				
			}
	}
		/*
		 * read the lsc_hdr data(in the parse_sc)
		 * */
		public class lsc_data_des_count_hdr implements NetWorkStruct{
			public Lsc_data_des_count m_lsc_des_count_data = null;
			public lsc_data_des_count_hdr() {
				SetupConfirm m_setupConfirm = new SetupConfirm();
				m_lsc_des_count_data = m_setupConfirm.LscDataDesCount;
			}
			public lsc_data_des_count_hdr(SetupConfirm.Lsc_data_des_count data) {
				m_lsc_des_count_data = data;
			}
			
			public void readItems(InputStream is, int offset) throws IOException {
				// TODO Auto-generated method stub
				// dsmHeader -------------------------------------------------------
				Log.v(TAG, "readItems ----------------------- ");
				if (m_lsc_des_count_data == null)
				{
					Log.v(TAG, "m_lsc_des_count_data is null");
					return;
				}
				
				is.skip(offset);
				//jump the first 6 byte
				byte []buf = new byte[16];
				is.read(buf, 0, 6);
				//this is the true des_count
				buf = new byte[16];
				is.read(buf, 0, 1);
				m_lsc_des_count_data.des_count = 0x0;
				m_lsc_des_count_data.des_count = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
				m_lsc_des_count_data.des_count &= 0xff;
				/////////////////////////////
				Log.v(TAG, "m_lsc_des_count_data.des_count(byte) = " + buf[0]);
				Log.v(TAG, "readItems m_lsc_des_count_data.des_count = " 
						+ Integer.toHexString(m_lsc_des_count_data.des_count));
				
		}
			@Override
			public void writeItems(OutputStream bos) throws IOException {
				// TODO Auto-generated method stub
				
			}
	}
			
		/*
		 * read the lsc_hdr data(in the parse_sc)
		 * */
		public class lsc_hdr implements NetWorkStruct{
			public Lsc_data m_lsc_data = null;
			public int m_des_count;
			public lsc_hdr(int des_count) {
				Log.v(TAG, "lsc_hdr ------- in");
				SetupConfirm m_setupConfirm = new SetupConfirm();
				m_lsc_data = m_setupConfirm.Lscdata;
				m_des_count = des_count;
				Log.v(TAG, "lsc_hdr ------- out");
			}
			public lsc_hdr(SetupConfirm.Lsc_data data, int des_count) {
				m_lsc_data = data;
				m_des_count = des_count;
			}
			
			public void readItems(InputStream is, int offset) throws IOException {
				// TODO Auto-generated method stub
				// dsmHeader -------------------------------------------------------
				Log.v(TAG, "readItems ----------------------- ");
				if (m_lsc_data == null)
				{
					Log.v(TAG, "m_lsc_data is null");
					return;
				}
				
				is.skip(offset);
				byte []buf = new byte[16];
				
				//jump the first byte, it is the m_des_count!!!
				is.read(buf, 0, 1);
			/*
				is.read(buf, 0, 2);
				m_lsc_data.resource_request_id = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
			*/
				Log.v(TAG, "m_des_count = " + m_des_count);
				for (int i=0; i<m_des_count; i++)
				{
					buf = new byte[16];
					is.read(buf, 0, 1);
					Log.v(TAG, "[lsc_hdr]buf = " + buf[0]);
					if (0x03 == buf[0])
					{
						buf = new byte[16];
						is.read(buf, 0, 1);
						int len = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
						 
						buf = new byte[16];
						is.read(buf, 0, 2);
						m_lsc_data.port = new DataInputStream(new ByteArrayInputStream(buf)).readShort();
						Log.v(TAG, "----m_lsc_data.port = " + m_lsc_data.port);
						
						buf = new byte[16];
						is.read(buf, 0, 4);
						m_lsc_data.ip = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
						Log.v(TAG, "----m_lsc_data.ip = " + m_lsc_data.ip);
					}
					if (0x04 == buf[0])
					{
						buf = new byte[16];
						is.read(buf, 0, 1);
						int len = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
						
						buf = new byte[16];
						is.read(buf, 0, 4);
						m_lsc_data.stream_handle = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
						Log.v(TAG, "----m_lsc_data.stream_handle = " + m_lsc_data.stream_handle);
					}
					if ((byte)0x06 == buf[0])
					{
						buf = new byte[16];
						is.read(buf, 0, 1);
						int len = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
						len &= 0xff;
						
						//the protocal and version is not useful, we jump it
						buf = new byte[16];
						is.read(buf, 0, 2);
						
						buf = new byte[16];
						is.read(buf, 0, 1);
						int count = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
						count &= 0xff;
						
						Log.v(TAG, "0x06 == buf[0]'s count(@@) = " + count);
						byte shdr = 0;
						for(int ii=0; ii < count; ii++)
						{
							buf = new byte[16];
							is.read(buf, 0, 1);
							shdr = 0;
							shdr = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
							
							if ((byte)0x03 == shdr)
							{
								//there is '04' before Billing
								buf = new byte[16];
								is.read(buf, 0, 1);
								//read the true Billing
								is.read(m_lsc_data.billing, 0, 4);
								for (int k=0; k<4; k++)
									Log.v(TAG, "m_lsc_data.billing[i] = " + m_lsc_data.billing[k]);
							}
							else if ((byte)0x05 == shdr)
							{
								Log.v(TAG, "----m_lsc_data.remain_time IN");
								//there is '04' before remain_time
								buf = new byte[16];
								is.read(buf, 0, 1);
								//read the true RemainingPlayTime
								buf = new byte[16];
								is.read(buf, 0, 4);
								m_lsc_data.remain_time = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
								Log.v(TAG, "----m_lsc_data.remain_time = " + m_lsc_data.remain_time);
							}
							else if (0x07 == shdr)//homeID
							{
								//there is '04' before homeID
								buf = new byte[16];
								is.read(buf, 0, 1);
								//read the true homeID
								is.read(m_lsc_data.home_id, 0, 4);
								for (int k=0; k<4; k++)
									Log.v(TAG, "m_lsc_data.home_id[i] = " + m_lsc_data.home_id[k]);
							}
							else if (0x08 == shdr)//pur_id
							{
								//there is '04' before pur_id
								buf = new byte[16];
								is.read(buf, 0, 1);
								//read the true pur_id
								is.read(m_lsc_data.pur_id, 0, 4);
								for (int k=0; k<4; k++)
									Log.v(TAG, "m_lsc_data.pur_id[i] = " + m_lsc_data.pur_id[k]);
							}
							else if (0x09 == shdr)//smart_id
							{
								//there is '04' before smart_id
								buf = new byte[16];
								is.read(buf, 0, 1);
								//read the true smart_id
								is.read(m_lsc_data.smart_id, 0, 4);
								for (int k=0; k<4; k++)
									Log.v(TAG, "m_lsc_data.smart_id[i] = " + m_lsc_data.smart_id[k]);
							}
							else if ((byte)0x80 == shdr)//heartBeatTime
							{
								//there is '04' before heartBeatTime
								buf = new byte[16];
								is.read(buf, 0, 1);
								//read the true heartBeatTime
								buf = new byte[16];
								is.read(buf, 0, 4);
								m_lsc_data.heartBeatTime = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
							}
							else if ((byte)0x81 == shdr)//lscpIpProtocol
							{
								//there is '04' before lscpIpProtocol
								buf = new byte[16];
								is.read(buf, 0, 1);
								//read the true lscpIpProtocol
								buf = new byte[16];
								is.read(buf, 0, 4);
								m_lsc_data.lscpIpProtocol = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
							}
						}
					}
					if ((byte)0x80 == buf[0])
					{
						buf = new byte[16];
						is.read(buf, 0, 1);
						int len = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
						
						//jump the protocal and version
						buf = new byte[16];
						is.read(buf, 0, 2);
						//read the true count
						buf = new byte[16];
						is.read(buf, 0, 1);
						int count = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
						count &= 0xff;
						Log.v(TAG, "0x80's count = " + count);
						
						
						for (int ii=0; ii<count; ii++)
						{
							buf = new byte[16];
							is.read(buf, 0, 1);
							byte shdr = new DataInputStream(new ByteArrayInputStream(buf)).readByte();
							
							if (0x03 == shdr)
							{
								//there is '04' before Billing
								buf = new byte[16];
								is.read(buf, 0, 1);
								//read the true Billing
								is.read(m_lsc_data.billing, 0, 4);
							}
							else if (0x05 == shdr)
							{
								//there is '04' before Billing
								buf = new byte[16];
								is.read(buf, 0, 1);
								//read the true RemainingPlayTime
								buf = new byte[16];
								is.read(buf, 0, 4);
								m_lsc_data.remain_time = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
								Log.v(TAG, "0x80's m_lsc_data.remain_time = " + m_lsc_data.remain_time);
							}
						}
					}
				}
				Log.v(TAG, "LSCP Server Info :");
				Log.v(TAG, "m_lsc_data.ip = " + m_lsc_data.ip);
				Log.v(TAG, "m_lsc_data.port = " + m_lsc_data.port);
				Log.v(TAG, "m_lsc_data.stream_handle = " + m_lsc_data.stream_handle);
				Log.v(TAG, "m_lsc_data.heartBeatTime = " + m_lsc_data.heartBeatTime);
				Log.v(TAG, "m_lsc_data.lscpIpProtocol = " + m_lsc_data.lscpIpProtocol);
				Log.v(TAG, "m_lsc_data.remain_time = " + m_lsc_data.remain_time);
		}
			@Override
			public void writeItems(OutputStream bos) throws IOException {
				// TODO Auto-generated method stub
				
			}
	}

		public class SSPClientSessionInProgress_hdr implements NetWorkStruct{
			ClientSessionInProgressData m_data = null;
			public SSPClientSessionInProgress_hdr() {
				this.m_data = new ClientSessionInProgressData();
			}
			public SSPClientSessionInProgress_hdr(ClientSessionInProgressData data) {
				this.m_data = data;
			}
			/**
			 * write data to network
			 * @param bos
			 * @throws IOException
			 */
			public void writeItems(OutputStream bos) throws IOException {
		        DataOutputStream dps = new DataOutputStream(bos);
		        Log.v(TAG, "writeItems ---11111111-- ");
		        // dsmHeader -------------------------------------------------------
		    	dps.writeByte(this.m_data.m_dsmHeader.m_protocolDiscriminator);
		    	dps.writeByte(this.m_data.m_dsmHeader.m_dsmccType);
		    	dps.writeShort(this.m_data.m_dsmHeader.m_messageId);
		    	dps.writeInt(this.m_data.m_dsmHeader.m_transactionId);
		    	dps.writeByte(this.m_data.m_dsmHeader.m_reserved);
		    	dps.writeByte(this.m_data.m_dsmHeader.m_adaptationLength);
		    	dps.writeShort(this.m_data.m_dsmHeader.m_messageLength);
		    	/*
		    	 * DsmccAdaptationHeader not fill into the header, beacause
		    	 * the DsmccAdaptationHeader always empty 
		    	 * */
		    	//m_sessionCount
		    	dps.writeShort(this.m_data.m_sessionCount);
		    	
		    	// SessionId -------------------------------------------------------
		    	dps.writeInt(this.m_data.m_sessionId.sysTime);
		    	dps.write(this.m_data.m_sessionId.mac);
		    
		    
		    	Log.v(TAG, "writeItems m_protocolDiscriminator = " + m_data.m_dsmHeader.m_protocolDiscriminator);
		    	Log.v(TAG, "writeItems m_dsmccType = " + m_data.m_dsmHeader.m_dsmccType);
		    	Log.v(TAG, "writeItems m_messageId = " + m_data.m_dsmHeader.m_messageId);
		    	Log.v(TAG, "writeItems m_transactionId = " + m_data.m_dsmHeader.m_transactionId);
		    	Log.v(TAG, "writeItems m_reserved = " + m_data.m_dsmHeader.m_reserved);
		    	Log.v(TAG, "writeItems m_adaptationLength = " + m_data.m_dsmHeader.m_adaptationLength);
		    	Log.v(TAG, "writeItems m_messageLength = " + m_data.m_dsmHeader.m_messageLength);
		    	
		    	Log.v(TAG, "writeItems m_sessionCount = " + m_data.m_sessionCount);
		    	
		    	Log.v(TAG, "writeItems m_data.m_sessionId.sysTime = " + m_data.m_sessionId.sysTime);
		    	for (int i=0; i<6; i++)
	    		{
		    		Log.v(TAG, "writeItems m_data.m_sessionId.mac = " + m_data.m_sessionId.mac[i]);
	    		}
		    	
		        dps.close();
			}
			@Override
			public void readItems(InputStream is, int offset) throws IOException {
				// TODO Auto-generated method stub
				
		}
	}
}