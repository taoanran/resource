package com.hansun.vod;

import java.io.IOException;
import java.net.DatagramPacket;
import java.util.Timer;
import java.util.TimerTask;

import android.util.Log;
/*
 * className:   HeartBeat 
 * function:    send the STB HeartBeat(ssp's ClientSessionInProgress message) to the SRM server, 
 * 				it will tell server the ssp connect is alive
 * description: it is a singlean class
 * author:      taoanran
 * createTime:  2012-12-25
 * */
public class HeartBeat {
	private static final String TAG = "HeartBeat";
	
	private int timeType ;
	private long m_second ;
	private long m_microsecond ;
	
	private Timer mTimer = null;
	private TimerTask task = null;
	private boolean threadIsCreate = false;
	private volatile boolean threadStopFlag = false;
	//CSRIReasonValue    --- ClientSessionReleaseIndication
	public interface TIMETYPE{
		int  	HEATBEAT = 0,
				SSPCONFIRM = 1,	
				ERROR = -1;
	};
		
	private static HeartBeat instance = null;
	
	public static HeartBeat getInstance() {
		if (instance == null)
		{
			instance = new HeartBeat();
		}
		return instance;
	}

	private HeartBeat()
	{
		timeType = 0;
		m_second = 0;
		m_microsecond = 0;

	    if (task == null)
	    {
			task = new TimerTask(){
			@Override
			public void run() {
				// TODO Auto-generated method stub
				OnTimer();
			 }};
	   	}
	}
	
	public void SetTimer(int type ,long second, long microsecond)
	{
		if (second < 0 || microsecond < 0)
		{
			Log.v(TAG, "setTimer's param is error !!!!!!!!!");
			return ;
		}
		
		mTimer = new Timer();
		
		mTimer.schedule(task, second * 1000);
	}

	public void StartTimer() {	
		threadIsCreate = true;
	}
	
	private void OnTimer() {

		STBCmdControl tmpSTBCmdControl = STBCmdControl.getInstance();
		
		if(TIMETYPE.HEATBEAT == timeType)
		{
			Log.v(TAG, " Ontimer type is HEATBEAT");
			tmpSTBCmdControl.ClientSessionInProgress() ;
		}
		else if (TIMETYPE.SSPCONFIRM == timeType)
		{
			Log.v(TAG, " Ontimer type is SSPCONFIRM");
		}
		else
		{
			Log.e(TAG, " Ontimer's timeType is error !!!!!!!!");
		}
			
	}
	
	public void StopTimer()
	{
		if (false == threadIsCreate)
		{
			Log.v(TAG, "the thread(heartBeat) is not created , so just return ! ");
			return;
		}
		
		if (task != null) {
			task.cancel();
			task = null;
		}
		 if (mTimer != null) {
        	mTimer.cancel();
        	mTimer.purge();
        	mTimer = null;
        }
		
		timeType = 0;
		m_second = 0;
		m_microsecond = 0;
		
		threadStopFlag = true;
		instance = null;
	}
	
}
