package com.hansun.vod;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public interface NetWorkStruct {
	public void readItems(InputStream is, int offset) throws IOException;
	public void writeItems(OutputStream bos) throws IOException;
}
