package com.hansun.vod.struct;

import android.util.Log;

/*
 * name:        MpegConfig
 * function:    the MediaPlayer's configure, include all dvb configure param
 * description: this is a data struct class
 * author:      taoanran
 * time:        2012.12.03
 * */
public class MpegConfig {
	private final static String TAG = "MpegConfig";
	
	public int programId; 
	public int freq_point[] = new int[6];//freq point
	public int freq_count;//the number of freq point, max num is 6
	public int qamMod; 
	public int symbolRate;
	public int revSignal; 
	public int version;
}
