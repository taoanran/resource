package com.hansun.vod.struct;
/*
 * name:        SSPClientReleaseRequestData
 * function:    the data of STB client tearDown the SSP connect
 * description: this is a data struct class
 * author:      taoanran
 * time:        2012.11.30
 * */
public class UserData {
	public short m_uuDataLength ; 	 /// char uuDataByte[m_uuDataLength]
	public byte m_uuDataByte[] = new byte[m_uuDataLength];
	public short m_privateDataLength ; /// char privateDataByte[m_privateDataLength]
	public byte m_privateDataByte[] = new byte[m_privateDataLength];
}
