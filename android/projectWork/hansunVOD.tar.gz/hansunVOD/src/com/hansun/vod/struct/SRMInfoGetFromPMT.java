package com.hansun.vod.struct;
/*
 * name:        SRMInfoGetFromPMT
 * function:    get the SRM info from pmt map, 
 * 				
 * description:  
 * author:      taoanran
 * time:        2012.11.30
 * */
public class SRMInfoGetFromPMT {
	public String m_gateway ; ///32 bit       Session Gateway Ip Address 
//	public int m_SRMIpAddress ;  /// 32 bit
	public String m_SRMIpAddress;
	public short m_SRMPort ; ///16 bit
	public short m_ServiceGroupId  ;//16 bit
	public SRMInfoGetFromPMT()
	{
		m_gateway = new String();
		m_SRMPort = 0;
		m_ServiceGroupId = 0;
		m_SRMIpAddress = new String();
	}
}
