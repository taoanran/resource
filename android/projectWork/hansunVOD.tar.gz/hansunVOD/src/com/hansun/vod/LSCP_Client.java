package com.hansun.vod;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.hansun.vod.struct.NetFormatTransform;

import android.util.Log;

/*
 * className:   STBCmdControl 
 * function:    send the STB commond Control to SRM server, 
 * 				it will control the SRM server do something
 * author:      taoanran
 * createTime:  2012-11-27
 * */

public class LSCP_Client {
	final Lock lock = new ReentrantLock();
	final Condition lockRespone  = lock.newCondition(); 
	final Condition lockDone = lock.newCondition();
	private static final String LOG_TAG = "LSCP_Client";
	public interface CallBack {
		void LSC_Done(int mode, int status_code);
	}
	private CallBack mCb = null;
	public CallBack getCb() {
		return mCb;
	}
	public void setCb(CallBack mCb) {
		this.mCb = mCb;
	}	
	public interface lscp_client_cmd{
		int	LSC_PAUSE = 0x01,
				LSC_RESUME = 0x02,
				LSC_STATUS = 0x03,
				LSC_RESET = 0x04,
				LSC_JUMP = 0x05,
				LSC_PLAY = 0x06,
				LSC_DONE = 0x40,
				LSC_PAUSE_REPLY = 0x81,
				LSC_RESUME_REPLY = 0x82,
				LSC_STATUS_REPLY = 0x83,
				LSC_RESET_REPLY = 0x84,
				LSC_JUMP_REPLY =  0x85,
				LSC_PLAY_REPLY =  0x86;
	};
	public interface lscp_client_ret {
		byte	LSC_OK = 0,
				LSC_BAD_REQUEST = 0x10,
				LSC_BAD_STREAM = 0x11,
				LSC_WRONG_STATE = 0x12,
				LSC_UNKNOWN = 0x13,
				LSC_NO_PERMISSION = 0x14,
				LSC_BAD_PARAM = 0x15,
				LSC_NO_IMPLEMENT = 0x16,
				LSC_NO_MEMORY = 0x17,
				LSC_IMP_LIMIT = 0x18,
				LSC_TRANSIENT = 0x19 ,
				LSC_SERVER_ERROR = 0x20, 
				LSC_SERVER_FAILURE = 0x21, 
				LSC_BAD_SCALE = 0x30,
				LSC_BAD_START = 0x31, 
				LSC_BAD_STOP = 0x32,
				LSC_MPEG_DELIVERY = 0x40;
	}
	public class lscp_hdr implements NetWorkStruct{
		public static final int SIZE = 8;
		// here should include two , one is people understand and other is machine transcation
		public int version; // byte 1
		public int trans_id; // byte 1
		public int  op_code; // byte 1
		public int status_code; // byte 1
		public long stream_handle; // int 4
		public lscp_hdr() {
			
		}
		public lscp_hdr(int version, int trans_id, int op_code, int status_code, long stream_handle) {
			this.version = version;
			this.trans_id = trans_id;
			this.op_code = op_code;
			this.status_code = status_code;
			this.stream_handle = stream_handle;
		}
		/**
		 * 
		 * @param read data from inpustStream
		 * @throws IOException 
		 */
		public void readItems(InputStream is, int offset) throws IOException {
			is.skip(offset);
			this.version = is.read();
			this.trans_id = is.read();
			this.op_code = is.read();
			this.status_code = is.read();
			byte[] buf = new byte[8];
			is.read(buf, 4, 4);
			this.stream_handle = new DataInputStream(new ByteArrayInputStream(buf)).readLong();
		}
		/**
		 * write data to network
		 * @param bos
		 * @throws IOException
		 */
		public void writeItems(OutputStream bos) throws IOException {
	        DataOutputStream dps = new DataOutputStream(bos);
	        dps.writeByte(this.version);
	        dps.writeByte(this.trans_id);
	        dps.writeByte(this.op_code);
	        dps.writeByte(this.status_code);
	        dps.writeInt((int) this.stream_handle);
	        //alter by zhengwei
	        //dps.close();
		}
		 
		public String toString () {
			return getClass().getName() + '@' + " version " + this.version + " trans_id " + this.trans_id +
					" op_code " + this.op_code + " status_code " + this.status_code + " stream_handle " + this.stream_handle;
		}
	};
	public class lscp_pause implements NetWorkStruct{
		public static final int SIZE = 4;
		public long stop_npt; // int 4
		public lscp_pause() {
			
		}
		public lscp_pause(long stop_npt) {
			this.stop_npt = stop_npt;
		}
		 
		public void readItems(InputStream is, int offset) throws IOException {
			is.skip(offset);
			byte[] buf = new byte[8];
			is.read(buf, 0, 4);		
			this.stop_npt = new DataInputStream(new ByteArrayInputStream(buf)).readLong();
		}
		 
		public void writeItems(OutputStream bos) throws IOException {
	        DataOutputStream dps = new DataOutputStream(bos);
	        dps.writeInt((int) this.stop_npt);
	        //dps.close();
		}
	};
	public class lscp_resume implements NetWorkStruct{
		public static final int SIZE = 8;
		public long start_npt; // int 4
		public int scale_num; // short 2
		public int scale_denom; // short 2
		public lscp_resume() {
			
		}
		public lscp_resume(long start_npt, int scale_num, int scale_denom) {
			this.start_npt = start_npt;
			this.scale_num = scale_num;
			this.scale_denom = scale_denom;
		}
		 
		public void readItems(InputStream is, int offset) throws IOException {
			is.skip(offset);
			byte[] buf = new byte[8];
			is.read(buf, 0, 4);		
			this.start_npt = new DataInputStream(new ByteArrayInputStream(buf)).readLong();
			buf = new byte[4];
			is.read(buf, 0, 2);		
			this.scale_num = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
			buf = new byte[4];
			is.read(buf, 0, 2);		
			this.scale_denom = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
		}
		 
		public void writeItems(OutputStream bos) throws IOException {
			DataOutputStream dps = new DataOutputStream(bos);
	        dps.writeInt((int) this.start_npt);
	        dps.writeShort(this.scale_num);
	        dps.writeShort(this.scale_denom);
	        //dps.close();
		}
	};
	public class lscp_play implements NetWorkStruct{
		public static final int SIZE = 12;
		public long start_npt; // int 4
		public long stop_npt; // int 4
		public int scale_num; // short 2
		public int scale_denom; // short 2
		public lscp_play() {
			
		}
		public lscp_play(long start_npt, long stop_npt, int scale_num, int scale_denom) {
			this.start_npt = start_npt;
			this.stop_npt = stop_npt;
			this.scale_denom = scale_denom;
			this.scale_num = scale_num;
		}
		 
		public void readItems(InputStream is, int offset) throws IOException {
			is.skip(offset);
			byte[] buf = new byte[8];
			is.read(buf, 0, 4);		
			this.start_npt = new DataInputStream(new ByteArrayInputStream(buf)).readLong();
			buf = new byte[8];
			is.read(buf, 0, 4);		
			this.stop_npt = new DataInputStream(new ByteArrayInputStream(buf)).readLong();
			buf = new byte[4];
			is.read(buf, 0, 2);		
			this.scale_num = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
			buf = new byte[4];
			is.read(buf, 0, 2);		
			this.scale_denom = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
		}
		 
		public void writeItems(OutputStream bos) throws IOException {
	        DataOutputStream dps = new DataOutputStream(bos);
	        dps.writeInt((int) this.start_npt);
	        dps.writeInt((int) this.stop_npt);
	        dps.writeShort(this.scale_num);
	        dps.writeShort(this.scale_denom);
	        //dps.close();
		}
	};
	public class lscp_response implements NetWorkStruct{
		public static final int SIZE = 9; 
		public long current_npt; // int 4
		public int scale_num; // short 2
		public int scale_denom; // short 2
		public int mode; // byte 1
		public lscp_response() {
			
		}
		public lscp_response(int current_npt, short scale_num, short scale_denom, byte mode) {
			this.current_npt = current_npt;
			this.scale_denom = scale_denom;
			this.scale_num = scale_num;
			this.mode = mode;
		}
		 
		public void readItems(InputStream is, int offset) throws IOException {
			is.skip(offset);
			byte[] buf = new byte[8];
			is.read(buf, 4, 4);
			this.current_npt = new DataInputStream(new ByteArrayInputStream(buf)).readLong();
			buf = new byte[4];
			is.read(buf, 2, 2);
			this.scale_num = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
			buf = new byte[4];
			is.read(buf, 2, 2);
			this.scale_denom = new DataInputStream(new ByteArrayInputStream(buf)).readInt();
			this.mode = is.read();		
		}
		 
		public void writeItems(OutputStream bos) throws IOException {
	        DataOutputStream dps = new DataOutputStream(bos);
	        dps.writeInt((int) this.current_npt);
	        dps.writeShort(this.scale_num);
	        dps.writeShort(this.scale_denom);
	        dps.writeByte(this.mode);
	        //dps.close();
		}
		 
		public String toString () {
			return getClass().getName() + "@" + " current_npt: " + this.current_npt +
					" scale_num:" + this.scale_num + " scale_denom:" + this.scale_denom + " mode:" + this.mode;
		}
	};
	
	private Socket mSocket = null;
	
	private byte trans_id;	//unsigned char 8 bit
	private long stream_handle; // unsigned int 32 bit
	private long ser_current_npt; //uint
	private int ser_scale_num; // ushort
	private int ser_scale_denom; //ushort
	private int ser_mode;	// byte	
	private boolean session_over = false;
	public boolean getSession_over() {
		return session_over;
	}
	public void setSession_over(boolean session_over) {
		this.session_over = session_over;
	}
	private long current_npt; // uint
	
	private final int wait_done_timeout = 1000; //milliseconds
	private int wait_respone_timeout = 100; //milliseconds

	private boolean isResponse = false, iswaitdone = false;
	
	
	private boolean isSocketInit = false;
	
	/*private static LSCP_Client instance = null;
	public static LSCP_Client getInstance() {
		if (instance == null) 
			instance = new LSCP_Client();//12, 0, "192.168.0.147", 60000);
		return instance;
	}*/
	public LSCP_Client() {
	}
	public void init(long stream_handle, int protocal, int server_ip, int port) {
		String ip = NetFormatTransform.int2IpString(server_ip);
		init(stream_handle, protocal, ip, port);
	}
	/**
	 * 
	 * @param stream_handle_ // ssp handle
	 * @param protocal // protocal type UDP or TCP
	 * @param server_ip server ip
	 * @param port server port
	 * @throws IOException 
	 */
	public void init(long stream_handle, int protocal, final String server_ip, final int port) 
	{	
		this.trans_id = 0x00;
		this.stream_handle = stream_handle;
		Log.i(LOG_TAG, "new lscp client " + server_ip + " port " + port);
	
		new Thread() {
			public void run(){
				try {
					mSocket = new Socket(server_ip, port);
				} catch (UnknownHostException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				isSocketInit = true;
				while(!session_over) {
						if (!isResponse) {
							iswaitdone = true;
							try {
								mSocket.setSoTimeout(wait_done_timeout);
								parse_response(mSocket.getInputStream());
							} catch (SocketException e) {
								try {
									mSocket = new Socket(server_ip, port);
								} catch (UnknownHostException e2) {
									e2.printStackTrace();
								} catch (IOException e2) {
									e2.printStackTrace();
								}
							} catch (IOException e) {
								
							}
							iswaitdone = false;
						}
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {}
				}
				// when finish we close the socket
				Log.i(LOG_TAG, "socket finished " + session_over);
				try {
					mSocket.close();
				} catch (IOException e) {}
			}
		}.start();
	}
	/**
	 * 
	 * @param bos
	 * @param request
	 * @return
	 * @throws IOException 
	 */
	private int fill_lscp_hdr(OutputStream bos, int request) throws IOException {
		Log.v(LOG_TAG, "fill_lscp_hdr:" + request);
		lscp_hdr lh = new lscp_hdr(0x01, this.trans_id++, request, 0x00, this.stream_handle);
		lh.writeItems(bos);
		if (session_over)
			return -1;
		return 0;
	}
	
	private int parse_response(InputStream is) {
		Log.v(LOG_TAG, "parser response:" + is);
		lscp_hdr lh = new lscp_hdr();
		lscp_response lr = new lscp_response();
		try {
			lh.readItems(is, 0);
			lr.readItems(is, 0);
		} catch (IOException e1) {
			e1.printStackTrace();
			return -1;
		}
		Log.v(LOG_TAG, lh.toString() + "   " + lr.toString());
		if(lh.version !=0x01 || lh.stream_handle != stream_handle) {
			Log.v(LOG_TAG, "not associate with us, ignore!");
			return -1;
		}
		switch (lh.op_code) {
		case lscp_client_cmd.LSC_PAUSE_REPLY:
			Log.v(LOG_TAG, "parse_response: LSC_PAUSE_REPLY");
			this.current_npt = lr.current_npt;
		case(lscp_client_cmd.LSC_RESUME_REPLY):
			Log.v(LOG_TAG, "parse_response: LSC_RESUME_REPLY");
		case(lscp_client_cmd.LSC_STATUS_REPLY):
			Log.v(LOG_TAG, "parse_response: LSC_STATUS_REPLY");   
			current_npt =  lr.current_npt;
		case(lscp_client_cmd.LSC_RESET_REPLY):
			Log.v(LOG_TAG, "parse_response: LSC_RESET_REPLY");
		case(lscp_client_cmd.LSC_JUMP_REPLY):
			Log.v(LOG_TAG, "parse_response: LSC_JUMP_REPLY");
		case(lscp_client_cmd.LSC_PLAY_REPLY):
			Log.v(LOG_TAG, "parse_response: LSC_PLAY_REPLY");
			if(lh.status_code == lscp_client_ret.LSC_OK) {
				Log.v(LOG_TAG, "parse_response: LSC_PLAY_REPLY state = LSC_OK");
				ser_current_npt = lr.current_npt;
				ser_scale_num = lr.scale_num;
				ser_scale_denom = lr.scale_denom;
				ser_mode = lr.mode;
			} else {
				//todo our request server do not suppot,
				Log.v(LOG_TAG, "parse_response: LSC_PLAY_REPLY state = " + lh.status_code);
				return -1;
			}
			break;
		case(lscp_client_cmd.LSC_DONE):
			Log.v(LOG_TAG, "parse_response: LSC_DONE");
			ser_current_npt = lr.current_npt;
			ser_scale_num = lr.scale_num;
			ser_scale_denom = lr.scale_denom;
			ser_mode = lr.mode;
			if(ser_mode == 7)  ///just end of the stream , 
				session_over = true;
			if (mCb != null)
				mCb.LSC_Done(lr.mode, lh.status_code);
			break;
		default:
			Log.v(LOG_TAG, "parse_response: " + lh.op_code);
			return -1;
		}
		return 0;
	}
	/** 
	 * 
	 * @param start_npt
	 * @param stop_npt
	 * @param s_num
	 * @param s_denom
	 * @return
	 * @throws IOException 
	 */
	public int lscp_send_play(long start_npt, long stop_npt, int s_num, int s_denom) {
		Log.v(LOG_TAG, "start_npt: " + start_npt + "stop_npt: " + stop_npt + "s_num: " + s_num + "s_denom" + s_denom);
		int i = 0;
		while(!isSocketInit) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			i ++;
			if (i == 50)
				return -1;
		}
		return sendCmd(lscp_client_cmd.LSC_PLAY, 
				new lscp_play(start_npt, stop_npt, (short) s_num, (short) s_denom));
	}
	/**
	 * set response wait time
	 * @param timerSecond
	 * @param timerUSecond 10 -6 seconds
	 */
	public void setResponseWaitTime(int timerSecond,int timerMSecond) {
		this.wait_respone_timeout = timerSecond * 1000 + timerMSecond;
	}
	/**
	 * pause
	 * @param stop_npt
	 * @return
	 */
	public int lscp_send_pause(long stop_npt) {
		return sendCmd(lscp_client_cmd.LSC_PAUSE, 
				new lscp_pause(stop_npt));
	}
	/**
	 * resume
	 * @param start_npt
	 * @param s_num
	 * @param s_denom
	 * @return
	 */
	public int lscp_send_resume(long start_npt, int s_num, int s_denom) {
		return sendCmd(lscp_client_cmd.LSC_RESUME, 
				new lscp_resume(start_npt, s_num, s_denom));
	}
	/**
	 * jump
	 * @param start_npt
	 * @param stop_npt
	 * @param s_num
	 * @param s_denom
	 * @return
	 */
	public int lscp_send_jump(long start_npt, long stop_npt, int s_num, int s_denom) {
		return sendCmd(lscp_client_cmd.LSC_JUMP,
				new lscp_play(start_npt, stop_npt, s_num, s_denom));
	}
	/**
	 * get current status
	 * @return
	 */
	public int lscp_send_status() {
		return sendCmd(lscp_client_cmd.LSC_STATUS, 
				null);
	}
	/**
	 * reset
	 * @return
	 */
	public int lscp_send_reset() {
		return sendCmd(lscp_client_cmd.LSC_RESET, 
				null);
	}
	/**
	 * communication with server use this
	 * @param cmd
	 * @param ns
	 * @return
	 */
	private int sendCmd(int cmd, NetWorkStruct ns) {
		try {
			Log.i(LOG_TAG, "socket lp:" + mSocket.getLocalPort() + " server ip: " + mSocket.getRemoteSocketAddress() + " port " + mSocket.getPort());
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			baos.reset();
			if (fill_lscp_hdr(baos, cmd) != 0) {
				Log.v(LOG_TAG, "session hava finished!");
				return -1;
			}
			if (ns != null)
				ns.writeItems(baos);
			byte[] bs = baos.toByteArray();
			baos.close();
			int i = 10;
			int ret = -1;
			while(i > 0) {
				if (iswaitdone) {
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {}
				} else {
					this.isResponse = true;
					mSocket.getOutputStream().write(bs);
					mSocket.setSoTimeout(wait_respone_timeout);
					ret = parse_response(mSocket.getInputStream());
					this.isResponse = false;
					break;
				}
			}
			return ret;
		} catch (IOException e1) {
			e1.printStackTrace();
			Log.v(LOG_TAG, "sendCmd failed !");
			this.isResponse = false;
			return -1;
		}
	}
	public boolean isSocketInit() {
		return isSocketInit;
	}
	public void setSocketInit(boolean isSocketInit) {
		this.isSocketInit = isSocketInit;
	}

}
