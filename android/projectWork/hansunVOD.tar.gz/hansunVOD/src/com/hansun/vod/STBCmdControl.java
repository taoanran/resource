package com.hansun.vod;

import java.io.BufferedReader;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.OptionalDataException;
import java.io.StreamCorruptedException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Date;

import android.util.Log;

import com.hansun.vod.SSPSocket.Comm_info_hdr;
import com.hansun.vod.SSPSocket.SSPClientReleaseRequestData_hdr;
import com.hansun.vod.VodEnum.Client_MessageId;
import com.hansun.vod.VodEnum.TearDownCSRRReasonValues;
import com.hansun.vod.VodStatus.PlayStateMachine;
import com.hansun.vod.VodStatus.cmdControlStateMachine;
import com.hansun.vod.struct.ClientId;
import com.hansun.vod.struct.ClientSessionInProgressData;
import com.hansun.vod.struct.ClientSessionSetupRequestBody;
import com.hansun.vod.struct.ClientSessionSetupRequestBody.ApplicationRequestData;
import com.hansun.vod.struct.ClientSessionSetupRequestBody.ApplicationRequestData.AppDescInfo;
import com.hansun.vod.struct.ClientSessionSetupRequestBody.AssetID;
import com.hansun.vod.struct.ClientSessionSetupRequestBody.NodeGroupId;
import com.hansun.vod.struct.DsmccMessageHeader;
import com.hansun.vod.struct.NetFormatTransform;
import com.hansun.vod.struct.SRMInfoGetFromPMT;
import com.hansun.vod.struct.SSPClientReleaseRequestData;
import com.hansun.vod.struct.SSPClientSessionSetUpRequest;
import com.hansun.vod.struct.ServerId;
import com.hansun.vod.struct.SessionId;
import com.hansun.vod.struct.SetupConfirm;
import com.hansun.vod.struct.SetupConfirm.Ats_info;
import com.hansun.vod.struct.SetupConfirm.Comm_info;
import com.hansun.vod.struct.SetupConfirm.Eri_info;
import com.hansun.vod.struct.SetupConfirm.Head_end_info;
import com.hansun.vod.struct.SetupConfirm.Lsc_data;
import com.hansun.vod.struct.SetupConfirm.Mpeg_info;
import com.hansun.vod.struct.SetupConfirm.Ts_info;
import com.hansun.vod.struct.UserData;
import com.hansun.vod.struct.resourceDescriptorCount;

/*
 * className:   STBCmdControl 
 * function:    the STB send and recieve  the commond of Control to/from the SRM server, 
 * 				it responsible for interact of stb and srm server
 * 
 * descript:    it is a singleton class
 * author:      taoanran
 * createTime:  2012-11-27
 * */
public class STBCmdControl 
{
	private final static String TAG = "STBCmdControl";
	
	//lscp client, it is a lscp session's client. it maybe multi object, not must single
	private LSCP_Client mLscp_client = null;
	//private DatagramSocket mSspSocket = null;//ssp(session setup protocol) socket(udp), Communicate with SRM server for setup/teardown session 
	private static STBCmdControl instance = null;
	private String m_assetIdString = null;
	private int m_transactionId = 0; //transactionID initial by STB need to increase 1 automatically
	private SessionId m_SessionId = null;  /// this is means this session ;
	private VodStatus mVodStatus = null;  //vodStatus
	private byte []m_Mac = new byte[6];
	private int m_IP  = 0;
	private SRMInfoGetFromPMT m_SRMInfo = null;
	private SetupConfirm m_sc = null;
	private SSPSocket m_SSPSocket = null;
	private boolean m_socketThreadExitFlag = false;
	private HeartBeat m_heartBeat = null;
	private LSCP_Client m_lscpClient = null;

	public Thread m_sspRecieveThread = null;
	
	int lscpTimerStep[]= { 0,500,1,0,2,0 };
	

	public void setSSPSocketThreadExitFlag(boolean tmpFlag)
	{
		m_socketThreadExitFlag = tmpFlag;
	}
	public static STBCmdControl getInstance() {
		if (instance == null)
		{
			instance = new STBCmdControl();
		}
		return instance;
	}
	/*
	 * 1.create a socket to recieve srmServer's message
	 * 2.
	 * */
	private STBCmdControl()
	{
		int i = 0;

		//init the global lscp_client
		mLscp_client = null;
		//set cmdControl status to init
		mVodStatus = VodStatus.getInstance();

		mVodStatus.setCmdControlStateMachine(cmdControlStateMachine.Init);//set CmdControl status is inited

		m_transactionId = 0x01 ;//transactionId is assigned by the Server
		if (null == m_SRMInfo)
		{
			m_SRMInfo = new SRMInfoGetFromPMT();
		}

		if (m_SessionId == null )
		{
			m_SessionId = new SessionId();
		}
		//init m_SessionId (mac and sysTime)
		for (i=0 ; i<6; i++)
		{
			m_SessionId.mac[i] = 0;
		}
		m_SessionId.sysTime = 0;

		//get the mac, and insert it into the global struct(m_Mac), for improve speed
		String mac = getMacAddr();
		Log.v(TAG, "get the mac = " + mac);
		String []macString = new String[6];
		macString = mac.split(":");
		for (i=0; i<6; i++)
		{
			//like 00:11:22:33:44:55
			m_Mac[i] = (byte)(Integer.parseInt(macString[i],16));
		}
		
		//get the IP, and insert it into the global struct(m_IP), for improve speed
		Log.v(TAG, "@@@@@@@@@@@@@@IP@@@@@@@@@@@@@@@@@@@@@@@");
		InetAddress addr = null;
		try {
			addr = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String ip = new String();
		ip = NetFormatTransform.getLocalIP();//addr.getHostAddress().toString();//get the local IP, now just for test
		
		Log.v(TAG, "get the IP = " + ip);
		String []ipString = new String[4];
		ipString = ip.split("\\.");

		byte []ipTmp = new byte[4];
		for (i=0; i<4; i++)
		{
			Log.v(TAG, "ipString =  " + ipString[i]);
			ipTmp[i] = (byte)(Integer.parseInt(ipString[i],16));
			Log.v(TAG, "get the IP(byte) = " + ipTmp[i]);
		}
		//transform IP's format (byte -> int)
		m_IP = NetFormatTransform.bytes2Integer(ipTmp);
		Log.v(TAG, "m_IP(Integer) = " + m_IP);
		Log.v(TAG, "m_IP(String) = " + ip);
		
		//create a thread to recieve the server's response
		m_sspRecieveThread = new Thread() {
			
			byte []inbuf = null;
			public void run(){
				if (null == m_SSPSocket)
				{
					m_SSPSocket = SSPSocket.getInstance();
				}
				DatagramPacket packet;
				while(true)					
				{
					if (m_socketThreadExitFlag)
					{
						break;
					}
						
					inbuf = new byte[1024*1024];
					packet = new DatagramPacket(inbuf, inbuf.length); // udp data package include date
					try {
						m_SSPSocket.mSocket.setSoTimeout(1000);
					} catch (SocketException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						continue;
					}
					
					try {
						Log.v(TAG, "RECV READY --------------------inbuf.length = " + inbuf.length);
						m_SSPSocket.mSocket.receive(packet);
						Log.v(TAG, "RECV end ");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} // get date from socket if no stop to wait
					Log.v(TAG, "RECVThread !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
					//Log.v(TAG, "RECVThread lenth = " + packet.getLength());
					//for (int i=0; i<packet.getLength(); i++)
					//	Log.v(TAG, "buf = " + inbuf[i]);
					//
					parserDataFromSocket(inbuf, packet.getLength());
				}
				
				m_socketThreadExitFlag = false;//deinit the flag
			}

		};
		m_sspRecieveThread.start();
		
		Log.v(TAG, "OUT");
	}
	/**
	 * @name   releaseSSPSocket
	 * @throws IOException 
	 */
	public void releaseSSPSocket()
	{
		m_SSPSocket = SSPSocket.getInstance();
		m_SSPSocket.mSocket.close();
		m_SSPSocket.mSocket = null;
		m_SSPSocket = null;
	}
	
	/**
	 * @name   parserDataFromSocket
	 * @param  recvData // recieve data
	 * @param  length // the lenth of recieve data
	 * @throws IOException 
	 */
	//private boolean parserDataFromSocket(DsmccMessageHeader tmpDsmccMessageHeader) {
	private synchronized boolean  parserDataFromSocket(byte data[], int length) {
	// TODO Auto-generated method stub
		//this.stream_handle = new DataInputStream(new ByteArrayInputStream(buf)).readLong();
		Log.v(TAG, "parserDataFromSocket IN-=--------------");
		if (data == null)
		{
			Log.v(TAG, "parserDataFromSocket -------------param data == null");
			return false;
		}

		SSPSocket.DsmccMessageHeader_hdr dsmccMessageHeader_hdr = m_SSPSocket.new DsmccMessageHeader_hdr();
		try {
			dsmccMessageHeader_hdr.readItems(new DataInputStream(new ByteArrayInputStream(data)), 0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		switch(dsmccMessageHeader_hdr.m_dsmccMessageHeader.m_messageId)
		{
	///tear Down  ++++++++++++++++++++++ 
		case VodEnum.Client_MessageId.TypeClientProceedingIndication:
			Log.v(TAG, "VodEnum.Client_MessageId.TypeClientProceedingIndication -------");
			parserClientSessionProceedingIndication(dsmccMessageHeader_hdr.m_dsmccMessageHeader);
			
			mVodStatus = VodStatus.getInstance();
			if(mVodStatus.getCmdControlStateMachine() == VodStatus.cmdControlStateMachine.TearDown )
			{
				ClientSessionReleaseResponse() ;
			}
			else if (mVodStatus.getCmdControlStateMachine() == VodStatus.cmdControlStateMachine.SessionSetup)
			{
				Log.v(TAG, "and now in Session Setup state !");
			}	
			break;
		case VodEnum.Client_MessageId.TypeClientReleaseIndication:
			Log.v(TAG, "VodEnum.Client_MessageId.TypeClientReleaseIndication -------");
			parserClientSessionReleaseIndication(dsmccMessageHeader_hdr.m_dsmccMessageHeader);  ///CSRI
			ClientSessionReleaseResponse() ;  ///CSRR
			mVodStatus = VodStatus.getInstance();
			mVodStatus.setCmdControlStateMachine(VodStatus.cmdControlStateMachine.Init) ;
			break;
		case VodEnum.Client_MessageId.TypeClientReleaseConfirm:
			Log.v(TAG, "VodEnum.Client_MessageId.TypeClientReleaseConfirm -------");
			parserClientSessionReleaseConfirm(dsmccMessageHeader_hdr.m_dsmccMessageHeader) ;
			mVodStatus = VodStatus.getInstance();
			mVodStatus.setCmdControlStateMachine(VodStatus.cmdControlStateMachine.Init) ;
			break;
	/// ----------------------------------
	
	//setup +++++++++++++++++++++++++++++++++
		case VodEnum.Client_MessageId.TypeClientSessionSetUpConfirm:
			boolean ret ;
			Log.v(TAG, "VodEnum.Client_MessageId.TypeClientSessionSetUpConfirm -------");
			ret = parserClientSessionSetUpConfirm(data, length, dsmccMessageHeader_hdr.m_dsmccMessageHeader) ;
			if(ret)
			{
				mVodStatus = VodStatus.getInstance();
				mVodStatus.setCmdControlStateMachine(VodStatus.cmdControlStateMachine.LSCPState) ;
				Log.v(TAG, "set the state to LscpState !");
			}
	//---------------------------------------
			break;
		default:
			Log.e(TAG, "parserDataFromSocket " + dsmccMessageHeader_hdr.m_dsmccMessageHeader.m_messageId);
			return false;
		}
		
		return true;
	}
	/**
	 * parse the ClientSessionSetUpConfirm message from SRM to STB 
	 * @param m_dsmccMessageHeader 
	 * @param data:  the data of stb received from srm server(ClientSessionSetUpConfirm's data)
	 * @param length:  the data length of stb received from srm server(ClientSessionSetUpConfirm's data)
	 * @return boolean
	 */
	private boolean parserClientSessionSetUpConfirm(byte[] data, int length, DsmccMessageHeader dsmccMessageHeader) {
		//create the setupConfirm's object
		if (m_sc == null)
		{
			m_sc = new SetupConfirm();
		}
		
		if(!parse_sc(data, length, m_sc, dsmccMessageHeader))
		{
			Log.e(TAG, "parserClientSessionSetUpConfirm error !!!!");
			return false;
		}
		
		///////start the heardbeat
		long timer = m_sc.Lscdata.heartBeatTime ;
		Log.v(TAG, "m_sc.Lscdata.heartBeatTime  =  " + m_sc.Lscdata.heartBeatTime );
		m_heartBeat = HeartBeat.getInstance();
		m_heartBeat.SetTimer(HeartBeat.TIMETYPE.HEATBEAT,timer,0);
		m_heartBeat.StartTimer();

		if (m_lscpClient == null)
		{
			m_lscpClient = new LSCP_Client();
		}
		m_lscpClient.init(m_sc.Lscdata.stream_handle, 0, m_sc.Lscdata.ip, m_sc.Lscdata.port);
		Log.v(TAG, "parserClientSessionSetUpConfirm ------- OUT");
		return true;
	}
	/**
	 * parse the setupConfirm data(it is come from the ClientSessionSetUpConfirm's data) 
	 * @param dsmccMessageHeader 
	 * @param data:  the data of stb received from srm server(ClientSessionSetUpConfirm's data)
	 * @param length:  the data length of stb received from srm server(ClientSessionSetUpConfirm's data)
	 * @param sc:    SetupConfirm's data
	 * @return boolean
	 */
	private boolean parse_sc(byte[] data, int length, SetupConfirm sc, DsmccMessageHeader dsmccMessageHeader) {
		// TODO Auto-generated method stub
		int ret = 0;
		byte []tmpData = null;
		resourceDescriptorCount resCount = new resourceDescriptorCount();

		if (data == null || length < 0 || sc == null || dsmccMessageHeader == null)
		{
			Log.e(TAG, "parse_sc's param is error !!!!!!!");
			return false;
		}
		tmpData = new byte[length];
		
		ret += parse_comfirm_dsm(dsmccMessageHeader);
		Log.v(TAG, "parse_sc ret = " + ret);
		if (ret > 0)
		{
			for(int i=0; i<length; i++)
			{
				tmpData[i] = 0;
			}
			for (int i=ret, j=0; i<length; i++,j++)
			{
				tmpData[j] = data[i];
			}
			//tmpData is the message delete the header
			ret += parse_comfirm_hdr(tmpData, length-ret, resCount);
			//Log.v(TAG, "parse_sc ret = " + ret);
			Log.v(TAG, "parse_comfirm_hdr resCount = " + resCount.count);
			if (resCount.count > 0)
			{
				for(int i=0; i<resCount.count; i++)
				{
					Log.v(TAG, "parse_sc ret = " + ret);
					//byte tmp = (byte) 0xf0;
					for(int t=0; t<length; t++)
					{
						tmpData[t] = 0;
					}
			
					if (((byte) 0xf0) == data[ret+2] && 0x06 == data[ret+2+1])
					{
						for (int k=ret, j=0; k<length; k++,j++)
						{
							tmpData[j] = data[k];
						}
						ret += parse_ether(tmpData, length-ret, sc.E_info);//4
					}
					else if(((byte) 0x00) == data[ret+2] && 0x03 == data[ret+2+1])
					{
						for (int k=ret, j=0; k<length; k++,j++)
						{
							tmpData[j] = data[k];
						}
						ret += parse_mpeg(tmpData, length-ret, sc.M_info);//2
					}
					else if(((byte) 0xf0) == data[ret+2] && 0x03 == data[ret+2+1])
					{
						for (int k=ret, j=0; k<length; k++,j++)
						{
							tmpData[j] = data[k];
						}
						ret += parse_head(tmpData, length-ret, sc.H_info);//1
					}
					else if(((byte) 0x00) == data[ret+2] && 0x06 == data[ret+2+1])
					{
						for (int k=ret, j=0; k<length; k++,j++)
						{
							tmpData[j] = data[k];
						}
						ret += parse_Ts(tmpData, length-ret, sc.T_info);//3
					}
					else if(((byte) 0x00) == data[ret+2] && 0x04 == data[ret+2+1])
					{
						for (int k=ret, j=0; k<length; k++,j++)
						{
							tmpData[j] = data[k];
						}
						ret += parse_Comm(tmpData, length-ret, sc.C_info);//5
					}
					else if(((byte) 0xf0) == data[ret+2] && 0x01 == data[ret+2+1])
					{
						for (int k=ret, j=0; k<length; k++,j++)
						{
							tmpData[j] = data[k];
						}
						ret += parse_Ats(tmpData, length-ret, sc.A_info);//6
					}
				}
				
				for(int t=0; t<length; t++)
				{
					tmpData[t] = 0;
				}
				for (int k=ret, j=0; k<length; k++,j++)
				{
					tmpData[j] = data[k];
				}
				parse_lsc_data(tmpData, sc.Lscdata);
			}
		}
		else
		{	
			
		}
		
		Log.v(TAG, "parse_sc END !!!!!!!");
		return true;
	}
	private void parse_lsc_data(byte[] tmpData, Lsc_data lscdata) {
		// TODO Auto-generated method stub
		if (null == tmpData || lscdata == null)
		{
			Log.e(TAG, "parse_lsc_data's param is null");
			return ;
		}
		
		Log.v(TAG, "parse_lsc_data ---------------------------- IN");
		//read the lsc_data_des_count
		m_SSPSocket = SSPSocket.getInstance();
		SSPSocket.lsc_data_des_count_hdr lsc_des_count_data = m_SSPSocket.new lsc_data_des_count_hdr();
		try {
			lsc_des_count_data.readItems(new DataInputStream(new ByteArrayInputStream(tmpData)), 0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.v(TAG, "lsc_des_count_data.m_lsc_des_count_data.des_count(parse_lsc_data) = " + lsc_des_count_data.m_lsc_des_count_data.des_count );
		//read the other memsage
		byte[] tmpLSCData = new byte[tmpData.length];
		for(int i=0, j=6; i<tmpData.length-6; i++,j++)
		{
			tmpLSCData[i] = tmpData[j];
			//Log.v(TAG, "tmpLSCData = " + tmpLSCData[i]);
		}
		
		SSPSocket.lsc_hdr lsc_data = m_SSPSocket.new lsc_hdr(lsc_des_count_data.m_lsc_des_count_data.des_count);
		try {
			lsc_data.readItems(new DataInputStream(new ByteArrayInputStream(tmpLSCData)), 0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		lscdata.port = lsc_data.m_lsc_data.port;
		lscdata.ip = lsc_data.m_lsc_data.ip;
		lscdata.stream_handle 	= lsc_data.m_lsc_data.stream_handle;
		lscdata.remain_time 	= lsc_data.m_lsc_data.remain_time;
		lscdata.heartBeatTime 	= lsc_data.m_lsc_data.heartBeatTime;
		lscdata.lscpIpProtocol 	= lsc_data.m_lsc_data.lscpIpProtocol;
		
		for (int i=0; i<5; i++)
		{
			lscdata.billing[i] 	= lsc_data.m_lsc_data.billing[i];
			lscdata.home_id[i] 	= lsc_data.m_lsc_data.home_id[i];
			lscdata.pur_id[i] 	= lsc_data.m_lsc_data.pur_id[i];
			lscdata.smart_id[i] = lsc_data.m_lsc_data.smart_id[i];
		}	
		
		Log.v(TAG, "LSCP Server Info :");
		Log.v(TAG, "lscdata.ip = " + lscdata.ip);
		Log.v(TAG, "LSCP ip(Hex) = "+ Integer.toHexString(lscdata.ip));
		Log.v(TAG, "lscdata.port = " + lscdata.port);
		Log.v(TAG, "LSCP port(Hex) = "+ Integer.toHexString(lscdata.port));
		Log.v(TAG, "lscdata.stream_handle = " + lscdata.stream_handle);
		Log.v(TAG, "LSCP stream_handle = "+ Integer.toHexString(lscdata.stream_handle));
		Log.v(TAG, "lscdata.heartBeatTime = " + lscdata.heartBeatTime);
		Log.v(TAG, "lscdata.lscpIpProtocol = " + lscdata.lscpIpProtocol);
		Log.v(TAG, "lscdata.remain_time = " + lscdata.remain_time);
		
		Log.v(TAG, "parse_lsc_data ---------------------------- OUT");
	}
	/**
	 * parse_Ats
	 * @param tmpData : the data of resource info
	 * @param lenth:    the lenth of resource info
	 * @param c_info:   the Ats info
	 * @return :        the lenth of the Ats info
	 */
	private int parse_Ats(byte[] tmpData, int lenth, Ats_info a_info) {
		// TODO Auto-generated method stub
		if (null == tmpData || lenth < 0 || null == a_info)
		{
			if (null == tmpData)
			{
				Log.e(TAG, "parse_Ats param is error (tmpData)!!!!!!!");
			}
			else if (lenth < 0)
			{
				Log.e(TAG, "parse_Ats param is error (lenth)!!!!!!!");
			}
			else
			{
				Log.e(TAG, "parse_Ats param is error (a_info)!!!!!!!");
			}
			Log.e(TAG, "parse_Ats param is error !!!!!!!");
			return -1;
		}
		Log.v(TAG, "parse_Ats ---------------------------- IN");
		
		m_SSPSocket = SSPSocket.getInstance();
		SSPSocket.Ats_info_hdr ats_hdr = m_SSPSocket.new Ats_info_hdr();
		try {
			ats_hdr.readItems(new DataInputStream(new ByteArrayInputStream(tmpData)), 0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		a_info.resource_request_id = ats_hdr.m_ats__info.resource_request_id;
		a_info.resource_des_type = ats_hdr.m_ats__info.resource_des_type;
		a_info.resource_num 	= ats_hdr.m_ats__info.resource_num;
		a_info.assi_tag 	= ats_hdr.m_ats__info.assi_tag;
		a_info.resource_flag 	= ats_hdr.m_ats__info.resource_flag;
		a_info.resource_status 	= ats_hdr.m_ats__info.resource_status;
		a_info.resource_field_len 	= ats_hdr.m_ats__info.resource_field_len ;
		a_info.resource_count 	= ats_hdr.m_ats__info.resource_count;
		
		a_info.transmission_system 	= ats_hdr.m_ats__info.transmission_system ;
		a_info.coding_mode 	= ats_hdr.m_ats__info.coding_mode ;
		a_info.split_bitmode 	= ats_hdr.m_ats__info.split_bitmode ;
		a_info.mod_format 	= ats_hdr.m_ats__info.mod_format ;
		a_info.sym_rate 	= ats_hdr.m_ats__info.sym_rate ;
		
		a_info.resert 	= ats_hdr.m_ats__info.resert ;
		a_info.depth 	= ats_hdr.m_ats__info.depth ;
		a_info.modu_mode 	= ats_hdr.m_ats__info.modu_mode ;
		a_info.forwrd 	= ats_hdr.m_ats__info.forwrd ;
		
		
		Log.v(TAG, "parse_Ats ---------------------------- OUT");
		return 26;
	}
	/**
	 * parse_Comm
	 * @param tmpData : the data of resource info
	 * @param lenth:    the lenth of resource info
	 * @param c_info:   the Comm_info
	 * @return :        the lenth of the Comm_info
	 */
	private int parse_Comm(byte[] tmpData, int lenth, Comm_info c_info) {
		// TODO Auto-generated method stub
		if (null == tmpData || lenth < 0 || null == c_info)
		{
			if (null == tmpData)
			{
				Log.e(TAG, "parse_Ts param is error (tmpData)!!!!!!!");
			}
			else if (lenth < 0)
			{
				Log.e(TAG, "parse_Ts param is error (lenth)!!!!!!!");
			}
			else
			{
				Log.e(TAG, "parse_Ts param is error (c_info)!!!!!!!");
			}
			Log.e(TAG, "parse_Comm param is error !!!!!!!");
			return -1;
		}
		Log.v(TAG, "parse_Comm ---------------------------- IN");
		
		m_SSPSocket = SSPSocket.getInstance();
		SSPSocket.Comm_info_hdr commInfo_hdr = m_SSPSocket.new Comm_info_hdr();
		try {
			commInfo_hdr.readItems(new DataInputStream(new ByteArrayInputStream(tmpData)), 0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		c_info.resource_request_id = commInfo_hdr.m_comm__info.resource_request_id;
		c_info.resource_des_type = commInfo_hdr.m_comm__info.resource_des_type;
		c_info.resource_num 	= commInfo_hdr.m_comm__info.resource_num;
		c_info.assi_tag 	= commInfo_hdr.m_comm__info.assi_tag;
		c_info.resource_flag 	= commInfo_hdr.m_comm__info.resource_flag;
		c_info.resource_status 	= commInfo_hdr.m_comm__info.resource_status;
		c_info.resource_field_len 	= commInfo_hdr.m_comm__info.resource_field_len ;
		c_info.resource_count 	= commInfo_hdr.m_comm__info.resource_count;
		c_info.channel_id 	= commInfo_hdr.m_comm__info.channel_id ;
		c_info.direction 	= commInfo_hdr.m_comm__info.direction ;

		Log.v(TAG, "parse_Comm ---------------------------- OUT");
		return 22;
	}
	/**
	 * parse_Ts
	 * @param tmpData : the data of resource info
	 * @param lenth:    the lenth of resource info
	 * @param t_info:   the Ts Info
	 * @return :        the lenth of the Ts info
	 */
	private int parse_Ts(byte[] tmpData, int lenth, Ts_info t_info) {
		// TODO Auto-generated method stub
		
		if (null == tmpData || lenth < 0 || null == t_info)
		{
			if (null == tmpData)
			{
				Log.e(TAG, "parse_Ts param is error (tmpData)!!!!!!!");
			}
			else if (lenth < 0)
			{
				Log.e(TAG, "parse_Ts param is error (lenth)!!!!!!!");
			}
			else
			{
				Log.e(TAG, "parse_Ts param is error (t_info)!!!!!!!");
			}
			Log.e(TAG, "parse_Ts param is error !!!!!!!");
			return -1;
		}
		Log.v(TAG, "parse_head ---------------------------- IN");
		
		m_SSPSocket = SSPSocket.getInstance();
		SSPSocket.Ts_hdr ts_hdr = m_SSPSocket.new Ts_hdr();
		try {
			ts_hdr.readItems(new DataInputStream(new ByteArrayInputStream(tmpData)), 0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t_info.resource_request_id = ts_hdr.m_ts_info.resource_request_id;
		t_info.resource_des_type = ts_hdr.m_ts_info.resource_des_type;
		t_info.resource_num 	= ts_hdr.m_ts_info.resource_num;
		t_info.assi_tag 	= ts_hdr.m_ts_info.assi_tag;
		t_info.resource_flag 	= ts_hdr.m_ts_info.resource_flag;
		t_info.resource_status 	= ts_hdr.m_ts_info.resource_status;
		t_info.resource_field_len 	= ts_hdr.m_ts_info.resource_field_len ;
		t_info.resource_count 	= ts_hdr.m_ts_info.resource_count;
		t_info.bandwidth 	= ts_hdr.m_ts_info.bandwidth ;
		t_info.transport_id 	= ts_hdr.m_ts_info.transport_id ;

		Log.v(TAG, "parse_Ts ---------------------------- OUT");
		return 26;
	}
	/**
	 * parse_head
	 * @param tmpData : the data of resource info
	 * @param lenth:    the lenth of resource info
	 * @param h_info:   the Head_end_info Info
	 * @return :        the lenth of the head
	 */
	private int parse_head(byte[] tmpData, int lenth, Head_end_info h_info) {
		// TODO Auto-generated method stub
		
		if (null == tmpData || lenth < 0 || null == h_info)
		{
			if (null == tmpData)
			{
				Log.e(TAG, "parse_head param is error (tmpData)!!!!!!!");
			}
			else if (lenth < 0)
			{
				Log.e(TAG, "parse_head param is error (lenth)!!!!!!!");
			}
			else
			{
				Log.e(TAG, "parse_head param is error (h_info)!!!!!!!");
			}
			Log.e(TAG, "parse_mpeg's param is error !!!!!!!");
			return -1;
		}
		Log.v(TAG, "parse_head ---------------------------- IN");
		
		m_SSPSocket = SSPSocket.getInstance();
		SSPSocket.Head_hdr headInfo_hdr = m_SSPSocket.new Head_hdr();
		try {
			headInfo_hdr.readItems(new DataInputStream(new ByteArrayInputStream(tmpData)), 0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		h_info.resource_request_id = headInfo_hdr.m_head_end_info.resource_request_id;
		h_info.resource_des_type = headInfo_hdr.m_head_end_info.resource_des_type;
		h_info.resource_num = headInfo_hdr.m_head_end_info.resource_num;
		h_info.assi_tag = headInfo_hdr.m_head_end_info.assi_tag;
		h_info.resource_flag = headInfo_hdr.m_head_end_info.resource_flag;
		h_info.resource_status = headInfo_hdr.m_head_end_info.resource_status;
		h_info.resource_field_len = headInfo_hdr.m_head_end_info.resource_field_len;
		h_info.resource_count = headInfo_hdr.m_head_end_info.resource_count;
		h_info.head_end_flag = headInfo_hdr.m_head_end_info.head_end_flag;
		
		h_info.hei.afi = headInfo_hdr.m_head_end_info.hei.afi;
		for (int i=0; i<8; i++)
		{
			h_info.hei.idi[i] = headInfo_hdr.m_head_end_info.hei.idi[i];
		}
		h_info.hei.dsp = headInfo_hdr.m_head_end_info.hei.dsp;
		for (int i=0; i<6; i++)
		{
			h_info.hei.esi[i] = headInfo_hdr.m_head_end_info.hei.esi[i];
		}
		h_info.hei.sel = headInfo_hdr.m_head_end_info.hei.sel;
		
		h_info.transport_stream_id = headInfo_hdr.m_head_end_info.transport_stream_id;
		
		Log.v(TAG, "parse_head ---------------------------- OUT");
		return 40;
	}
	/**
	 * parse_mpeg
	 * @param tmpData : the data of resource info
	 * @param lenth:    the lenth of resource info
	 * @param e_info:   the mpeg resource info 
	 * @return int :    the lenth of the mpegInfo
	 */
	private int parse_mpeg(byte[] tmpData, int lenth, Mpeg_info m_info) {
		// TODO Auto-generated method stub
		if (null == tmpData || lenth < 0 || null == m_info)
		{
			if (null == tmpData)
			{
				Log.e(TAG, "parse_mpeg's param is error (tmpData)!!!!!!!");
			}
			else if (lenth < 0)
			{
				Log.e(TAG, "parse_mpeg's param is error (lenth)!!!!!!!");
			}
			else
			{
				Log.e(TAG, "parse_mpeg's param is error (m_info)!!!!!!!");
			}
			Log.e(TAG, "parse_mpeg's param is error !!!!!!!");
			return -1;
		}
		Log.v(TAG, "parse_mpeg ---------------------------- IN");
		int pkt_count=0;
		m_SSPSocket = SSPSocket.getInstance();
		SSPSocket.MpegInfo_hdr mpegInfo_hdr = m_SSPSocket.new MpegInfo_hdr();
		try {
			mpegInfo_hdr.readItems(new DataInputStream(new ByteArrayInputStream(tmpData)), 0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		m_info.resource_request_id = mpegInfo_hdr.m_mpeg_info.resource_request_id;
		m_info.resource_des_type = mpegInfo_hdr.m_mpeg_info.resource_des_type;
		m_info.resource_num = mpegInfo_hdr.m_mpeg_info.resource_num;
		m_info.assi_tag = mpegInfo_hdr.m_mpeg_info.assi_tag;
		m_info.resource_flag = mpegInfo_hdr.m_mpeg_info.resource_flag;
		m_info.resource_status = mpegInfo_hdr.m_mpeg_info.resource_status;
		m_info.resource_field_len = mpegInfo_hdr.m_mpeg_info.resource_field_len;
		m_info.resource_count = mpegInfo_hdr.m_mpeg_info.resource_count;
		
		m_info.mpeg_num = mpegInfo_hdr.m_mpeg_info.mpeg_num;
		m_info.mpeg_pmt_pid = mpegInfo_hdr.m_mpeg_info.mpeg_pmt_pid;
		m_info.mpeg_ca_pid = mpegInfo_hdr.m_mpeg_info.mpeg_ca_pid;
		m_info.stream_count = mpegInfo_hdr.m_mpeg_info.stream_count;
		m_info.mpeg_pcr = mpegInfo_hdr.m_mpeg_info.mpeg_pcr;
		
		pkt_count = 14 + (int)m_info.resource_field_len;
		Log.v(TAG, "parse_mpeg ---------------------------- OUT");
		return pkt_count;
	}
	/**
	 * parse_ether
	 * @param tmpData : the data of resource info
	 * @param lenth:    the lenth of resource info
	 * @param e_info:   the Ethernet interface resource info 
	 * @return int :    the lenth of the EthernetInfo
	 */
	private int parse_ether(byte[] tmpData, int lenth, Eri_info e_info) {
		Log.v(TAG, "parse_ether ----------------- IN");
		
		if (null == tmpData || lenth < 0 || null == e_info)
		{
			Log.e(TAG, "parse_ether's param is error !!!!!!!");
			return -1;
		}
		
		int pkt_count=0;
		m_SSPSocket = SSPSocket.getInstance();
		SSPSocket.EtherInfo_hdr etherInfo_hdr = m_SSPSocket.new EtherInfo_hdr();
		try {
			etherInfo_hdr.readItems(new DataInputStream(new ByteArrayInputStream(tmpData)), 0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		e_info.resource_request_id = etherInfo_hdr.m_eri_info.resource_request_id;
		e_info.resource_des_type = etherInfo_hdr.m_eri_info.resource_des_type;
		e_info.resource_num = etherInfo_hdr.m_eri_info.resource_num;
		e_info.assi_tag = etherInfo_hdr.m_eri_info.assi_tag;
		e_info.resource_flag = etherInfo_hdr.m_eri_info.resource_flag;
		e_info.resource_status = etherInfo_hdr.m_eri_info.resource_status;
		e_info.resource_field_len = etherInfo_hdr.m_eri_info.resource_field_len;
		e_info.resource_count = etherInfo_hdr.m_eri_info.resource_count;
		
		pkt_count += (2 + 2 + 2 + 2 +2 + 1 + 1 + 2);
		
		e_info.source_port = etherInfo_hdr.m_eri_info.source_port;
		e_info.source_ip = etherInfo_hdr.m_eri_info.source_ip;
		e_info.dst_port = etherInfo_hdr.m_eri_info.dst_port;
		e_info.dst_ip = etherInfo_hdr.m_eri_info.dst_ip;
		//e_info.dst_mac = etherInfo_hdr.m_eri_info.dst_mac;
		//e_info.dst_port = etherInfo_hdr.m_eri_info.dst_port;

		pkt_count += 6;

		pkt_count += 8;

		pkt_count += 10;

		pkt_count += 6;

		pkt_count += 8;
		pkt_count += 10;

		Log.v(TAG, "parse_ether ----------------- OUT");
		return pkt_count;
	}
	//Judge if we will change the sessionID of not
	private boolean isSessionIDChange(byte[] tmpData, int length){
		byte []tmpSysTime = new byte[4]; 
		Log.v(TAG, "isSessionIDChange ------- IN");
		SessionId sessionid = new SessionId();
		getTheSessionId(sessionid);
		tmpSysTime = NetFormatTransform.integer2Bytes(sessionid.sysTime);
		for (int i=0; i<4; i++)
		{
			Log.v(TAG, "tmpSysTime[i] = " + tmpSysTime[i]);
		}
		for (int i=0; i<4; i++)
		{
			Log.v(TAG, "tmpData[i] = " + tmpData[i]);
			if (tmpSysTime[i] != tmpData[i])
			{
				Log.v(TAG, "we should change the sessionID from confirm(tmpSysTime)!!");
				return true;
			}
		}
		for (int i=0; i<6; i++)
		{
			Log.v(TAG, "sessionid.mac[i] = " + sessionid.mac[i]);
		}
		for (int i=0; i<6; i++)
		{
			if (sessionid.mac[i] != tmpData[4+i])
			{
				Log.v(TAG, "we should change the sessionID from confirm(mac)!!");
				return true;
			}
		}
		Log.v(TAG, "isSessionIDChange ------- OUT");
		return false;
	}
	//change the sessionID
	private void sessionIDChange(byte[] tmpData, int length){
		if (null == tmpData || length < 0)
		{
			Log.v(TAG, "sessionIDChange's param is error !!!!!!!!!");
			return ;
		}
		Log.v(TAG, "sessionIDChange ------- IN");
		byte []tmpSysTime = new byte[4]; //m_SessionId
		for (int i=0; i<4; i++)
		{
			tmpSysTime[i] = tmpData[i];
		}
		m_SessionId.sysTime = NetFormatTransform.bytes2Integer(tmpSysTime);
		
		for (int i=0; i<6; i++)
		{
			m_SessionId.mac[i] = tmpData[i+4];
		}
		Log.v(TAG, "sessionIDChange ------- OUT");
	}
	
	//getMpegNum(program_id, serviceID)
	public short getMpegNum()
	{
		return m_sc.M_info.mpeg_num;
	}
	//getChannelId(freq)
	public int getChannelId()
	{
		return m_sc.C_info.channel_id;
	}
	//getSymbolRate
	public int getSymbolRate()
	{
		return m_sc.A_info.sym_rate;
	}
	//getModFormat
	public byte getModFormat()
	{
		return m_sc.A_info.mod_format;
	}
	//tmpData: data message, has been deleted the  dsmccMessageHeader
	private int parse_comfirm_hdr(byte[] tmpData, int length, resourceDescriptorCount resCount) {
		Log.v(TAG, "parse_comfirm_hdr ------------------- IN");
		if (null == tmpData || length < 0 || null == resCount)
		{
			//Log.e(TAG, "parse_comfirm_hdr's param is error !!!!!!!!!");
			if (null == tmpData)
			{
				Log.e(TAG, "parse_comfirm_hdr's param is error ---------tmpData == null");
			}
			if (length < 0)
			{
				Log.e(TAG, "parse_comfirm_hdr's param is error ---------length < 0");
			}
			if (null == resCount)
			{
				Log.e(TAG, "parse_comfirm_hdr's param is error ---------resCount == null");
			}
			return -1;
		}

		int pkt_count = 0;
		byte []tmpArray = new byte[2];
		short tmpResponse = 0;
		//compare the sessionID
		if (isSessionIDChange(tmpData, length))
		{
			//we must change the sessionID
			sessionIDChange(tmpData, length);
		}
		pkt_count += 10;
		
		//compare the response with 0	
		if (tmpData[10] != 0 || tmpData[11] != 0)
		{
			Log.v(TAG, "parse_comfirm_hdr's response is not 0 !!!!!!!!!");	
			return -1;
		}
		pkt_count += 2;

		//skip afi and idi 
		pkt_count +=9;
		
		pkt_count +=4;
		//skip esi
		pkt_count +=6;
		//skip sel
		pkt_count ++;
		Log.v(TAG, "pkt_count = " + pkt_count);
		tmpArray[0] = tmpData[pkt_count];
		tmpArray[1] = tmpData[pkt_count+1];
		resCount.count = NetFormatTransform.bytes2Short(tmpArray);
		Log.v(TAG, "resCount.count = " + resCount.count);
		
		pkt_count += 2;
		Log.v(TAG, "parse_comfirm_hdr ------------------- OUT");
		return pkt_count;
	}
	/**
	 * parse the confirm dsm 
	 * @return : lenth of dsmccMessageHeader
	 */
	private int parse_comfirm_dsm(DsmccMessageHeader dsmccMessageHeader) {
		// TODO Auto-generated method stub
		if (null == dsmccMessageHeader)
		{
			Log.e(TAG, "parse_comfirm_dsm's param is error !!!!!!!");
			return -1;
		}
		
		if (dsmccMessageHeader.m_protocolDiscriminator != 0x11){
			Log.e(TAG, "dsmcc hdr_discriminator wrong[parse_comfirm_dsm]");
			return -1;
		}
		
		if(dsmccMessageHeader.m_dsmccType != 0x02) {
			Log.e(TAG, "dsmccMessageHeader.m_dsmccType wrong[parse_comfirm_dsm]");
			return -1;
		}
		if(dsmccMessageHeader.m_messageId != 0x4011) {
			Log.e(TAG, "dsmccMessageHeader.dsmcc messid wrong[parse_comfirm_dsm]");
			return -1;
		}
		
		Log.v(TAG, "dsmcc_hdr->m_messageLength = " + dsmccMessageHeader.m_messageLength);
		
		return 12;
	}
	
	/**
	 * parse the ClientSessionReleaseConfirm(CSRI) message from SRM to STB 
	 * @param SSPClientReleaseRequestData
	 * @return void
	 */
	private void parserClientSessionReleaseConfirm(
			DsmccMessageHeader m_dsmccMessageHeader) {
		// TODO Auto-generated method stub
		if (null == m_dsmccMessageHeader)
		{
			Log.e(TAG, "parserClientSessionReleaseIndication param is null");
			return ;
		}
		
		if (m_dsmccMessageHeader.m_protocolDiscriminator != 0x11 
				|| m_dsmccMessageHeader.m_dsmccType != 0x02 
				|| m_dsmccMessageHeader.m_messageId != Client_MessageId.TypeClientReleaseConfirm)
		{
			Log.e(TAG, "parserClientSessionReleaseIndication data is error !!!!");
			return ;
		}
	}
	/**
	 * parse the ClientSessionReleaseIndication(CSRI) message from SRM to STB 
	 * @description:
	 * 		the message format:
	 *			ClientReleaseIndication()
	 *			{
	 *				dsmccMessageHeader()
	 *				sessionId		10
	 *				reason		2
	 *				UserData()
	 *			}
	 * @param SSPClientReleaseRequestData
	 * @return void
	 */
	private void parserClientSessionReleaseIndication(DsmccMessageHeader m_dsmccMessageHeader) 
	{
		// TODO Auto-generated method stub
		if (null == m_dsmccMessageHeader)
		{
			Log.e(TAG, "parserClientSessionReleaseIndication param is null");
			return ;
		}
		
		if (m_dsmccMessageHeader.m_protocolDiscriminator != 0x11 
				|| m_dsmccMessageHeader.m_dsmccType != 0x02 
				|| m_dsmccMessageHeader.m_messageId != Client_MessageId.TypeClientReleaseIndication)
		{
			Log.e(TAG, "parserClientSessionReleaseIndication data is error !!!!");
			if (m_dsmccMessageHeader.m_protocolDiscriminator != 0x11)
			{
				Log.e(TAG, "parserClientSessionReleaseIndication m_protocolDiscriminator is error !!!!");
			}
			else if (m_dsmccMessageHeader.m_dsmccType != 0x02 )
			{
				Log.e(TAG, "parserClientSessionReleaseIndication m_dsmccType is error !!!!");
			}
			else if (m_dsmccMessageHeader.m_messageId != Client_MessageId.TypeClientReleaseIndication)
			{
				Log.e(TAG, "parserClientSessionReleaseIndication m_messageId is error !!!!");
			}
			
			
			return ;
		}
		
		//we don't add the CSRIReasonValue, we find 7019 not use it ---- taoanran add 
	}
	/**
	 * parse the ClientSessionReleaseResponse(CSRR) message from SRM to STB 
	 * @param start_npt
	 * @param s_num
	 * @param s_denom
	 * @return boolean
	 */
	private boolean ClientSessionReleaseResponse() {
		// TODO Auto-generated method stub
		Log.v(TAG, "ClientReleaseRequest  ------------- IN");
		int ret = 0;
		
		SSPClientReleaseRequestData sspClientReleaseRequestData = new SSPClientReleaseRequestData();
		sspClientReleaseRequestData.m_dsmHeader = new DsmccMessageHeader();
		sspClientReleaseRequestData.m_sessionId = new SessionId();
		sspClientReleaseRequestData.m_userData = new UserData();
		VodEnum vodEnum = new VodEnum();
		
		//first, get the dmscc's header
		ret = getDsmccMessageHeader(sspClientReleaseRequestData.m_dsmHeader, VodEnum.Client_MessageId.TypeClientReleaseResponse);
		if (-1 == ret)
		{
			Log.e(TAG, "getDsmccMessageHeader error -------[ClientReleaseRequest]");
			return false;
		}
		
		//second, get the sessionId
		 ret = getTheSessionId(sspClientReleaseRequestData.m_sessionId);
		 if (-1 == ret)
		 {
				Log.e(TAG, "getDsmccMessageHeader error -------[ClientReleaseRequest]");
				return false;
		 }
		 
		 //third, get the the reason
		 sspClientReleaseRequestData.m_reason = TearDownCSRRReasonValues.RsnNormal;
		 Log.v(TAG, "sspClientReleaseRequestData.m_reason = " + sspClientReleaseRequestData.m_reason);
		 sspClientReleaseRequestData.m_userData.m_uuDataLength= 0 ;
		 sspClientReleaseRequestData.m_userData.m_privateDataLength = 0 ;

		/*
		 * create/get the ssp(udp) socket for recv/send the ssp message
		 * */
		if (null == m_SSPSocket)
		{
			m_SSPSocket = SSPSocket.getInstance();
		} 
		//send to the socket (m_SRMInfo is come from scanchannel !!!)
		Log.v(TAG, "tmpVodControl.m_SRMInfo.m_SRMIpAddress = " + m_SRMInfo.m_SRMIpAddress);
		if (!m_SSPSocket.ssp_send_sspClientReleaseResponseData(sspClientReleaseRequestData, m_SRMInfo.m_SRMIpAddress, m_SRMInfo.m_SRMPort))
		{
			Log.e(TAG, "m_SSPSocket.DatagramPacket_Send error !!!");
			return false;
		}
		Log.v(TAG, "ClientReleaseRequests  ------------- OUT");
		return true;
	}
	/**
	 * parse the ClientSessionProceedingIndication message(CSPI)
	 * @description: This message is optional for SRM,
	 * 				  and STB should ignore the reason in ClientProceedingIndication message.
	 * @param start_npt
	 * @param s_num
	 * @param s_denom
	 * @return void
	 */
	private void parserClientSessionProceedingIndication(DsmccMessageHeader m_dsmccMessageHeader) 
	{
		// TODO Auto-generated method stub
		if (null == m_dsmccMessageHeader)
		{
			Log.e(TAG, "parserClientSessionProceedingIndication's param is null");
			return ;
		}
		
		if (m_dsmccMessageHeader.m_protocolDiscriminator != 0x11 
				|| m_dsmccMessageHeader.m_dsmccType != 0x02 
				|| m_dsmccMessageHeader.m_messageId != Client_MessageId.TypeClientProceedingIndication)
		{
			Log.e(TAG, "parserClientSessionProceedingIndication's data is error !!!!");
			return ;
		}
	}

	/*
	 * @function:set the SRM server's Info
	 * @descript:include 1.gateway 2.ServiceGroupId 3.SRMIpAddress 4.SRMPort
	 * @param     srmInfo
	 * @return    void
	 */
	public void setSRMInfo(SRMInfoGetFromPMT srmInfo)
	{
		if (m_SRMInfo == null)
		{
			m_SRMInfo = new SRMInfoGetFromPMT();
		}
		m_SRMInfo.m_gateway = srmInfo.m_gateway;
		m_SRMInfo.m_ServiceGroupId = srmInfo.m_ServiceGroupId;
		m_SRMInfo.m_SRMIpAddress = srmInfo.m_SRMIpAddress;
		m_SRMInfo.m_SRMPort = srmInfo.m_SRMPort;
	}
	
	/*
	 * get the ssp session ID, deviceId MAC IP systemTime  must be global unique
	 * systemTime(4byte)+mac(6byte)
	 * 
	 * output:       global SessionId:@m_SessionId
	 * return:       
	 * 				true:  the sizeof SessionID
	 * 				false: -1
	 * */
	private int getTheSessionId (SessionId m_sessionId)
	{
		int ret = 0 ;
		int i;
		String []macSinglePart = new String[6];
	
		if (null == m_sessionId)
		{
			Log.e(TAG, "getTheSessionId's m_sessionId == null");
			return -1;
		}
		//get mac addr (just for debug)
	/*
		String mac = getMacAddr();
		macSinglePart = mac.split(":");
		for (i=0; i<6; i++)
		{
			//like 00:11:22:33:44:55
			m_sessionId.mac[i] = (byte)(Integer.parseInt(macSinglePart[i],16));//get the LSB, to get the mac
			m_SessionId.mac[i] = m_sessionId.mac[i];//remember Current session's information
		}
	*/
		//get mac addr (just for debug) +++++++++++++++++++++++++
		//00:18:95:12:0C:B7
/*		
		m_SessionId.mac[0] = 0x00;
		m_SessionId.mac[1] = 0x18;
		m_SessionId.mac[2] = (byte) 0x95;
		m_SessionId.mac[3] = 0x12;
		m_SessionId.mac[4] = 0x0c;
		m_SessionId.mac[5] = (byte) 0xb7;
*/
		m_sessionId.mac[0] = 0x00;
		m_sessionId.mac[1] = 0x18;
		m_sessionId.mac[2] = (byte) 0x95;
		m_sessionId.mac[3] = 0x12;
		m_sessionId.mac[4] = 0x0c;
		m_sessionId.mac[5] = (byte) 0xb7;
		// ----------------------------------------------------------
		
		//get the system time
		m_sessionId.sysTime = getSysTime();
//		m_SessionId.sysTime = m_sessionId.sysTime;//remember Current session's information
		Log.e(TAG, "getTheSessionId ------- OUT");
		/*
		 * 	sysTime(4byte) + mac(1*6byte) 
		 * */
		return 10;
	}
	//get the system time
	private int getSysTime() {
		int nowTime = (int )(System.currentTimeMillis()/1000);//long -> int
		Log.v(TAG, "nowTime(string) = " + Integer.toHexString(nowTime));
		Log.v(TAG, "nowTime = " + nowTime);
		return nowTime;
	}

	private String getMacAddr() {
		//String mac = null; 
		String  mac = "00:18:95:12:0C:B7";//just for test    
/*		 
		Log.v(TAG, "getMacAddr -----------------");
		
         BufferedReader bufferedReader = null;     
         Process process = null;     
         try {     
               //Unix下的命令，一般取eth0作为本地主网卡 显示信息中包含有mac地址信息    
             process = Runtime.getRuntime().exec("busybox ifconfig eth1");   
             bufferedReader = new BufferedReader(new InputStreamReader(process     
                     .getInputStream()));     
             String line = null;     
             int index = -1;     
             while ((line = bufferedReader.readLine()) != null) {     
                    //寻找标示字符串[hwaddr]     
                 index = line.toLowerCase().indexOf("hwaddr");    
                    //找到了
                 if (index != -1) {     
                	 // 取出mac地址并去除2边空格    
                	 //delete for test----------------------taoanran
                     mac = line.substring(index +"hwaddr".length()+ 1).trim();   
                     break;     
                 }     
             }     
         } catch (IOException e) {     
             e.printStackTrace();     
         } finally {     
             try {     
                 if (bufferedReader != null) {     
                     bufferedReader.close();     
                 }     
             } catch (IOException e1) {     
                e1.printStackTrace();     
            }     
             bufferedReader = null;     
             process = null;     
         }     

  */       
         Log.v(TAG, "mac = " + mac);     
		
		return mac;
	}

	/*
	 * function:set the the URL of movie, now the url only has the AssetID
	 * 
	 * description: now we only support the Numeric AssetID !!!!!
	 * 				the ASCII's Asset will been support later
	 *  
	 * */
	public boolean setAssetId(String AssetId)
	{
		if(null == m_assetIdString)
		{
			m_assetIdString = new String();
		}
		Log.v(TAG, "setAssetId = " + AssetId);
		
		//String tmpAssetIDString = new String();
		//tmpAssetIDString = String.valueOf(Long.toHexString(Long.parseLong(AssetId)));
		m_assetIdString = AssetId;
/*		
		if (tmpAssetIDString.length() < 40)
		{
			int num = tmpAssetIDString.length();
			String tmpStringFill = new String();
			String tmpString = "0000000000000000000000000000000000000000";//40 '0'
			tmpStringFill = tmpString.substring(0, 40 - num);
			m_assetIdString = tmpStringFill +  tmpAssetIDString;
		}
*/
		Log.v(TAG, "m_assetIdString = " + m_assetIdString);
		
		return true;
	}
	
	/*
	 * setup the ssp connect to SRM server
	 * */
	public boolean setUpSspConnect() {
		// TODO Auto-generated method stub
		Log.v(TAG, "setUpSspConnect  ------------- IN");
		/////start set the ssp
		mVodStatus = VodStatus.getInstance();
		//set cmdControl to setUp connect
		mVodStatus.setCmdControlStateMachine(cmdControlStateMachine.SessionSetup);
		
		ClientSessionSetUpRequest();
		Log.v(TAG, "setUpSspConnect  ------------- OUT");
		return true;
	}
	//send the ssp connect request to srm(vod) server
	private boolean ClientSessionSetUpRequest() {
		// TODO Auto-generated method stub
		//VodEnum.Client_MessageId clientMsgId;
		int num = 0;
		int ret = 0;
		
		SSPClientSessionSetUpRequest  tmpSSPClientSessionSetUpRequest = new SSPClientSessionSetUpRequest();
	
		changeTheTransactionId() ;  ///change the sesstionId, just in setup request
		
		ret = getDsmccMessageHeader(tmpSSPClientSessionSetUpRequest.m_dsmHeader, VodEnum.Client_MessageId.TypeClientSessionSetUpRequest) ;
		if (-1 == ret){
			Log.e(TAG, "getDsmccMessageHeader false !!!!");
			return false;
		}
		num += ret;
		
		ret = getTheSessionId(tmpSSPClientSessionSetUpRequest.m_sessionId ) ;
		if (-1 == ret){
			Log.e(TAG, "getTheSessionId false !!!!");
			return false;
		}
		num += ret;
		
		tmpSSPClientSessionSetUpRequest.m_reserved = (short) 0xffff ;
		num += 2;
		
		ret = getClientId(tmpSSPClientSessionSetUpRequest.m_clientId);
		if (-1 == ret)
		{
			Log.e(TAG, "getClientId false !!!!");
			return false;
		}
		num += ret;
/*		
		Log.v(TAG, "tmpSSPClientSessionSetUpRequest.m_clientId.afi = " + tmpSSPClientSessionSetUpRequest.m_clientId.afi);
		Log.v(TAG, "tmpSSPClientSessionSetUpRequest.m_clientId.dsp = " + tmpSSPClientSessionSetUpRequest.m_clientId.dsp);
		Log.v(TAG, "tmpSSPClientSessionSetUpRequest.m_clientId.sel = " + tmpSSPClientSessionSetUpRequest.m_clientId.sel);
		for (int i=0; i<8; i++)
		{
			Log.v(TAG, "tmpSSPClientSessionSetUpRequest.m_clientId.idi = " + tmpSSPClientSessionSetUpRequest.m_clientId.idi[i]);
		}
		for (int i=0; i<6; i++)
		{
				Log.v(TAG, "tmpSSPClientSessionSetUpRequest.m_clientId.mac = " + tmpSSPClientSessionSetUpRequest.m_clientId.mac[i]);
		}
*/		
		
		ret = getServerId(tmpSSPClientSessionSetUpRequest.m_serverId);
		if (-1 == ret)
		{
			Log.e(TAG, "getClientId false !!!!");
			return false;
		}
		num += ret;
		
		ret = ConstructorUserData(tmpSSPClientSessionSetUpRequest.m_userData) ;
		if (-1 == ret)
		{
			Log.e(TAG, "get ConstructorUserData false !!!!");
			return false;
		}
		num += ret;
		
		/// messageLength size change
		tmpSSPClientSessionSetUpRequest.m_dsmHeader.m_messageLength = (short) (num - 12);
		Log.v(TAG, "tmpSSPClientSessionSetUpRequest.m_dsmHeader.m_messageLength = " + tmpSSPClientSessionSetUpRequest.m_dsmHeader.m_messageLength);
		/*
		 * create/get the ssp(udp) socket for recv/send the ssp message
		 * */
		if (null == m_SSPSocket)
		{
			m_SSPSocket = SSPSocket.getInstance();
		} 
		//send to the socket 
		Log.v(TAG, "m_SRMInfo.m_SRMIpAddress = " + m_SRMInfo.m_SRMIpAddress);
		if (!m_SSPSocket.ssp_send_ClientSessionSetUpRequestData(tmpSSPClientSessionSetUpRequest, m_SRMInfo.m_SRMIpAddress, m_SRMInfo.m_SRMPort))
		{
			Log.e(TAG, "m_SSPSocket.DatagramPacket_Send error !!!");
			return false;
		}
		
		return true;
	}
	/*
	 * set the UserData
	 * return:  the size of userdata
	 * discription:  	serverID = afi(1byte) + idi(1byte*8) + dsp(4byte) + mac(1byte*6) + sel(1byte)
	 * */
	private int ConstructorUserData(ClientSessionSetupRequestBody data) {
		// TODO Auto-generated method stub
		int size = 0 ;
		
		if (null == data)
		{
			data = new ClientSessionSetupRequestBody();
		}

		//ClientSessionSetupRequestBody.AssetID tmpAsset = data.new AssetID();
		//ClientSessionSetupRequestBody.NodeGroupId tmpNodeGroupId = data.new NodeGroupId();
		data.m_uuDataLength = 0x00;   	//m_uuDataLength == 0
		size += 2;
		data.m_privateDataLength = 0x0056 ;
		size += 2;
		data.m_protocolID = (byte) 0xf1;
		size += 1;
		data.m_version = (byte) 0x01;
        size += 1;
        data.m_descriptorCount = 0x03;
        size += 1;
        //assetID
        size += getAsset(data.m_assetID);
        //groupID
        size += getGroupId(data.m_nodeGroupID);
        Log.v(TAG, "getGroupId(tmpNodeGroupId) ------- 11111");
        size += getAppRequestRequestData(data);
        Log.v(TAG, "getAppRequestRequestData ------------------------- 222222222");
        
    	/// messageLength size change
        data.m_privateDataLength = (short) (size - 4);
        
        Log.v(TAG, "data.m_privateDataLength = " + data.m_privateDataLength);
        
		return size;
	}
	//little-endian:groupID data
	private int getGroupId(NodeGroupId tmp) {
		// TODO Auto-generated method stub
		if (null == tmp)
		{
			Log.e(TAG, "getGroupId's param ---- tmpNodeGroupId == null !!!!!");
			return -1;
		}
		
        String tmpServiceGroupId = new String();
        byte tmpServerID[] = new byte[2];
        
        tmpServiceGroupId = Short.toString((short)(Integer.parseInt(Integer.toHexString(m_SRMInfo.m_ServiceGroupId))));
        Log.v(TAG, "tmpServiceGroupId = " + m_SRMInfo.m_ServiceGroupId);
        Log.v(TAG, "tmpServiceGroupId(Integer.toHexString) = " + Integer.toHexString(m_SRMInfo.m_ServiceGroupId));
        Log.v(TAG, "tmpServiceGroupId(int) = " + Integer.parseInt(Integer.toHexString(m_SRMInfo.m_ServiceGroupId)));
        Log.v(TAG, "tmpServiceGroupId(String) = " + tmpServiceGroupId);
        byte tmpbyte1 ;
        byte tmpbyte2 ;
        String tmpString = "";
        if (tmpServiceGroupId.length() < 4)
        {
        	for (int i=0; i<4-tmpServiceGroupId.length(); i++)
        	{
        		tmpString += "0";
        	}
        	tmpServiceGroupId = tmpString + tmpServiceGroupId;
        	Log.v(TAG, "tmpServiceGroupId = " + tmpServiceGroupId);
        }
        for (int i=0, j=0; i<tmpServiceGroupId.length(); i += 2, j++)
		{	
			tmpbyte1 = (byte) tmpServiceGroupId.charAt(i);
			tmpbyte2 = (byte) tmpServiceGroupId.charAt(i+1);
			if (tmpbyte1 >= '0' && tmpbyte1 <= '9')
			{
				//System.out.print((byte)(tmpbyte1 - '0') + "\n");
				tmpbyte1 = (byte) (tmpbyte1 - '0');
			}
			else
			{
				//System.out.print((byte)(tmpbyte1 - 'a' + 10)+ "\n");
				tmpbyte1 = (byte)(tmpbyte1 - 'a' + 10);
			}
			
			if (tmpbyte2 >= '0' && tmpbyte2 <= '9')
			{
				tmpbyte2 = (byte) (tmpbyte2 - '0');
				//System.out.print((byte)(tmpbyte2 - '0') + "\n");
			}
			else
			{
				tmpbyte2 = (byte)(tmpbyte2 - 'a' + 10);
				//System.out.print((byte)(tmpbyte2 - 'a' + 10)+ "\n");
			}
			
			tmpServerID[j] = (byte) ((tmpbyte1 << 4) | tmpbyte2);
			Log.v(TAG, "tmpServerID[j] = " + tmpServerID[j]);
			//System.out.print("tmpByte = "+ tmpByte + "\n");
		}
        
        
		tmp.tag = 0x02;
        tmp.datelength = 6;
        tmp.data[4] = tmpServerID[0];
        tmp.data[5] = tmpServerID[1];
        Log.v(TAG, "getGroupID -------------- out");
		return (1+1+4+2);
	}

	private int getAsset(ClientSessionSetupRequestBody.AssetID tmp) {
		// TODO Auto-generated method stub
	//// assertIdString which get from epg or other place 
		tmp.tag = 0x01;
	/*	datelength
		if ( m_assetIdString != null )
		{
			if (m_assetIdString.length()%2 == 0)
				tmp.datelength = (byte) (m_assetIdString.length()/2);
			else//we will fill '0'
				tmp.datelength = (byte)(( m_assetIdString.length() + 1)/2);
		}
		else
			tmp.datelength = 0;
		*/
		tmp.datelength = (byte) ( m_assetIdString.length()/2);//2位表示一个bit
		Log.v(TAG, "getAsset = " + m_assetIdString);
		tmp.data = m_assetIdString;
		
		return 1+1+tmp.datelength;
	}

	private int getAppRequestRequestData(ClientSessionSetupRequestBody tmp) {
		// TODO Auto-generated method stub
		if (null == tmp)
		{
			Log.e(TAG, "getAppRequestRequestData's param == null");
			return -1;
		}
		Log.v(TAG, "---getAppRequestRequestData------------1111111--------------------");
		int size = 0;

		///ClientSessionSetupRequestBody tmpClientSessionSetupRequestBody = new ClientSessionSetupRequestBody();
		//ClientSessionSetupRequestBody.ApplicationRequestData tmpApplicationRequestData = tmp.new ApplicationRequestData();
		//ClientSessionSetupRequestBody.ApplicationRequestData.AppDescInfo tmpAppDescInfo[] = new ClientSessionSetupRequestBody.ApplicationRequestData.AppDescInfo[8];
		Log.v(TAG, "---getAppRequestRequestData------------222222222--------------------");
		for (int i=0; i<8; i++){
			tmp.m_applicationRequestData.m_appDescInfo[i].appDescLength = 0x04;
		}
		tmp.m_applicationRequestData.m_appDescInfo[0].appDescdata = 1;
		tmp.m_applicationRequestData.m_appDescInfo[1].appDescdata = 2;
		tmp.m_applicationRequestData.m_appDescInfo[2].appDescdata = 3;
		tmp.m_applicationRequestData.m_appDescInfo[3].appDescdata = 8;
		tmp.m_applicationRequestData.m_appDescInfo[4].appDescdata = 4;
		tmp.m_applicationRequestData.m_appDescInfo[5].appDescdata = 5;
		tmp.m_applicationRequestData.m_appDescInfo[6].appDescdata = 6;
		tmp.m_applicationRequestData.m_appDescInfo[7].appDescdata = 7;
		
		Log.v(TAG, "---getAppRequestRequestData------------333333333333333333--------------------");
		tmp.m_applicationRequestData.m_appDescInfo[0].appDescTag = 0x07;
		tmp.m_applicationRequestData.m_appDescInfo[1].appDescTag = 0x09;
		tmp.m_applicationRequestData.m_appDescInfo[2].appDescTag = 0x04;
		tmp.m_applicationRequestData.m_appDescInfo[3].appDescTag = 0x08;
		tmp.m_applicationRequestData.m_appDescInfo[4].appDescTag = 0x05;
		tmp.m_applicationRequestData.m_appDescInfo[5].appDescTag = 0x03;
		tmp.m_applicationRequestData.m_appDescInfo[6].appDescTag = 0x06;
		tmp.m_applicationRequestData.m_appDescInfo[7].appDescTag = 0x0d;
		//return to the ConstructorUserData
		tmp.m_applicationRequestData.descriptorTag = 0x05;     //tag
		tmp.m_applicationRequestData.descriptorLength = 0x33;  //Descriptor length
		tmp.m_applicationRequestData.protocol = 0x01; //protocol
		tmp.m_applicationRequestData.version = 0x01;  //version
		tmp.m_applicationRequestData.count = 0x08;    //count
		size += 5;
		Log.v(TAG, "---getAppRequestRequestData------------4444444444444--------------------");
		for (int i=0; i<8; i++)
		{
			size += (2 + 4);
		}

		return size;
	}

	/*
	 * set the serverID into the global serverID
	 * return:  the size of serverID
	 * discription:  	serverID = afi(1byte) + idi(1byte*8) + dsp(4byte) + mac(1byte*6) + sel(1byte)
	 * */
	private int getServerId(ServerId tmpServerID ) {
		// TODO Auto-generated method stub
		if (null == tmpServerID)
		{
			Log.e(TAG, "getServerId tmpServerID == null");
			return -1;
		}
		
		tmpServerID.afi = 0x2d ;
		for (int i=0; i<8; i++)
		{
			tmpServerID.idi[i] = 0;
		}
		///session gateway Ip address, will be get in the pmtif (null == m_SRMInfo)
		if (null == m_SRMInfo)
		{
			m_SRMInfo = new SRMInfoGetFromPMT();
		}
		Log.v(TAG, "[656line]m_SRMInfo.m_gateway = " + m_SRMInfo.m_gateway);
		
/////////////////++++++++++++++++++++++++/////////////
		String []tmpGWString = new String[4];
		tmpGWString = m_SRMInfo.m_gateway.split("\\.");
		byte []tmpGateWay = new byte[4];
		int tmpGateWay_integer = 0;
		for (int i=0; i<4; i++)
		{
			Log.v(TAG, "tmpGWString =  " + tmpGWString[i]);
			tmpGateWay[i] = (byte)(Integer.parseInt(tmpGWString[i],16));
			Log.v(TAG, "get the gateway(byte) = " + tmpGateWay[i]);
		}
		//transform IP's format (byte -> int)
		tmpGateWay_integer = NetFormatTransform.bytes2Integer(tmpGateWay);
		Log.v(TAG, "tmpGateWay_integer(Integer) = " + tmpGateWay_integer);
///////////////---------------------------////////////	
		
		tmpServerID.dsp = tmpGateWay_integer;
		tmpServerID.sel = 0x00 ;
		for (int i=0; i<6; i++)
		{
			tmpServerID.mac[i] = m_Mac[i];
		}
		
		return 20;
	}

	/*
	 * return: the size of the ClientID
	 * discription:  	afi(1byte) + idi(1byte*8) + dsp(1byte*4) + mac(1byte*6) + sel(1byte) == 20byte
	 * */
	private int getClientId(ClientId tmpClientId) {
		// TODO Auto-generated method stub
		if (null == tmpClientId)
		{
			Log.e(TAG, "getClientId's param is null");
			return -1;
		}
		
		if(tmpClientId.afi == 0)
		{
			tmpClientId.afi = 0x2d ;
			for (int i=0; i<8; i++)
			{
				tmpClientId.idi[i]	 = 0 ;
			}
			
			tmpClientId.dsp = m_IP;//htonl(ipAddr); ///client Ip address
		
			for (int i=0; i<6; i++)
			{
				tmpClientId.mac[i] = m_Mac[i];
			}
			tmpClientId.sel = 0x00 ;
		}
		
		return 20;
	}

	//the session(ssp)'s TransactionId, will be increase 1 auto 
	private boolean changeTheTransactionId() {
		// TODO Auto-generated method stub
		m_transactionId++ ;
		return true;
	}	
	/*
	 * tear down the ssp connect to SRM server
	 * */
	public boolean tearDownSspSetupRequest() 
	{
		Log.v(TAG, "tearDownSspSetupRequest  ------------- IN");
		//tear down 
		mVodStatus = VodStatus.getInstance();
		mVodStatus.setCmdControlStateMachine(VodStatus.cmdControlStateMachine.TearDown);//set cmdControl to tearDown
		if (!ClientReleaseRequest(VodEnum.TearDownCSRRReasonValues.RsnNormal))  //release the alive ssp , maybe it is not exist 
		{
			Log.e(TAG, "ClientReleaseRequest error !!!!!");
			return false;
		}
		Log.v(TAG, "tearDownSspSetupRequest  ------------- OUT");
		return true;
	}
	/*
	 * send the ClientReleaseRequest(tear down)to SRM server, for teardown the ssp connect
	 * */
	public boolean ClientReleaseRequest(short tearDownCSRRReasonValues) 
	{
		Log.v(TAG, "ClientReleaseRequest  ------------- IN");
		int ret = 0;
		
		SSPClientReleaseRequestData sspClientReleaseRequestData = new SSPClientReleaseRequestData();
		
		//first, get the dmscc's header
		ret = getDsmccMessageHeader(sspClientReleaseRequestData.m_dsmHeader, VodEnum.Client_MessageId.TypeClientReleaseRequest);
		if (-1 == ret)
		{
			Log.e(TAG, "getDsmccMessageHeader error -------[ClientReleaseRequest]");
			return false;
		}
		
		//second, get the sessionId
		 ret = getTheSessionId(sspClientReleaseRequestData.m_sessionId);
		 if (-1 == ret)
		 {
				Log.e(TAG, "getDsmccMessageHeader error -------[ClientReleaseRequest]");
				return false;
		 }
		 
		 //third, get the the reason
		 sspClientReleaseRequestData.m_reason = tearDownCSRRReasonValues;
		 Log.v(TAG, "sspClientReleaseRequestData.m_reason = " + sspClientReleaseRequestData.m_reason);
		 sspClientReleaseRequestData.m_userData.m_uuDataLength= 0 ;
		 sspClientReleaseRequestData.m_userData.m_privateDataLength = 0 ;

		/*
		 * create/get the ssp(udp) socket for recv/send the ssp message
		 * */
		if (null == m_SSPSocket)
		{
			m_SSPSocket = SSPSocket.getInstance();
		} 
		//send to the socket (m_SRMInfo is come from scanchannel !!!)
		Log.v(TAG, "tmpVodControl.m_SRMInfo.m_SRMIpAddress = " + m_SRMInfo.m_SRMIpAddress);
		if (!m_SSPSocket.ssp_send_sspClientReleaseRequestData(sspClientReleaseRequestData, m_SRMInfo.m_SRMIpAddress, m_SRMInfo.m_SRMPort))
		{
			Log.e(TAG, "m_SSPSocket.DatagramPacket_Send error !!!");
			return false;
		}
		Log.v(TAG, "ClientReleaseRequests  ------------- OUT");
		return true;
	}
	
	/*
	 * get the DsmccMessageHeader
	 * param: @m_dsmHeader:the dsmcc's header(outPut data)
	 * return: size of DsmccMessageHeader
	 * */
	private int getDsmccMessageHeader(DsmccMessageHeader m_dsmHeader , short typeclientsessionsetuprequest)
	{
		int size = 0;
		
		Log.v(TAG, "getDsmccMessageHeader  ------------- IN");
		
		if (null == m_dsmHeader)
		{
			Log.v(TAG, "getDsmccMessageHeader's m_dsmHeader == NULL");
			return -1;
		}
		

		m_dsmHeader.m_protocolDiscriminator = (byte)0x11 ;  //fix page 22
		m_dsmHeader.m_dsmccType = 0x02 ; 

		//java may be not need little/big edit
		//getTransactionId(sspReleaseRequestData.m_dsmHeader.m_transactionId);  ///should increase one step automatically  page  23
		m_dsmHeader.m_transactionId = m_transactionId;
		m_dsmHeader.m_reserved = (byte) 0xff ;//may be has problem!!!!!----taoanran
		m_dsmHeader.m_adaptationLength = 0x00 ;   /// the total length in bytes of the adaptation header.

		if ( VodEnum.Client_MessageId.TypeClientSessionSetUpRequest == typeclientsessionsetuprequest)
		{
			m_dsmHeader.m_messageId = VodEnum.Client_MessageId.TypeClientSessionSetUpRequest;//htons(cmid) ;
			m_dsmHeader.m_messageLength = 0x008e;///htons(0x008e) ;
		}
		else if ( VodEnum.Client_MessageId.TypeClientReleaseRequest == typeclientsessionsetuprequest)
		{		
			m_dsmHeader.m_messageId = VodEnum.Client_MessageId.TypeClientReleaseRequest;//htons(cmid) ;
			m_dsmHeader.m_messageLength = 0x0010;///htons(0x0010) ;
		}
		else if ( VodEnum.Client_MessageId.TypeClientSessionInProgressRequest == typeclientsessionsetuprequest)
		{		
			m_dsmHeader.m_messageId = VodEnum.Client_MessageId.TypeClientSessionInProgressRequest;//htons(cmid) ;
			m_dsmHeader.m_messageLength = 0x000c;///htons(0x000c) ;
		}		
		else if ( VodEnum.Client_MessageId.TypeClientReleaseResponse == typeclientsessionsetuprequest)
		{		
			m_dsmHeader.m_messageId = VodEnum.Client_MessageId.TypeClientReleaseResponse;//htons(cmid) ;
			m_dsmHeader.m_messageLength = 0x0010;///htons(0x0010) ;
		}

		if(m_dsmHeader.m_adaptationLength != 0)  ///it looks like that all the m_adaptationLength==0 
		{

		}
		/*
		 * size = protocol(1byte) + m_dsmccType(1byte) + m_messageId(2byte)
		 * 		+ m_transactionId(4byte) + m_reserved(1byte) 
		 * 		+ m_adaptationLength(1byte) + m_messageLength(2byte)
		 * 
		 * discription: now DsmccAdaptationHeader is empty
		 * */
		size = 12;
		Log.v(TAG, "getDsmccMessageHeader  ------------- OUT");
		
		return size;
	}
	
	/*
	 * send the play command to SRM server, and start play
	 * */
	public void cableMpegPlay(int startTimer,int scaleNum, int scaleDenom)
	{
		Log.v(TAG, "in the cableMpegPlay 111------------");

		if (m_lscpClient == null)
		{
			m_lscpClient = new LSCP_Client();
		}

		if (startTimer == 0)
		{
			int i = 0;
			
			while(i < 3)
			{
				Log.v(TAG, "m_lscpClient.lscp_send_play---------");
				m_lscpClient.setResponseWaitTime(lscpTimerStep[2*i],lscpTimerStep[2*i+1]) ;
				if(m_lscpClient.lscp_send_play(Long.parseLong("80000000", 16),0x7fffffff,scaleNum,scaleDenom) == 0 )
				{						
					break ;
				}
				i++ ;
			}
			if(3 == i)
			{
				///should release the ssp
				Log.v(TAG, "cableMpegPlay will tear down");
				mVodStatus = VodStatus.getInstance();
				mVodStatus.setCmdControlStateMachine(VodStatus.cmdControlStateMachine.TearDown);
				ClientReleaseRequest(TearDownCSRRReasonValues.RsnNormal) ;
				// add by zhengwei to finished Receive Done Thread
				m_lscpClient.setSession_over(true);
			}
		}
		else  ///seek and play 
		{
			int i = 0 ;
			while(i < 3)
			{
				Log.v(TAG, "try " + i + " time to send resume");
				m_lscpClient.setResponseWaitTime(lscpTimerStep[2*i],lscpTimerStep[2*i+1]) ;
				if(m_lscpClient.lscp_send_resume(startTimer,scaleNum,scaleDenom) == 0 )   ///shall we need to play ?  fixed me ?
				{						
					break ;
				}
				i++ ;
			}
			if(i == 3)
			{
				///should release the ssp
				mVodStatus = VodStatus.getInstance();
				mVodStatus.setCmdControlStateMachine(VodStatus.cmdControlStateMachine.TearDown);

				ClientReleaseRequest(TearDownCSRRReasonValues.RsnNormal) ; 
			}
		}
		
		Log.v(TAG, "in the cableMpegPlay -------OUT");
	}
	
	
	
	//ssp heartbeat
	public void ClientSessionInProgress() {
		// TODO Auto-generated method stub
		int num = 0;
		int ret = 0;
		
		ClientSessionInProgressData  tmpClientSessionInProgressData = new ClientSessionInProgressData();
	
		changeTheTransactionId() ;  ///change the sesstionId, just in setup request
		
		ret = getDsmccMessageHeader(tmpClientSessionInProgressData.m_dsmHeader, VodEnum.Client_MessageId.TypeClientSessionInProgressRequest) ;
		if (-1 == ret){
			Log.e(TAG, "getDsmccMessageHeader false !!!![ClientSessionInProgress]");
			return ;
		}
		num += ret;
		
		tmpClientSessionInProgressData.m_sessionCount = 0x0001;
		
		ret = getTheSessionId(tmpClientSessionInProgressData.m_sessionId ) ;
		if (-1 == ret){
			Log.e(TAG, "getTheSessionId false !!!!");
			return ;
		}
		num += ret;
		
		/*
		 * create/get the ssp(udp) socket for recv/send the ssp message
		 * */
		if (null == m_SSPSocket)
		{
			m_SSPSocket = SSPSocket.getInstance();
		} 
		//send to the socket 
		Log.v(TAG, "m_SRMInfo.m_SRMIpAddress = " + m_SRMInfo.m_SRMIpAddress);
		if (!m_SSPSocket.ssp_send_ClientSessionInProgress(tmpClientSessionInProgressData, m_SRMInfo.m_SRMIpAddress, m_SRMInfo.m_SRMPort))
		{
			Log.e(TAG, "m_SSPSocket.DatagramPacket_Send error !!!");
			return ;
		}
	}
	public void cableMpegClose() {
		// TODO Auto-generated method stub
		if (m_lscpClient == null)
		{
			m_lscpClient = new LSCP_Client();
		}
		
		if (m_lscpClient != null)
		{
			int i = 0;
			
			while(i < 3)
			{
				m_lscpClient.setResponseWaitTime(lscpTimerStep[2*i],lscpTimerStep[2*i+1]) ;
				if(m_lscpClient.lscp_send_reset() == 0)
				{						
					break ;
				}
				i++ ;
			}
			if(3 == i)
			{
				///should release the ssp
				Log.v(TAG, "cableMpegPlay will tear down");
				mVodStatus = VodStatus.getInstance();
				mVodStatus.setCmdControlStateMachine(VodStatus.cmdControlStateMachine.TearDown);
				ClientReleaseRequest(TearDownCSRRReasonValues.RsnNormal) ; 
			}
		}
		else
		{
			Log.v(TAG, "lscp did not init success !");
		}
	}
	
	/**
	 * release now LSCPSession, set the lscpHandle = null
	 * @return
	 */
	public void releaseLSCPSession() {
		// TODO Auto-generated method stub
		m_lscpClient.setSession_over(true);
		m_lscpClient = null;
	}


}
