package com.hansun.vod.struct;

/**
 * name:        SetupConfirm
 * function:    SetupConfirm's data, use to STB Store the ClientSessionSetupConfirm(SSP)'s data,
 * 				such as vod mpeg info, ts info and so on
 *				
 * author:      taoanran
 * time:        2012.12.06
 * */
public class SetupConfirm {
	public Eri_info E_info;
	public Mpeg_info M_info;
	public Head_end_info H_info;
	public Ts_info T_info;
	public Comm_info C_info;
	public Ats_info A_info;
	public Lsc_data_des_count LscDataDesCount;
	public Lsc_data Lscdata;
	
	//Ethernet Interface resource info
	public class Eri_info
	{
		public short resource_request_id;
		public short resource_des_type;
		public short resource_num;
		public short assi_tag;
		public short resource_flag;
		public byte resource_status;
		public byte resource_field_len;
		public short resource_count;
		public int source_port; 
		public int source_ip;
		public int source_mac;
		public int dst_port; 
		public int dst_ip;
		public int dst_mac;
		
		public Eri_info()
		{
			 resource_request_id = 0;
			 resource_des_type = 0;
			 resource_num = 0;
			 assi_tag = 0;
			 resource_flag = 0;
			 resource_status = 0;
			 resource_field_len = 0;
			 resource_count = 0;
			 source_port = 0; 
			 source_ip = 0;
			 source_mac = 0;
			 dst_port = 0; 
			 dst_ip = 0;
			 dst_mac = 0;
		}
	}
	
	//Mpeg resource info
	public class Mpeg_info
	{
		public short resource_request_id;
		public short resource_des_type;
		public short resource_num ;
		public short assi_tag ;
		public short resource_flag ;
		public byte resource_status ;
		public byte resource_field_len ;
		public short resource_count;
		public short mpeg_num ;
		public short mpeg_pmt_pid ;
		public short mpeg_ca_pid;
		public short stream_count;
		public short mpeg_pcr;
		 
		public Mpeg_info()
		{
			  resource_request_id = 0;
			  resource_des_type = 0;
			  resource_num = 0;
			  assi_tag = 0;
			  resource_flag = 0;
			  resource_status = 0;
			  resource_field_len = 0;
			  resource_count = 0;
			  mpeg_num = 0;
			  mpeg_pmt_pid = 0;
			  mpeg_ca_pid = 0;
			  stream_count = 0;
			  mpeg_pcr = 0;
		}
	}
	//HeadEnd resource info
	public class Head_end_info
	{
		public short resource_request_id;
		public short resource_des_type;
		public short resource_num;
		public short assi_tag;
		public short resource_flag;
		public byte resource_status;
		public byte resource_field_len;
		public short resource_count;
		public short head_end_flag;
		public head_end_id hei;
		public short transport_stream_id; 
		
		
		public class head_end_id
		{
			public byte afi;
			public byte idi[];
			public int dsp;
			public byte esi[];
			public byte sel;
			
			public head_end_id()
			{
				 afi = 0;
				 idi = new byte[8];
				 dsp = 0;
				 esi = new byte[6];
				 sel = 0;
			}
		}
		
		public Head_end_info()
		{
			resource_request_id = 0x00;
			resource_des_type = 0x00;
			resource_num = 0x00;
			assi_tag = 0x00;
			resource_flag = 0x00;
			resource_status = 0x00;
			resource_field_len = 0x00;
			resource_count = 0x00;
			head_end_flag = 0x00;
			hei = new head_end_id();
			transport_stream_id = 0x00; 
		}
	}
	//TSDownStreamBandwith Resource info
	public class Ts_info
	{
		public short resource_request_id;
		public short resource_des_type;
		public short resource_num;
		public short assi_tag;
		public short resource_flag;
		public byte resource_status;
		public byte resource_field_len;
		public short resource_count;
		public int bandwidth;
		public int transport_id;
		
		public Ts_info()
		{
			resource_request_id = 0;
			resource_des_type = 0;
			resource_num = 0;
			assi_tag = 0;
			resource_flag = 0;
			resource_status = 0;
			resource_field_len = 0;
			resource_count = 0;
			bandwidth = 0;
			transport_id = 0;
		}
	}
	//commonDescriptorHeader info
	public class Comm_info
	{
		public short resource_request_id;
		public short resource_des_type;
		public short resource_num;
		public short assi_tag;
		public short resource_flag;
		public byte resource_status;
		public byte resource_field_len;
		public short resource_count;
		public int channel_id;
		public short direction;
		
		public Comm_info()
		{
			resource_request_id = 0;
			resource_des_type = 0;
			resource_num = 0;
			assi_tag = 0;
			resource_flag = 0;
			resource_status = 0;
			resource_field_len = 0;
			resource_count = 0;
			channel_id = 0;
			direction = 0;
		}
	}
	//AtscModulation Resource info
	public class Ats_info
	{
		public short resource_request_id;
		public short resource_des_type;
		public short resource_num;
		public short assi_tag;
		public short resource_flag;
		public byte resource_status;
		public byte resource_field_len;
		public short resource_count;
		public byte transmission_system;
		public byte coding_mode;
		public byte split_bitmode;
		public byte mod_format;
		public int sym_rate;
		public byte resert;
		public byte depth;
		public byte modu_mode;
		public byte forwrd;
		
		public Ats_info()
		{
			resource_request_id = 0;
			resource_des_type = 0;
			resource_num = 0;
			assi_tag = 0;
			resource_flag = 0;
			resource_status = 0;
			resource_field_len = 0;
			resource_count = 0;
			transmission_system = 0;
			coding_mode = 0;
			split_bitmode = 0;
			mod_format = 0;
			sym_rate = 0;
			resert = 0;
			depth = 0;
			modu_mode = 0;
			forwrd = 0;
		}
	}
	
	public class Lsc_data
	{
		public short port;
		public int ip;
		public int stream_handle;
		public byte billing[];
		public byte home_id[];
		public byte pur_id[];
		public int remain_time;
		public byte smart_id[];
		public int heartBeatTime ;
		public int lscpIpProtocol ;
		
		public Lsc_data()
		{
			port = 0;
			ip = 0;
			stream_handle = 0;
			billing = new byte[5];
			home_id = new byte[5];
			pur_id = new byte[5];
			remain_time = 0;
			smart_id = new byte[5];
			heartBeatTime = 0;
			lscpIpProtocol = 0;
			
			for (int i=0; i<5; i++)
			{
				billing[i] = 0;
				home_id[i] = 0;
				pur_id[i] = 0;
				smart_id[i] = 0;
			}
		}
	}
	
	public class Lsc_data_des_count
	{
		public int des_count;
		
		public Lsc_data_des_count()
		{
			des_count = 0;
		}
	}
	
	public SetupConfirm()
	{
		E_info = new Eri_info();
		M_info = new Mpeg_info();
		H_info = new Head_end_info();
		T_info = new Ts_info();
		C_info = new Comm_info();
		A_info = new Ats_info();
		Lscdata = new Lsc_data();
		LscDataDesCount = new Lsc_data_des_count();
	}
}
