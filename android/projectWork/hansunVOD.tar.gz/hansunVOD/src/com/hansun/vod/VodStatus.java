package com.hansun.vod;

import android.util.Log;

/*
 * className:   VodStatus
 * function:    1.vod status of vod 
 * 				it remember all kinds of vod status.
 * 				
 * descript:    it is a singleton class 
 * author:      taoanran
 * createTime:  2012-11-26
 * */
public class VodStatus {
	private final static String TAG = "VodStatus";
	
	//mediaplayer's status
	public interface PlayStateMachine {
		short   Init = 0x00,//0x00
				Ready = 0x01,//0x01
				Play = 0x02,//0x02
				Pause = 0x03,//0x03
				FastStep = 0x04,//0x04
				NoInit = 0x05;//not been inited
	};
	//stbCMDControl's status
	public interface cmdControlStateMachine{
		short 	Init = 0x01,
				TearDown = 0x02,  //cmdControl tear down
				SessionSetup = 0x03,//0x03 ssp 
				LSCPState = 0x04,   //0x04 lscp
				End = 0x05 ;        //0x05
	}
	
	private short m_playState;//status of player
	private short m_cmdControlStateMachine ;
	
	private static VodStatus instance = null;

	public static VodStatus getInstance() {
		if (instance == null)
		{
			instance = new VodStatus();
		}
		return instance;
	}
	/*
	 * set/get getPlayerState ++++++++++++++++++++
	 * */	
	public short getPlayerState()
	{
		return m_playState;
	}
	public void setPlayerState(short status)
	{
		if (status < 0 || status > 6)
		{
			Log.e(TAG, "setPlayerState's status value is error!!!!");
			return;
		}
		
		m_playState = status;
	}
	// ------------------------------------------
	
	/*
	 * set/get getPlayerState ++++++++++++++++++++
	 * */	
	public short getCmdControlStateMachine()
	{
		return m_cmdControlStateMachine;
	}
	public void setCmdControlStateMachine(short status)
	{
		if (status < 1 || status > 5)
		{
			Log.e(TAG, "setCmdControlStateMachine status value is error!!!!");
			return;
		}
		
		m_cmdControlStateMachine = status;
	}
	// ------------------------------------------
	private VodStatus() {
		// TODO Auto-generated method stub
		m_playState = PlayStateMachine.NoInit;
	}
}
