package com.hansun.vod;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.http.util.EncodingUtils;

import com.hansun.vod.VodControl.CallBack;

import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.webkit.CacheManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

@SuppressLint({ "NewApi", "NewApi", "NewApi", "NewApi", "NewApi", "NewApi", "NewApi", "NewApi" })
public class MainActivity extends Activity {
	private final static String TAG = "VodControl";
	private static WebView mWebView = null;//only one webview
	private Handler mHandler = new Handler();
/*
	final String js_for_new = "javascript: (function (){"
	+ "var newscript = document.createElement(\"script\");"
	+ "newscript.type ='text/javascript';"
	+ "newscript.text=\"vod = new VODControl();\";"
	+  "document.getElementsByTagName('head')[0].appendChild(newscript);" 
	+ "})() ;";
	
	final String js_for_vod_head = "javascript: (function (){"
	+ "var newscript = document.createElement(\"script\");"
	+ "newscript.type ='text/javascript';"
	+ "newscript.text=\"function VODControl(){ vod = VOD;}\";"
	+  "document.getElementsByTagName('head')[0].appendChild(newscript);" 
	+ "})() ;"; 

	final String js_for_vod = "javascript: (function (){"
	+ "var newscript = document.createElement(\"script\");"
	+ "newscript.type ='text/javascript';"
	+ "newscript.text=\"function VODControl(){ return VOD;}\";"
	+  "document.getElementsByTagName('head')[0].appendChild(newscript);" 
	+ "})() ;";
	
	final String js_for_vod_body = "javascript: (function (){"
	+ "var newscript = document.createElement(\"script\");"
	+ "newscript.type ='text/javascript';"
	+ "newscript.text=\"function VODControl(){ vod = VOD;}\";"
	+  "document.getElementsByTagName('body')[0].appendChild(newscript);" 
	+ "})() ;";
*/
	//auto insert the js into the HTML
	final String js_for_vod = "javascript:(function VODControl(){vod = VOD;})()";
	final String js_for_vod_getConfig = "javascript: (function (){"
	+ "var newscript = document.createElement(\"script\");"
	+ "newscript.type ='text/javascript';"
	+ "newscript.text=\"function VODControl(){ return VOD;}\";"
	+  "document.getElementsByTagName('head')[0].appendChild(newscript);" 
	+ "})() ;";
    @SuppressLint("NewApi")
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.v(TAG, "taoanran's webview start");
        setContentView(R.layout.activity_main);
        mWebView = (WebView) findViewById(R.id.webView1);
        
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true); 
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectDiskReads().detectDiskWrites().detectNetwork().penaltyLog().build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectLeakedSqlLiteObjects().penaltyLog().penaltyDeath().build());
       // mWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        mWebView.setBackgroundColor(Color.TRANSPARENT);
        WebViewClient mWebViewClient = new WebViewClient()
        {
        	public void onLoadResource(WebView view, String url)
        	{
        		Log.v(TAG, url);
		        view.loadUrl(js_for_vod_getConfig);//just for setCableMPEGConfigsss---taoanran add
				super.onLoadResource(view, url);
        	}
        	
        	public void onPageStarted(WebView view ,String url){
				 Log.v(TAG,"onPageStarted"+url);
							 
				 super.onPageStarted(view, url, null);
				
			 }
        	
        	public void onPageFinished(WebView view, String url)
			  {
		          Log.v("sk","page finishi " +url);
				 
				 //mWebView.stringByEvaluatingJavaScriptFromString(js);

		         view.loadUrl(js_for_vod);
				 super.onPageFinished(view, url);
			  }
        }; 
        
        mWebView.setWebChromeClient(new WebChromeClient(){
            public void onConsoleMessage(String message, int lineNumber,String sourceID) {
                //Log.d("MyApplication", message + " -- From line "+ lineNumber + " of " + sourceID);
                super.onConsoleMessage(message, lineNumber, sourceID);
               
            }
            public void onProgressChanged(WebView view, int newProgress) {
                	//String v = view.getUrl();
                	Log.d(TAG,"progress" + newProgress);
                	//if( v.contains("html")) {
                		//view.loadUrl(js_for_simple);
                	
                	//}
                
                }

        });

        mWebView.setWebViewClient(mWebViewClient);
        mWebView.addJavascriptInterface(VodControl.getInstance(), "VOD");
        VodControl.getInstance().setmCB(new CallBack() {
			@Override
			public void notifyed() {
				startVideo();
			}        	
        });
		//mWebView.addJavascriptInterface(new EnReach(), "enreach");
       // mWebView.loadUrl("javascript:" + js_for_vod);
        
		//loadUrl(VOD url) +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//mWebView.loadUrl("http://192.168.0.112/taoanran/sk1.html");//test url
		//mWebView.loadUrl("http://192.168.0.112/taoanran/movie_new.html");//test url
		//suzhou broadcast VOD url 
		mWebView.loadUrl("http://itv.njcatv.net/vpg/show.do?&action=show&pageID=300&clientid=02430711070128563");
		//loadUrl(VOD url) ---------------------------------------------------
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
    	
        return true;
    }
  
    public static WebView getWebView()
    {
    	return mWebView;
    }
    
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
    	Log.v(TAG, "keyCode = " + keyCode);
    	
    	if(keyCode == KeyEvent.KEYCODE_BACK &&
    			event.getRepeatCount() == 0 &&
    			mWebView.canGoBack())
    	{
    		Log.v(TAG, "KeyEvent.KEYCODE_BACK --------");
			
    		mWebView.goBack();
    		return true;
    	}
    	
    	return super.onKeyDown(keyCode, event);
    }
    
    public void startVideo()
    {
		Intent goIntent = new Intent();
		goIntent.setClass(MainActivity.this, VideotestActivity.class);
		startActivity(goIntent);
    }
}
