package com.hansun.vod.struct;
/*
 * name:        resourceDescriptorCount
 * function:    parse_comfirm_hdr's resCount
 * 				
 * author:      taoanran
 * time:        2012.12.24
 * */
public class resourceDescriptorCount {
	public int count;
	
	public resourceDescriptorCount()
	{
		count = 0;
	}
}
