package com.hansun.vod;

import java.util.HashMap;

import com.hansun.vod.VodStatus.PlayStateMachine;
import com.hansun.vod.struct.MpegConfig;
import com.hansun.vod.struct.SRMInfoGetFromPMT;

import android.R.bool;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.util.Log;
import android.webkit.WebView;


/*
 * className:   VodCtrol 
 * function:    jsExtend of vod control, it is the mapping class from js to java 
 * author:      taoanran
 * createTime:  2012-11-10
 * */
public class VodControl {	
	public interface CallBack {
		void notifyed();
	}
	private CallBack mCB;
	public CallBack getmCB() {
		return mCB;
	}

	public void setmCB(CallBack mCB) {
		this.mCB = mCB;
	}
	private final static String TAG = "VodControl";
	private static boolean mVodSrmInfoflag = false;
	
	private String vodFucSubArgs[] = new String[16];
	private boolean mMediaPlayerInit = false;//MediaPlayer init flag
	private boolean mSurfaceInit = false;//Surface init flag
	private MediaPlayer mMediaPlayer = null;
	private VodStatus mVodStatus = null; //globel vodStatus
	private MpegConfig mMpegConfig = null;
	
	private STBCmdControl stbCmdControl = null;
	
	private static VodControl instance = null;
	public static VodControl getInstance() {
		if (instance == null)
		{
			instance = new VodControl();
		}
		return instance;
	}
	
	 @SuppressLint("NewApi")
	private boolean setVodInfo(String funcName, String arg)
	 {
		 Log.v(TAG, funcName);
		 
		 //parse the paramt
		 vodFucSubArgs = parseArgs(funcName, arg);
		 ///Log.v(TAG, "parseArgs end +++++++++++++++++++++++++");
		 //find the function
		 if(funcName.equals("CableMPEGClose"))
		 {
			 Log.v(TAG, "we call CableMPEGClose");
			 return setCableMPEGClose();
		 }
		 else if(funcName.equals("CableMPEGConfig"))
		 {
			 Log.v(TAG, "we call CableMPEGConfig");	
			 return setCableMPEGConfig(
					 vodFucSubArgs[0], vodFucSubArgs[1], vodFucSubArgs[2], 
					 vodFucSubArgs[3], vodFucSubArgs[4], vodFucSubArgs[5]);
		 }
		 else if(funcName.equals("CableMpegWindowDestory"))
		 {
			 Log.v(TAG, "we call CableMpegWindowDestory");
			 return setCableMpegWindowDestory(); 
		 }
		 else if(funcName.equals("JseBrowserControl"))
		 {
			 Log.v(TAG, "we call JseBrowserControl");
			 int status = Integer.parseInt(vodFucSubArgs[1]);
			 Log.v(TAG, "status = " + status);
			 return setJseBrowserControl(status);		 
		 }
		 else if(funcName.equals("CableTVWindowDestory"))
		 {
			 Log.v(TAG, "we call CableTVWindowDestory");

			 return setCableTVWindowDestory();
		 }
		 else if(funcName.equals("SetupServerIPFile"))
		 {
			 Log.v(TAG, "we call SetupServerIPFile");

			 return SetupServerIPFile(vodFucSubArgs[0]);
		 }
		 else if(funcName.equals("CableMPEGName"))
		 {
			 Log.v(TAG, "we call CableMPEGName");	

			 return setCableMPEGName(vodFucSubArgs[0]);
		 }
		 else if(funcName.equals("CableMPEGPlay"))
		 {
			 int nMSecond = 0;
			 Log.v(TAG, "we call CableMPEGPlay");
			 
			 if(vodFucSubArgs[0].isEmpty() || vodFucSubArgs[0] == " ") 
			 {
				 Log.v(TAG, "we call CableMPEGPlay, the vodFucSubArgs[0] == \" \" ");
				 vodFucSubArgs[0] = "0";
			 }
			 else
			 {
				 Log.v(TAG, "we call CableMPEGPlay, the vodFucSubArgs[0] != \" \" ");
				 //Log.v(TAG, "vodFucSubArgs[0] =" + Integer.parseInt(vodFucSubArgs[0])); //Integer.parseInt(vodFucSubArgs[0]);
				 /* this is a bug , we will fix it later ------ taoanran */
				 //nMSecond = Integer.parseInt(vodFucSubArgs[0]);
				 //while(true);
			 }
			//7019 is set startTime=1, endTime = 1
			 return setCableMPEGPlay(nMSecond, 1, 1);
		 }
		 else if(funcName.equals("CableMpegWindowCreate"))
		 {
			 Log.v(TAG, "we call CableMpegWindowCreate");	

			 return setCableMpegWindowCreate(vodFucSubArgs[0]);
		 }
		 else if(funcName.equals("CableMPEGPause"))
		 {
			 Log.v(TAG, "we call CableMPEGPause");	

			 return setCableMPEGPause();
		 }
		 else if(funcName.equals("CableMPEGMute"))
		 {
			 Log.v(TAG, "we call CableMPEGMute");	

			 return setCableMPEGMute();
		 }		
		 else if(funcName.equals("AudioVolumeUp"))
		 {
			 Log.v(TAG, "we call AudioVolumeUp");	

			 return setAudioVolumeUp();
		 }
		 else if(funcName.equals("AudioVolumeDown"))
		 {
			 Log.v(TAG, "we call AudioVolumeDown");	

			 return setAudioVolumeDown();
		 }
		 else if(funcName.equals("CableMPEGFast"))
		 {
			 Log.v(TAG, "we call CableMPEGFast");	

			 return setCableMPEGFast(Integer.parseInt(vodFucSubArgs[0]));
		 }
		 else if(funcName.equals("printf"))
		 {
			 Log.v(TAG, "we call printf");
			 
			 printf(vodFucSubArgs[0]);
			 return true ;
		 }
		 else
		 {
			 Log.v(TAG, "we not have this function");
		 }
		return false;
	 }

	private String getVodInfo(String info)
	{
		Log.v(TAG, "get VodInfo = " + info);

		if(info.equals("CableMPEGState"))
		{
			//Log.v(TAG, "we call CableMPEGState");
			return getCableMPEGState();
		}
		else if(info.equals("STBNo"))
		{
			//Log.v(TAG, "we call STBNo");
			return getSTBNo();
		}
		else if(info.equals("CableMPEGPos"))
		{
			//Log.v(TAG, "we call CableMPEGPos");
			return getCableMPEGPos();
		}
		 else if(info.equals("CableMPEGParentRating"))
		 {
			 //Log.v(TAG, "we call getCableMPEGParentRating");
			 return getCableMPEGParentRating();
		 }
		return "OK";
	}
	 
	private VodControl()
	{
		Log.v(TAG, "VodControl init");
	}
	//init the mpeg and mediaPlayer, not realized now (taoanran add)
	public void Install()
	{
		Log.v(TAG, "Install");
		if (!mMediaPlayerInit)
		{
			mMediaPlayerInit = true;//remember the mediaPlayer has been inited
			mVodStatus = VodStatus.getInstance();
			mVodStatus.setPlayerState(PlayStateMachine.Init);//set vod player status is inited
		}
		if (!mSurfaceInit)
		{
			mSurfaceInit = true;//remember the Surfavce has been inited
		}
	}
	
	//mpeg_read(ioctl)
	public String Get(String info)
	{
		return getVodInfo(info);
	}
	
	public boolean SetUp(String func_name, String args)
	{
		Log.v(TAG, "SetUp--------------");
		return setVodInfo(func_name, args);
	}
	
	public void GiveUp()
	{
		Log.v(TAG, "GiveUp");
	}

	/*parse the args*/
	private String[] parseArgs(String funcName, String arg)
	{
		Log.v(TAG, "--------funcName=" + funcName + "," + "arg=" + arg);
		//init array of vodFucSubArgs
		if (funcName.equals("printf"))//printf's arg may be has ":" in a string
		{
			Log.v(TAG, "-----------------taoanran add ------------------");
			//only one args, so we not need to split it
			vodFucSubArgs[0] = arg;	
		}
		else
		{
			//globle
			vodFucSubArgs = arg.split(":");
		}

		return vodFucSubArgs;
	}
//set +++++++++++++++++++++++++++++++++++++++++++++++
	public boolean setCableMPEGClose()
	{
		Log.v(TAG, "in the setCableMPEGClose  !!!!!!!!!!");
		
		stbCmdControl = STBCmdControl.getInstance();
		stbCmdControl.cableMpegClose();///maybe should release all the ssp 
		stbCmdControl.releaseLSCPSession();
		stop();////stop decode 
		HeartBeat m_heartBeat = HeartBeat.getInstance();
		m_heartBeat.StopTimer();////stop ssp heartbeat 
		
		mVodStatus = VodStatus.getInstance();
		mVodStatus.setCmdControlStateMachine(VodStatus.cmdControlStateMachine.TearDown);
		stbCmdControl.ClientReleaseRequest(VodEnum.TearDownCSRRReasonValues.RsnNormal);////stop ssp	
		
		mVodStatus.setPlayerState(VodStatus.PlayStateMachine.Init);//set the player's status to init

		Log.v(TAG, "OUT the setCableMPEGClose  !!!!!!!!!!");

		return true;
	}
	private void stop() {
		// TODO Auto-generated method stub
		SearchChannel search = new SearchChannel();
		search.search_for_vod("player_play_stop");//send the stop message to dvbtestd(localSocket)
	}

	private boolean setCableMpegWindowDestory()
	{
		Log.v(TAG, "in the CableMpegWindowDestory  !!!!!!!!!!");
		
		return true;
	}
	private boolean setCableTVWindowDestory()
	{
		Log.v(TAG, "in the CableTVWindowDestory  !!!!!!!!!!");
			
		return true;
	}
	//@curPlayURL    url Program number:Normal or timeShift
	private boolean SetupServerIPFile(String curPlayURL)
	{
		Log.v(TAG, "in the SetupServerIPFile  !!!!!!!!!!   and the curPlayURL = " + curPlayURL);
		
		//setup ssp connection(first, we must tear down Previous connection)
		stbCmdControl = STBCmdControl.getInstance();
		stbCmdControl.tearDownSspSetupRequest();
		//now there is only AssetID in the curPlayURL
		stbCmdControl.setAssetId(curPlayURL);
		stbCmdControl.setUpSspConnect();
		
		mVodStatus.setPlayerState(PlayStateMachine.Ready);//vod Player ready!!!
		
		return true;
	}
	private boolean setCableMPEGName(String CalbleAssetNAME)
	{
		Log.v(TAG, "in the CableMPEGName  !!!!!!!!!!");
			
		return true;
	}

	private boolean setCableMPEGPlay(int nMSecond, int startTime, int endTime)
	{
		Log.v(TAG, "in the CableMPEGPlay  !!!!!!!!!! --------nMSecond="+nMSecond+" startTime="+startTime + " endTime="+endTime);

		stbCmdControl = STBCmdControl.getInstance();
		stbCmdControl.cableMpegPlay(nMSecond,startTime,endTime);
		mVodStatus = VodStatus.getInstance();
		//mVodStatus.setPlayerState(VodStatus.PlayStateMachine.Play);
		
		if( mVodStatus.getPlayerState() == VodStatus.PlayStateMachine.Init || mVodStatus.getPlayerState() == VodStatus.PlayStateMachine.Ready)
	    {
	        //stbCmdControl->lscpclient()->setcallback(LSC_handle_done_event,stbCmdControl);
			Log.v(TAG, "PLAY !!!!");
			Play();
	    }
	    else
	    {
	    	Log.v(TAG, "RESUME !!!!");
	    	resume() ;
	    }
		
		return true;
	}
	
	private void resume()
	{
		
	}
	
	private void Play()
	{
		Log.v(TAG, "in the Play 111------------");
		
		//wait the TypeClientSessionSetUpConfirm
		while(mVodStatus.getCmdControlStateMachine() != VodStatus.cmdControlStateMachine.LSCPState)
		{
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		stbCmdControl = STBCmdControl.getInstance();
		
		Log.v(TAG, "in the cableMpegPlay 2222------------");
		//get the search Channel's info
		//getMpegNum(program_id, serviceID)
		Log.v(TAG, "getMpegNum(16) = " + stbCmdControl.getMpegNum());
		int tmpMpegNum = Integer.parseInt(Integer.valueOf(Integer.toString(stbCmdControl.getMpegNum()),10).toString());
		Log.v(TAG, "getMpegNum(10) = " + tmpMpegNum);
		//getChannelId(freq)
		int tmpChannelId = stbCmdControl.getChannelId();
		Log.v(TAG, "tmpChannelId = " + tmpChannelId);
		//getSymbolRate
		int tmpSymbolRate = stbCmdControl.getSymbolRate();
		//getModFormat
		int tmpModFormat = 0;
		tmpModFormat = (int) stbCmdControl.getModFormat();
		Log.v(TAG, "tmpModFormat = " + tmpModFormat);
		//search Channel
		SearchChannel search = new SearchChannel();
		//SRMInfoGetFromPMT pmtinfo = search.get_for_vod("vod_qam_get_ip 32 618682482514554 256 6875");
		//search.search_for_vod("vod_qam_search 618 64 6875 32");
		search.search_for_vod("vod_qam_search" + " "
		+ Integer.toString(tmpChannelId/1000/1000) + " " 
		+ Integer.toString(tmpModFormat) + " " 
		+ Integer.toString(tmpSymbolRate/1000) + " "
		+ tmpMpegNum);
		
		//transfor !!!!!!!!!
		if (mCB != null)
			mCB.notifyed();
		//MainActivity.startVideo();
	}
	
	private boolean setCableMPEGConfig(
			String program_id, String fi, String qam_mod, 
			String symbol_rate, String rev_signal, String version)
	{
		Log.v(TAG, "in the setCableMPEGConfig  !!!!!!!!!!");
		Log.v(TAG, "program_id = " + program_id);
		Log.v(TAG, "fi = " + fi);
		Log.v(TAG, "qam_mod = " + qam_mod);
		Log.v(TAG, "symbol_rate = " + symbol_rate);
		Log.v(TAG, "rev_signal = " + rev_signal);
		Log.v(TAG, "version = " + version);
		

		
		if(!getMpegConfig(program_id, fi, qam_mod, symbol_rate, rev_signal, version))
		{
			Log.v(TAG, "getMpegConfig false ------ ");
			
			return false;
		}
		//CableMPEGConfig = 32:618682482514554:64:6875:1:2
		
		/*
		 * we create a thread to  get the vod_srm_info in 7019, now we direct get for test,
		 * if the speed is too little, we create thread -----taoanran add
		 * */ 
		if (!getVodSrmInfo())
		{
			Log.v(TAG, "getVodSrmInfo false ------ ");
			
			return false;
		}
		
		return true;
	}
	
	private boolean getMpegConfig(
			String program_id, String fi, String qam_mod,
			String symbol_rate, String rev_signal, String version)
	{
		if (null == program_id || null == fi || null == qam_mod
				|| null == symbol_rate || null == rev_signal || null == version)
		{
			Log.v(TAG, "getMpegConfig's param is NULL !!!!");
			return false;
		}
		//mMpegConfig is the global mpegConfig
		if(null == mMpegConfig)
		{
			mMpegConfig = new MpegConfig();
		}
		//set the current mpeg_config_info into the global mMpegConfig struct
		mMpegConfig.programId = Integer.parseInt(program_id);
		mMpegConfig.qamMod = Integer.parseInt(qam_mod);
		mMpegConfig.symbolRate = Integer.parseInt(symbol_rate);
		mMpegConfig.revSignal = Integer.parseInt(rev_signal);
		mMpegConfig.version = Integer.parseInt(version);
		
		if(fi.length()/3 >= 6)
		{
			mMpegConfig.freq_count = 6;
		}
		else
		{
			mMpegConfig.freq_count = fi.length()/3;
		}
		for (int i=0; i<mMpegConfig.freq_count; i++)
		{
			mMpegConfig.freq_point[i] = Integer.parseInt(fi.substring(3*i, 3*i+3));
			//Log.v(TAG, "mMpegConfig.freq_point[i] = " + fi.substring(3*i, 3*i+3));
		}
		
		//just for the test
		Log.v(TAG, "mMpegConfig.programId = " + mMpegConfig.programId);
		Log.v(TAG, "mMpegConfig.qamMod = " + mMpegConfig.qamMod);
		Log.v(TAG, "mMpegConfig.symbolRate = " + mMpegConfig.symbolRate);
		Log.v(TAG, "mMpegConfig.revSignal = " + mMpegConfig.revSignal);
		Log.v(TAG, "mMpegConfig.version = " + mMpegConfig.version);
		Log.v(TAG, "mMpegConfig.freq_count = " + mMpegConfig.freq_count);
		for (int i=0; i<mMpegConfig.freq_count; i++)
		{
			Log.v(TAG, "mMpegConfig.freq_point[i] = " + mMpegConfig.freq_point[i]);
		}
		
		return true;
	}
	
	/*
	 * get the vod srm info
	 * */
	private boolean getVodSrmInfo()
	{
		if(null == mMpegConfig)
		{
			mMpegConfig = new MpegConfig();
		}
		
		//only get the info once !!
		if(mVodSrmInfoflag)
		{
			mVodSrmInfoflag = true;
			return true;
		}
		//pmt info, will be fill by sunke --- taoanran add
		SRMInfoGetFromPMT pmtinfo = new SRMInfoGetFromPMT() ;//= new SRMInfoGetFromPMT();
		
		boolean ret = false ;
		int index = 1 ;//local Counter to remember the count of freq
		int count = mMpegConfig.freq_count;
		
		//first, get the vod server by dvb param
		do{
			ret = getvodserver(mMpegConfig.symbolRate,mMpegConfig.freq_point[index],mMpegConfig.qamMod, pmtinfo);
			Log.v(TAG, "get the pmtinfo.m_gateway from pmt = " + pmtinfo.m_gateway);
			Log.v(TAG, "get the pmtinfo.m_ServiceGroupId from pmt = " + pmtinfo.m_ServiceGroupId);
			Log.v(TAG, "get the pmtinfo.m_SRMIpAddress from pmt = " + pmtinfo.m_SRMIpAddress);
			Log.v(TAG, "get the pmtinfo.m_SRMPort from pmt = " + pmtinfo.m_SRMPort);
			index ++ ;
		}while(!ret &&  index < count);
		
		if (7 == index && !ret)
		{
			Log.v(TAG, "[getVodSrmInfo]we no get the vod server !!!!");
			return false;
		}
		
		//set the SRM info
		stbCmdControl = STBCmdControl.getInstance();
		stbCmdControl.setSRMInfo(pmtinfo);
		
		return true;
	}
	
	/*
	 * function:  find the vod server
	 * return :   
	 * 			  true:  finded
	 * 			  false: not finded
	 * */
	private boolean getvodserver(int symbolRate, int freq, int qam_mod, SRMInfoGetFromPMT tmp)
	{
		if (symbolRate < 0 || freq < 0 || qam_mod < 0)
		{
			Log.v(TAG, "getvodserver's param is error !!");
			
			return false;
		}
		
		SearchChannel search = new SearchChannel();
		
		//String ip = System.getProperty("provider.media.reseted");  
		//delete it just for test +++++++++++++++++
		SRMInfoGetFromPMT pmtinfo = search.get_for_vod("vod_qam_get_ip 32 618682482514554 64 6875");
		//search.search_for_vod("vod_qam_search 618 64 6875 32");
		// -----------------------------------------
		Log.v(TAG, "get the pmtinfo (m_gateway) = " + pmtinfo.m_gateway);
		Log.v(TAG, "get the pmtinfo (m_SRMIpAddress) = " + pmtinfo.m_ServiceGroupId);
		Log.v(TAG, "get the pmtinfo (m_SRMPort) = " + pmtinfo.m_SRMIpAddress);
		Log.v(TAG, "get the pmtinfo (m_ServiceGroupId) = " + pmtinfo.m_SRMPort);
		tmp.m_gateway = pmtinfo.m_gateway;
		tmp.m_ServiceGroupId = pmtinfo.m_ServiceGroupId;
		tmp.m_SRMPort = pmtinfo.m_SRMPort;
		tmp.m_SRMIpAddress = pmtinfo.m_SRMIpAddress;
		
		return true;
	}
	//we don't know the MpegWindows's type !!!! -------------taoanran add
	private boolean setCableMpegWindowCreate(String win)
	{
		Log.v(TAG, "in the CableMpegWindowCreate  !!!!!!!!!!");
		
		return true;
	}
	private boolean setCableMPEGPause()
	{
		Log.v(TAG, "in the CableMPEGPause  !!!!!!!!!!");
		
		return true;
	}
	private boolean setCableMPEGMute()
	{
		Log.v(TAG, "in the CableMPEGMute  !!!!!!!!!!");
		
		return true;
	}
	private boolean setAudioVolumeUp()
	{
		Log.v(TAG, "in the AudioVolumeUp  !!!!!!!!!!");
		
		return true;
	}
	private boolean setAudioVolumeDown()
	{
		Log.v(TAG, "in the AudioVolumeDown !!!!!!!!!!");
			
		return true;
	}
	private boolean setCableMPEGFast(int curSpeed)
	{
		Log.v(TAG, "in the CableMPEGFast !!!!!!!!!!-------speed = "+curSpeed);
			
		return true;
	}
	/*
	 * set the browser's status
	 * @status : 0 is hide the browser, 1 is show the browser
	 * */
	private boolean setJseBrowserControl(int status)
	{
		WebView webView = null;
		Log.v(TAG, "in the JseBrowserControl !!!!!!!!!!, and status =" + status);
		webView = MainActivity.getWebView();
		if(webView == null)
		{
			Log.v(TAG, "webView is null !!!! ");
			return false;
		}
		
		
		
		return true;
	}
	
	private boolean printf(String log)
	{
		Log.v(TAG , log);
		return true;
	}
//set ----------------------------------

//get ++++++++++++++++++++++++++++++
	private String getCableMPEGState()
	{
		Log.v(TAG, "in the CableMPEGState  !!!!!!!!!!");
		mVodStatus = VodStatus.getInstance();//get the object
		Log.v(TAG, "CableMPEGState  = " + String.valueOf(mVodStatus.getPlayerState()));
		return String.valueOf(mVodStatus.getPlayerState());
	}
	private String getSTBNo()
	{
		Log.v(TAG, "in the getSTBNo  , the stbNO = 02430711070128563");
			
		return "02430711070128563";
	}
	private String getCableMPEGPos()
	{
		Log.v(TAG, "in the getCableMPEGPos  !!!!!!!!!!");
			
		return null;
	}
	private String getCableMPEGParentRating()
	{
		Log.v(TAG, "in the getCableMPEGParentRating !!!!!!!!!");
			
		return null;
	}
//get ----------------------------------

	
}
