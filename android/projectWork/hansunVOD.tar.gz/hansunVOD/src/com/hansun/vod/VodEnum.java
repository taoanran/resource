package com.hansun.vod;

import android.util.Log;

import com.hansun.vod.VodStatus.cmdControlStateMachine;

/*
 * className:   VodEnum 
 * function:    all enum and the interface to get of the vod 
 * 
 * descript:    
 * author:      taoanran
 * createTime:  2012-11-29
 * */
public class VodEnum {
	private final static String TAG = "VodEnum";
	//ClientReleaseRequest    --- the message of tear down the ssp connect 
	public interface Client_MessageId{
		//revered  0x0000 - 0x400f  
		short	TypeUndefine = 0x0000, // 0x0000
				
				TypeClientSessionSetUpRequest = 0x4010, // 0x4010
				TypeClientSessionSetUpConfirm = 0x4011, // 0x4011
				//reverd 0x4012 - 0x401f
				
				TypeClientReleaseRequest = 0x4020, // 0x4020
				TypeClientReleaseConfirm = 0x4021, // 0x4021
				TypeClientReleaseIndication = 0x4022, // 0x4022
				TypeClientReleaseResponse = 0x4023, // 0x4023
				//0x4024 - 0x4031
				TypeClientAddResourceIndication = 0x4032,  // 0x4032
				TypeClientAddResourceResponse = 0x4033, //  0x4033
				//0x4034 - 0x4041
				TypeClientDeleteResourceIndication = 0x4042, // 0x4042 ,
				TypeClientDeleteResourceResponse = 0x4043,// 0x4043 ,
				//0x4044 - 0x405f 

				TypeClientStatusRequest = 0x4060, // 0x4060 ,
				TypeClientStatusConfirm = 0x4061, // 0x4061 ,
				TypeClientStatusIndication = 0x4062, // 0x4062 ,	
				TypeClientStatusResponse = 0x4063, // 0x4063 ,
				//0x4064 - 0x406f

				TypeClientResetRequest = 0x4070, // 0x4070 ,
				TypeClientResetConfirm = 0x4071, // 0x4071 ,
				TypeClientResetIndication = 0x4072, // 0x4072 ,
				TypeClientResetResponse = 0x4073, // 0x4073 ,
				//0x4074-0x4081
				TypeClientProceedingIndication = 0x4082, // 0x4082 ,
				//ox4083-0x408f
				TypeClientConnectRequest = 0x4090, // 0x4090 ,
				//ox4091-0x40a1
				TypeClientSessionTransferIndication = 0x40a2, // 0x40a2 ,
				TypeClientSessionTransferResponse = 0x40a3, // 0x40a3 ,
				//ox40a4-0x40af
				TypeClientSessionInProgressRequest = 0x40b0;  // 0x40b0 
				//ox40b1-0x5fff
				
				//ox6000-0x7fff
	};
	
	//ClientReleaseRequest    --- tear down 1 
	public interface TearDownCSRRReasonValues{
		short   RsnNormal = 0x0001, //= 0x0001 ,
				RsnClProcError = 0x0002, // = 0x0002 ,	
				MotoDefined = (short) 0x9051, // = 0x9051 ,	
				LSCPDefined = (short) 0x9052; //= 0x9052 
	};  ///  m_reason 
	
	//CSRIReasonValue    --- ClientSessionReleaseIndication
	public interface CSRIReasonValue{
		short   RsnOK = 0x0000,
				RsnNeProcError = 0x0003,	
				RsnSeProcError = 0x0004,	
				RsnSeSessionRelease = 0x001A,
				RsnNeSessionRelease = 0x001B,
				CSRIMotoDefined = 0x151A;
	};  ///  m_reason 
}


