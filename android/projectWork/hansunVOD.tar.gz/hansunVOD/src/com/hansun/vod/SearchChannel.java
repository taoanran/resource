package com.hansun.vod;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.hansun.vod.struct.SRMInfoGetFromPMT;

import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.os.SystemProperties;
import android.util.Log;

//import com.hansun.localsocket.srminfo;
/*
 * className:   SearchChannel 
 * function:    search channel to find the available channel with the js param(such as
 * 				program_id, freq_point, qam_mod,symbol_rate and so on)
 * author:      taoanran
 * createTime:  2012-12-10
 * */

public class SearchChannel {
	
    private static final String TAG = "SearchChannel";

    InputStream mIn;

    OutputStream mOut;

    LocalSocket mSocket;

    byte buf[] = new byte[1024];

    int buflen = 0;
    private boolean connect() {
        if (mSocket != null) {
            return true;
        }
        Log.d(TAG, "connecting...");
        try {
            mSocket = new LocalSocket();

            LocalSocketAddress address = new LocalSocketAddress("dvbtest",
                    LocalSocketAddress.Namespace.ABSTRACT);

            mSocket.connect(address);

            mIn = mSocket.getInputStream();
            mOut = mSocket.getOutputStream();
        } catch (IOException ex) {
            disconnect();
            return false;
        }
        return true;
    }
    private void disconnect() {
        Log.d(TAG, "disconnecting...");
        try {
            if (mSocket != null)
                mSocket.close();
        } catch (IOException ex) {
        }
        try {
            if (mIn != null)
                mIn.close();
        } catch (IOException ex) {
        }
        try {
            if (mOut != null)
                mOut.close();
        } catch (IOException ex) {
        }
        mSocket = null;
        mIn = null;
        mOut = null;
    }
    private boolean readBytes(byte buffer[], int len) {
        int off = 0, count;
        if (len < 0)
            return false;
        while (off != len) {
            try {
                count = mIn.read(buffer, off, len - off);
                if (count <= 0) {
                    Log.e(TAG, "read error " + count);
                    break;
                }
                off += count;
            } catch (IOException ex) {
                Log.e(TAG, "read exception");
                break;
            }
        }
        
            Log.i(TAG, "read " + len + " bytes");
        
        if (off == len)
            return true;
        disconnect();
        return false;
    }
    private boolean readReply() {
        int len;
        buflen = 0;
        if (!readBytes(buf, 2))
            return false;
        len = (((int) buf[0]) & 0xff) | ((((int) buf[1]) & 0xff) << 8);
        if ((len < 1) || (len > 1024)) {
            Log.e(TAG, "invalid reply length (" + len + ")");
            disconnect();
            return false;
        }
        if (!readBytes(buf, len))
            return false;
        buflen = len;
        return true;
    }
    private boolean writeCommand(String _cmd) {
        byte[] cmd = _cmd.getBytes();
        int len = cmd.length;
        if ((len < 1) || (len > 1024))
            return false;
        buf[0] = (byte) (len & 0xff);
        buf[1] = (byte) ((len >> 8) & 0xff);
        try {
            mOut.write(buf, 0, 2);
            mOut.write(cmd, 0, len);
        } catch (IOException ex) {
            Log.e(TAG, "write error");
            disconnect();
            return false;
        }
        return true;
    }
    public synchronized String transaction(String cmd) {
        if (!connect()) {
            Log.e(TAG, "connection failed");
            return "-1";
        }

        if (!writeCommand(cmd)) {
            /*
             * If installd died and restarted in the background (unlikely but
             * possible) we'll fail on the next write (this one). Try to
             * reconnect and write the command one more time before giving up.
             */
            Log.e(TAG, "write command failed? reconnect!");
            if (!connect() || !writeCommand(cmd)) {
                return "-1";
            }
        }
       
            Log.i(TAG, "send: '" + cmd + "'");
        
        if (readReply()) {
            String s = new String(buf, 0, buflen);
            
                Log.i(TAG, "recv: '" + s + "'");
            
            return s;
        } else {
            
                Log.i(TAG, "fail");
           
            return "-1";
        }
    }
    SRMInfoGetFromPMT get_for_vod(String cmd)
    {
    	SRMInfoGetFromPMT si=new SRMInfoGetFromPMT();
    	if(SystemProperties.getInt("hansun.vod.srm.serviceid", 0) ==0 )
    		transaction(cmd);
    	si.m_SRMIpAddress =SystemProperties.get("hansun.vod.srm.ip");
    	si.m_gateway =SystemProperties.get("hansun.vod.srm.gateway");
    	si.m_SRMPort = (short) SystemProperties.getInt("hansun.vod.srm.port",0);
    	si.m_ServiceGroupId = (short) SystemProperties.getInt("hansun.vod.srm.serviceid", 0);
    	Log.e("localsocket","ip"+si.m_SRMIpAddress +si.m_ServiceGroupId + si.m_SRMPort + si.m_ServiceGroupId );
    	return si;
    }
    
    int search_for_vod(String cmd){
    	transaction(cmd);
    	return 1;
    }
                          



}
