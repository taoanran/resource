package com.hansun.vod.struct;

import java.util.ArrayList;
import java.util.List;

/*
 * name:        SSPClientSessionSetUpRequest
 * function:    the SSPClientSessionSetUpRequest message
 * description: this is a data struct class
 * author:      taoanran
 * time:        2012.12.03
 * */
public class SSPClientSessionSetUpRequest {
	public DsmccMessageHeader   m_dsmHeader = null;
	public SessionId m_sessionId = null;   /// deviceId MAC IP systemTime
	public short m_reserved = 0;	
	public ClientId m_clientId = null;
	public ServerId m_serverId = null;
	public ClientSessionSetupRequestBody m_userData = null;   //userData
	
	public SSPClientSessionSetUpRequest()
	{
		m_dsmHeader = new DsmccMessageHeader();
		m_sessionId = new SessionId();
		m_clientId = new ClientId();
		m_serverId = new ServerId();
		m_userData = new ClientSessionSetupRequestBody();
		m_reserved = 0;
	}
}
