package com.hansun.vod.struct;
/*
 * name:        ClientId
 * function:    ask for which SRM(VOD) server
 * 				
 * description: this struct is a number of SSPClientSessionSetUpRequest message,
 * 				it is used by SRM to do communicatation with Server , but set by STB ,
 * 				AS for automatic acquisition of serverID
 * author:      taoanran
 * time:        2012.12.04
 * */
public class ServerId {
	public byte afi ;
	public byte []idi;
	public int dsp ;
	public byte []mac;
	public byte sel ;
	
	public ServerId()
	{
		afi = 0;
		
		idi = new byte[8];
		for (int i=0; i<8; i++)
		{
			idi[i] = 0;
		}
		
		dsp = 0;
		
		mac = new byte[6];
		for (int i=0; i<6; i++)
		{
			mac[i] = 0;
		}
		sel = 0;
	}
}
