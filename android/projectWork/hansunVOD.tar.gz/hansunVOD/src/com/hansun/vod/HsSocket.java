package com.hansun.vod;

import java.io.IOException;
import java.io.InputStream;
import java.net.SocketException;

/*
 * className:   HsSocket 
 * function:    TCP/UDP socket
 * author:      zhengwei & taoanran
 * createTime:  2012-11-28
 * */
public interface HsSocket {
	void wait_done();
	void send();
	InputStream receive() throws IOException;
	void setTimeOut(int milliseconds) throws SocketException;
}